# Cooperative mission interaction contract

**Task:** UX-005  
**Runtime authority:** `public/content/trip-manifest.json`  
**Save authority:** `src/contracts/save-contract.ts` and `docs/save-envelope-contract.md`  
**Applies to:** all 16 scored missions, six excursion variants, and optional `RETURN-EP`

The family solves one shared clue on one parent-controlled phone. UI renders each mission's exact story, objective, three role actions, choices, retry, explanation, safety, fallbacks, and reward from the active manifest record or selected variant. Components never replace content with generic role copy.

## Mission loop

| Step | Required interaction | Stable state / persistence | Exit rule |
|---|---|---|---|
| 1. Open | Show title, objective, energy/duration, safety cue, and current role assignment | `beginMission` commits keyed `in-progress` before leaving `MISSION` | **Hear story** only after the local repository returns an accepted result |
| 2. Roles | Reveal Spotter, Detective, and Navigator cards in content order; parent may swap names | Default assignment derives from stored `roleRotationIndex`; swaps are session-local and unscored | All three actions remain visible by label + icon + shape |
| 3. Read aloud | Show the complete 50–110 word `storyBeat` as text for the parent | Route stage `story` | **Look up**; audio is never required |
| 4. Phone down | Show one short eyes-up instruction and the applicable safety cue | Route stage `look-up` | Parent taps **We're ready** after the real-world action; no timer |
| 5. Cooperate | Reveal one role clue at a time; children point, tap, match, gesture, compare, arrange, or speak to family | Route stage `challenge`; role checks and tentative answers remain session state | Normal completion needs all three role contributions plus the mission-mode gate |
| 6. Answer / observe | Choice missions use select then **Check answer**; observation missions use parent **Team done** | Tentative selection is not mission progress | Correct/team-confirmed continues; wrong stays in Challenge |
| 7. Retry / fallback | Show manifest `hint` when present, then `completion.retryLine`; adult may open manual/skip sheet | No attempt count, penalty, child attribution, or save mutation | Retry, **Done another way**, or **Save for later** |
| 8. Resolve | Submit exactly one of `completed`, `manual`, or `skipped`, plus `resolvedVariantId` when applicable | Repository transaction commits mission state, route, next role index, and any recovery snapshot before Celebration | Never navigate on a pending write |
| 9. Celebrate | Render the committed state, `successLine` or narrative state copy, and one family-level reward treatment | `celebration`; keyed mission record prevents a duplicate award | **Next clue**, **See Passport**, or **Finish story** |

If IndexedDB is unavailable, the repository must return its explicit memory-only durability result before Celebration. Celebration may continue with an `ADULT` recovery banner; it must not claim durable storage or ask children to repeat the clue.

## Deterministic role rotation

Role order is always `[spotter, detective, navigator]`. Family members remain in setup order.

```text
offset = save.family.roleRotationIndex
assignment(roleIndex) = members[(offset + roleIndex) mod members.length]
nextOffset = (offset + 1) mod members.length
```

- With three members, every mission assigns one role to each child and advances each role by one child after any first-time resolution.
- With two members, one child holds two roles; with one member, that child holds all roles. The UI groups repeated names without hiding any role action.
- The parent may swap any two assignments or choose a different name for a role before/during Challenge. Reassignment changes no score, reward, difficulty label, or stored profile.
- A session-local reassignment may return to the deterministic default after reload; the parent can swap again. Only `roleRotationIndex`, not a performance history, is durable.
- `completed`, `manual`, and `skipped` all advance rotation once. Replay or duplicate resolve does not advance it again because the first resolved keyed record wins.
- The app never calls a role easy/hard, younger/older, winner/loser, or ranks family members.

## Meaningful contribution and normal-completion gate

| Role | Required contribution type | Young-child access | Effect on normal completion |
|---|---|---|---|
| Spotter | Point, tap, match, choose an icon, or make a gesture | Reading-free; minimum 48×48 px control when on-screen | Its role check must be confirmed |
| Detective | Compare, sort, explain, or choose a reason | Parent may read choices; pointing is a valid response | Its role check and any answer gate must be confirmed |
| Navigator | Arrange cards, keep a count, start/end a pause, or choose among already-safe modes with the parent | Never controls real travel; parent may do the reading | Its role check must be confirmed |

The age-four child's assigned action is part of the same three-role normal-completion gate, so it changes whether **Team done** becomes available; it is not decorative. A parent can always use manual or skip when age, energy, access, weather, or the setting makes the normal gate unsuitable.

Normal completion uses session checks, not stored child performance. Save data records only one team mission state. No attempt count, per-child completion, reading level, correctness history, or role history is persisted.

## Mission-mode behavior

| Manifest shape | Interaction | Completion gate |
|---|---|---|
| One correct `choices[]` answer | Native radio semantics; selected state has marker + border + text; separate **Check answer** | All role checks + correct choice |
| Observation/team confirm | Each role card exposes its concrete action; parent confirms the family acted together | All role checks + **Team done** |
| Sensory choice | Sound and visual alternatives are equal; never record audio | All role checks + one selected sound/visual clue |
| Match/sort/create | Tap-to-select and ordered tapping only; no precise drag, handwriting, or long typing | All role checks + content-defined set/match; parent can confirm arrangement |
| Finale | Choose one discovery, one evidence label, and place each manifest-derived power card | All three role checks; no perfect-score or all-completed gate |
| Epilogue | Choose one earned stamp/memory or close with one tap | Optional reflection; no reward or scored progress |

Instructions support pointing and parent read-aloud from start to finish. Speech is directed to the family only; no child must address or perform for a stranger.

## Clue reveal, hint, and retry

- Role cards begin collapsed to label + assigned nickname + icon + shape. A tap reveals that role's exact action. Previously revealed cards remain visible so the family can work together.
- Reveal is user-triggered, never timed or automatic. **Show all clues** is an adult/tired-legs alternative and changes no outcome.
- Choice selection does not submit. On an incorrect check, retain the selection, announce **“Take another look.”**, show that choice's manifest `hint`, and keep focus on the result/hint before returning to the group.
- When no choice exists, **Try again** reveals `completion.retryLine`. No shake, buzzer, red cross, attempt counter, point loss, lockout, or named-child attribution is allowed.
- The explanation appears only after correct/team-confirmed completion or when a parent asks **Why?**; it never blocks manual/skip.

## Manual and skip

- The fallback sheet is adult-labelled and reason-free. Select one row, then expose one primary: **Done another way** (`manual`) or **Save for later** (`skipped`).
- `manual` means the parent confirms an equivalent family action. It earns the mission's one shared stamp exactly once.
- `skipped` shows the non-collectible Saved-for-later marker, not a false observation stamp. It still resolves the mission and can restore the chapter power under the reward contract.
- The child-facing copy comes from `narrative.states.manual` or `narrative.states.skip`; the UI does not invent failure language.
- A chapter restores its power when all listed missions are resolved and at least one is `completed`/`manual`, unless the parent uses the documented whole-chapter override. Children never see an empty/missed stamp slot.

## Persistence, resume, and one shared reward

The resolve request is one local serialized mutation. It must commit:

- stable mission ID and first resolved state;
- selected excursion `resolvedVariantId`, or `null` for fixed missions;
- next stable route/stage;
- `roleRotationIndex` advanced once;
- recovery snapshot/outbox changes owned by the repository.

Rewards and unlocks are derived after the committed save returns. A `completed`/`manual` mission reveals one family stamp; `skipped` reveals one saved marker. Repeated stamp types are valid. No sibling score, streak, rank, missed badge, percentage, or separate child reward exists.

Resume rules:

- Before resolve commits: return to the last stable story/look-up/challenge state; role checks and unsubmitted answers may restart without penalty.
- After resolve commits: return to Celebration or the next stable state; do not write again or animate a second award.
- Save retry keeps the children's successful session result in memory. Parent recovery decides whether to retry or continue memory-only.
- Unknown mission IDs never contribute to rewards or unlocks.

## TBC excursion variants

- `VER-04` and `VER-05` stay the only stable mission IDs. `selectedPairId` maps atomically to its manifest morning/afternoon variant IDs.
- When no pair is selected, show **Mystery route**, **Parent chooses later**, and adult/manual/skip paths. Do not choose the recommended pair silently.
- Once selected, the variant replaces story, objective, roles, choices, facts, completion copy, fallbacks, and safety inside the ordinary loop; it adds no screen, chapter, mission, or reward.
- Resolve writes the exact variant ID. Later pair changes affect unresolved slots only; a resolved slot keeps its recorded variant for honest history.
- Missing/unknown variant content falls back to the stable slot's base content plus manual/skip. `VER-06` remains reachable.

## Accessibility and safety invariants

- Reading order is story heading → text → role assignment → eyes-up action → challenge → primary → adult fallback.
- Each role and answer state has visible text and programmatic name/state; icon, shape, and color are redundant signals.
- Result and save status use polite live announcements. Focus never jumps during a child's real-world observation.
- Road missions are configured before driving or at a safe stop; driver interaction is impossible in the child loop.
- Location, tickets, live data, audio, venue entry, and cloud state never gate a role, completion, or reward.

