# Motion and celebration system

**Task:** UX-006  
**Machine tokens:** `docs/design-tokens.json#/motion`  
**Status:** P0 visual feedback and static meaning locked; P1 sound assets not produced

Motion confirms an action, preserves Bussola's story continuity, or reveals a committed team result. It never creates meaning, delays safety copy, loops while reading, or implies the app knows the family's location.

## Exact motion tokens

| Token | Value | Use |
|---|---:|---|
| `motion.duration.tap` | 80 ms | pressed feedback |
| `motion.duration.responseMax` | 100 ms | maximum time before visible tap response |
| `motion.duration.fast` | 150 ms | selection, hint, local reveal |
| `motion.duration.standard` | 220 ms | screen/content state change |
| `motion.duration.slow` | 300 ms | sheet/modal/shared-object move |
| `motion.duration.celebrationSkipAfter` | 600 ms | latest time the continue/skip control becomes available |
| `motion.duration.celebration` | 1200 ms | normal mission celebration |
| `motion.duration.celebrationMax` | 2500 ms | hard stop for every celebration |
| `motion.delay.revealStagger` | 60 ms | optional, user-triggered multi-item reveal only |
| `motion.delay.rewardSettle` | 120 ms | pause between persisted result and reward emphasis |
| `motion.distance.short` | 8 px | card/screen enter offset |
| `motion.distance.sheet` | 16 px | sheet enter offset |
| `motion.scale.pressed` | 0.98 | press feedback |
| `motion.scale.rewardStart/rest/peak` | 0.88 / 1 / 1.04 | one reward emphasis, no repeated bounce |
| `motion.performance.targetFramesPerSecond` | 60 | target on the actual family phone |
| `motion.performance.frameBudgetMilliseconds` | 16.67 ms | measurement threshold |
| `motion.performance.maxConcurrentMovingElements` | 2 | performance/cognitive ceiling |

Easing is `standard` `[0.2,0,0,1]`, `enter` `[0,0,0,1]`, `exit` `[0.3,0,1,1]`, and `emphasis` `[0.16,1,0.3,1]`. Durations include delays. No motion sequence may postpone readable result text or focus.

## Choreography

| Event | Full-motion treatment | Reduced-motion treatment | Focus / announcement |
|---|---|---|---|
| Button press | Scale to 0.98 and surface change in 80 ms; release to 1 in 80 ms | Surface/outline change in 80 ms, no scale | Native focus stays; activation once |
| Answer select | Marker/border updates immediately; label fades to selected emphasis over 150 ms | Marker/border/text update immediately | Announce selected label, not “correct” |
| Wrong answer | Hint fades in over 150 ms | Hint appears immediately | Polite “Take another look”; no shake/buzz |
| Role clue reveal | Opacity 0→1 + translateY 8→0 over 150 ms; optional 60 ms stagger only after **Show all** | All requested clues appear together in 100 ms fade | Heading remains; revealed text enters reading order |
| Screen forward | Existing content fades to 0 over 150 ms; next content enters opacity + 8 px over 220 ms | 100 ms crossfade, no travel | Focus new heading after state commit |
| Browser/back | Reverse opacity only over 150 ms; no theatrical reverse journey | 100 ms crossfade | Restore invoking control when possible |
| Bottom sheet | Backdrop opacity over 220 ms; sheet translateY 16→0 over 300 ms | Backdrop + sheet fade 100 ms | Focus sheet heading/first control |
| Look-up handoff | Nonessential UI fades in 150 ms; instruction remains static | Immediate static state | No auto timer, pan, phone animation, or sound |
| Local save accepted | Static check appears in 150 ms before Celebration | Static check appears immediately | Announce “Adventure saved” only if useful |
| Offline/permission/map state | No spatial animation; banner fades 150 ms | Immediate static banner | Never animate location or imply tracking |

Only `transform` and `opacity` may animate in P0. Border/text/state changes switch directly or crossfade. Do not animate layout properties, dimensions, scroll position, gradients, filters, shadows, masks, SVG paths, map position, or illustration crops. `will-change` may be applied immediately before a transition and removed on completion.

## Shared Bussola continuity

The same provenance-approved transparent Bussola asset is the shared object in Mission, Celebration, Atlas, and Passport. It may translate and scale between measured slots over 300 ms; it never morphs into a different drawing, follows the user while scrolling, or idles in a loop. If shared-object geometry is unavailable, crossfade the two static instances over 220 ms.

The current square PWA icon is an install asset, not the shared in-app character asset. The transparent Bussola runtime cutout remains to be generated under [`asset-production-contract.md`](asset-production-contract.md).

## Mission celebration storyboard

All result text, state label/icon/shape, and the continue control exist at frame zero. Animation is progressive enhancement.

### `completed` or `manual` — 1200 ms

| Time | Treatment |
|---:|---|
| 0 ms | Committed completion label and success/manual copy are visible; focus lands on heading |
| 0–220 ms | Bussola crossfades/translates into the Celebration slot |
| 220–700 ms | One family stamp scales 0.88→1.04→1 and fades in; no spin or repeated bounce |
| 600 ms | **Next clue** / **See Passport** is enabled and can skip remaining motion |
| 700–1200 ms | Stamp label and manifest `successLine` settle; motion ends |

`manual` uses the same stamp once with the text “You solved it your way.” It does not receive a lesser animation or a separate child label.

### `skipped` — 600 ms

Show the Saved-for-later bookmark icon, flag shape, and manifest narrative skip copy at frame zero. A single 150 ms fade is allowed; there is no stamp burst, sadness, empty slot, or penalty. Continue is available immediately.

### Chapter power restore — maximum 1800 ms

When every chapter mission is resolved and the reward rule is met, use the current manifest chapter/power record. Bussola enters over 220 ms; the chapter segment and power label fade/scale once from 220–900 ms; “Compass awake: {power} is glowing.” remains static by 900 ms. Continue is available at 600 ms; all motion ends by 1800 ms.

## Final compass ceremony

The component receives the ordered active `manifest.chapters`; `segmentCount = chapters.length`. It never assumes four, never creates an epilogue segment, and uses `semantic.chapter[id] ?? semantic.chapter.default`.

```text
segmentWindow = min(180 ms, 720 ms / max(segmentCount, 1))
segmentStart(i) = 220 ms + i * segmentWindow
```

- At frame zero, every segment, chapter label/shape, resolved state, and final text is already present.
- From 0–220 ms, Bussola moves/crossfades into the centre.
- Each segment gets one opacity/scale emphasis in manifest order within the 720 ms segment window. Maximum two elements move at once.
- Final needle emphasis runs once from 940–1240 ms; it rotates no more than 12 degrees and returns to its resting orientation. Reduced motion never rotates it.
- Teamwork/finale text is fully settled by 1400 ms. Continue is available at 600 ms. Hard stop is 2200 ms, below the 2500 ms global ceiling.
- Three- and four-chapter fixtures use the same formula. A longer future manifest compresses the window rather than extending the ceremony.

## Epilogue treatment

`RETURN-EP` is unscored. The static home arrow and chosen earned stamp may crossfade over 220 ms; there is no new segment, stamp, power fill, confetti, score, or fanfare. **Finish story** is never delayed.

## Reduced motion

`prefers-reduced-motion: reduce` or saved `settings.reducedMotion=true` activates the same contract:

- press feedback is an 80 ms surface/outline change;
- state changes use at most a 100 ms opacity crossfade;
- all translate, scale, rotate, parallax, zoom, bounce, shake, burst, confetti, auto-pan, shared-object travel, and stagger are zeroed;
- completed/manual/skipped labels, stamp/marker, chapter segment, explanation, focus, live announcement, and continue action appear together;
- no information, order, reward, or completion timing changes.

The stricter of OS preference and saved setting wins. Switching the setting cancels in-flight nonessential motion and settles directly to the final state.

## Sound contract (P1, no assets yet)

Sound defaults to `false` in the save envelope. It may play only after a parent enables it and a user gesture unlocks playback. Muted/offline success remains complete through text + icon + shape.

| Future cue ID | Max length | Intent | Prohibited treatment |
|---|---:|---|---|
| `success-soft` | 250 ms | soft brass click after committed mission | no arcade ding or spoken praise |
| `stamp-paper` | 300 ms | quiet paper/stamp contact | no impact boom |
| `power-chime` | 650 ms | four-note-or-manifest-neutral warm chime | no melody length tied to chapter count |

No wrong-answer, skip, offline, permission, or destructive sound exists. Future audio must be locally bundled, under 96 KiB total, and recorded in the runtime asset register only after files and licence/provenance exist.

## Performance and verification gate

- Keep no more than two moving elements and one fading backdrop active.
- Decode the next required image before starting its transition; never animate a late layout shift.
- Pause/cancel nonessential motion when the page is hidden, interrupted, or backgrounded.
- Measure tap-to-visible response, dropped frames, long tasks, and animation duration on the actual primary and backup phones in browser and installed mode.
- Pass requires visible feedback within 100 ms, common transitions 150–300 ms, no celebration beyond 2500 ms, no loop during reading/map/permission states, and an observed 60 fps target without essential information loss when reduced.

