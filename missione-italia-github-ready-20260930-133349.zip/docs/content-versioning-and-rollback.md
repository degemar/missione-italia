# Content versioning, integrity, and rollback

**Contract:** `1.0.0` · **Authority:** `BE-011`

## Identities

- `schemaVersion` selects the JSON Schema contract.
- `contentVersion` identifies an immutable published story package, currently `trip-2026.10-v1`.
- `minimumAppVersion` and storage bounds determine runtime compatibility.
- Stable chapter, mission, source, reward, asset, checkpoint, pair, and variant IDs are never reassigned.

Authoring files may change while `content-package.status` is `foundation`. Freeze copies the validated bytes to `public/content/releases/<contentVersion>/`, sets `status: frozen` and `immutable: true`, recomputes hashes, and records the release commit. Once published, any byte correction—including punctuation—requires a new `contentVersion`; the old path and package stay unchanged.

## Hash rule

Each package file uses lowercase SHA-256 of its exact served UTF-8 bytes. No newline or JSON reformatting occurs before hashing.

`packageHash = SHA256(UTF8(sorted(files by path).map(path + ":" + sha256 + ":" + bytes).join("\n")))`

`content-package.json` is not in its own `files` array, avoiding a self-hash. The package index is validated by the app/build signature boundary; file hashes and `packageHash` establish internal completeness and identity.

## Activation transaction

1. Keep bundled content as permanent last-resort known-good content.
2. Download a candidate index and files into a staging cache; never overwrite active keys.
3. Reject unsupported schema/app/storage versions, unsafe paths, duplicate paths, unapproved URLs, or non-frozen remote packages.
4. Verify every byte count, file hash, package hash, JSON Schema, ID, cross-reference, safety, privacy, and exclusion rule.
5. Wait for Atlas or Parent Corner and a committed local save; never swap content mid-mission.
6. Atomically change only the active-package pointer after all checks pass.
7. Retain bundled content, active known-good content, and at most one previous validated package. Delete abandoned staging data.

A timeout, missing file, parse error, schema error, hash mismatch, incompatible version, quota error, or interrupted download discards staging and leaves the active pointer untouched. Partial packages are never visible.

## Compatibility matrix

| Content schema | App | Storage | Runtime action |
|---|---|---|---|
| `0.1.0` | `>=0.1.0` | `1` | Activate after full validation. |
| newer/unknown | any | any | Keep last known good; show parent update note only. |
| supported content | below `minimumAppVersion` | any | Keep last known good; require app update outside mission play. |
| supported content | supported | below minimum or above maximum | Keep last known good; never downgrade/overwrite save. |
| missing/corrupt index or file | any | any | Discard staging and continue offline. |

## Save reconciliation and rollback

The save records its active `contentVersion` and stable mission IDs. On a compatible update, known IDs retain state. Unknown/removed IDs remain serialized for recovery but are excluded from unlocks, rewards, powers, and progress. New IDs begin unresolved. A resolved excursion slot retains its `resolvedVariantId` even if the parent later changes the selected pair.

Rollback changes the active pointer to the newest prior validated compatible package; it never rewrites that package or deletes the save. If no cached package passes, load the bundled package. GitHub Pages, map tiles, and Supabase may all be unavailable without blocking this path.

Current `public/content/content-package.json` is a reproducible foundation integrity record, not a published freeze. `scripts/validate-contracts.mjs` verifies its exact file and package hashes.
