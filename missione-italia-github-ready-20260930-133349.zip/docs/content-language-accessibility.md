# Language, Reading, and Accessibility Brief

**Applies to:** all Story/UI content in `trip-2026.10-v1`

## Language model

- English is the complete UI, story, instruction, safety, and parent language.
- Italian is a small optional phrase layer; hiding it never removes meaning.
- Initial phrase set: **ciao** (hello/bye), **buongiorno** (good morning), **grazie** (thank you), **per favore** (please), **arrivederci** (goodbye). `ROAD-03` carries plain-English pronunciation aids and gestures; `ST-054` remains the independent pre-freeze language QA gate.
- Preserve official place names and diacritics. Do not imitate an accent or use Italian fragments as jokes.

## Reading and read-aloud

- Parent read-aloud is P0. No mission depends on text-to-speech, recorded audio, sound, or headphones.
- Child instruction: one action, 12 words or fewer where practical; buttons 1–3 words; answer labels 1–6 words.
- Child story: short concrete sentences, generally 12 words or fewer; one unfamiliar idea at a time.
- Parent-read narration: 30–60 seconds and no more than 110 words.
- The age-4 contribution is point/tap/match/gesture; the age-7 contribution is compare/choose/explain; the age-9 contribution may include reading a short clue. Roles rotate and can be swapped.

## Inclusive defaults

- Every color clue also uses a name plus shape, icon, number, or position.
- Every sound clue has a visual/observation alternative. No recording is requested.
- Animation is decorative; reduced motion removes parallax, shaking, auto-pan, and celebratory bursts without hiding state.
- No timed answers, handwriting, precise dragging, long typing, or reading-only completion.
- Key state remains understandable at 200% text zoom and in portrait on one parent phone.
- Touch targets and contrast are UX responsibilities; copy never relies on color words such as “tap the green one” alone.
- “Tired legs,” quiet, seated, closed-place, rain, and manual alternatives preserve the same story beat.

## Privacy and family setup

- Ask for nicknames only. No surnames, birthdays, faces, voices, school, live location history, or child accounts.
- A parent controls any external map, ticket, transport, permission, reset, or delete action.
- One shared device means instructions alternate between “look together” and “phone down.”

## Required safety wording

- Walking/viewpoint: “Stop together. Parent holds the phone. Look from the safe path.”
- Road mission: “Parent starts this before driving or at a safe stop. Driver: no screen.”
- Water/bridge: “Stay beside your adult and behind the edge or rail.”
- Skip: “Save this clue for another explorer.”
- Manual completion: “We did it another way.”

## Acceptance examples

Good: “Find two arches from the square. Point—do not cross for a clue.”  
Avoid: “Race to the red arch and scan it.”

Good: “Listen for water, footsteps, or a bell. Prefer quiet? Match the three picture clues.”  
Avoid: “Record the people around you.”
