# Missione Italia — Story Bible

**Foundation version:** 1.0 · **Status:** approved for Wave 0 · **Audience:** one family team, children 9/7/4

## One-line premise

A friendly travel compass named **Bussola** has forgotten what makes a journey meaningful; the family restores its four powers—Curiosity, Wonder, Creativity, and Teamwork—by noticing real places together.

## Canon

- **Fiction:** Bussola can speak, react, and remember. A playful gust spun its needle and scattered four powers. The stakes are personal: without them, Bussola can point north but cannot remember why people explore. There is no villain, danger, curse, or world-saving duty.
- **Fact:** Place history, craft history, visitor information, and geography come only from cited source records. Facts never prove the fictional compass story.
- **Tradition:** A community story passed down over time is introduced as “People traditionally say…”
- **Legend:** An impossible or unverified tale is introduced as “A local legend tells…”
- **Fictional bridge:** Bussola may connect clues poetically, but narration must say or visually mark that the connection belongs to our story.

## Character

**Bussola** means “compass” in Italian. Bussola is warm, curious, slightly mischievous, and never sarcastic at a child’s expense. It sometimes mixes up directions or over-celebrates a tiny clue, then asks the team for help. It never orders, grades, frightens, spies, or claims live knowledge about the family’s location.

Voice pattern: short sentences, one vivid image, one clear action. Example: “My needle is doing the spaghetti wobble. Three clues, one team—can you steady it?”

## Four-power arc

| Chapter | Date | Power | Story beat | Restoration proof |
|---|---|---|---|---|
| Road | Sun 4 Oct | **Curiosity** | The mystery begins between Basel and the Gardaland area. The children notice changes without needing a route, GPS, or screen. | Three road observations are resolved while seated; the parent may confirm manually. |
| Venice | Tue 6 Oct | **Wonder** | Lions, bridges, working boats, and canal sounds show Bussola that a city can be read in many ways. | Four safe, public-space discoveries form a “wonder map.” |
| Lagoon Islands | Wed 7 Oct | **Creativity** | Murano patterns and Burano colour/lace clues reveal how makers repeat, vary, and pass on ideas. | Three maker clues form an original family pattern. |
| Verona | Thu–Fri 8–9 Oct | **Teamwork** | Roman Verona, a literary tradition, the Adige, and whichever excursion block the parent selects require different contributions. | Six team missions resolve; excursion slots may be manually completed or skipped without blocking the finale. |

**Monday 5 October is intentionally silent.** Gardaland has no chapter, mission, checkpoint, marker, reward, source, brand reference, or story event.

**Saturday 10 October is an unscored epilogue.** Bussola points home and asks for one favourite discovery. No power depends on it.

## Beginning, middle, finale

1. **Beginning:** Before the car moves—or at the first safe stop—the parent reads the 45-second opening. Each child chooses a nickname and the team starts with rotating roles. The youngest can wake Bussola with one tap.
2. **Middle:** Each chapter opens with a missing-power question, alternates observing and thinking, and closes with one shared reflection. A skipped place becomes “a clue saved for another explorer,” never failure.
3. **Finale:** `VER-06` asks all three roles for one action and restores Teamwork in under five minutes. It works at a Verona viewpoint, indoors, at the hotel, or by manual parent choice. It adapts to any number of completed, manual, or skipped excursion missions.

## Cooperative roles

- **Spotter:** points, matches a shape, chooses an icon, or makes a gesture. Reading is never required.
- **Detective:** compares two clues, explains a pattern, or chooses a reason.
- **Navigator:** reads the short instruction or helps the parent choose from already-safe options. The role never controls real travel.

Roles rotate each mission. Ages 4/7/9 inform accessible actions but never appear as ability rankings. The app awards the family, not individuals.

## Recurring language

- Opening: “Eyes up, explorers.”
- Team cue: “Three clues, one team.”
- Pause: “Clue saved. The adventure waits for us.”
- Inclusion promise: “Nobody is left behind.”
- Power restored: “Compass awake: **{power}** is glowing.”
- Italian sprinkle: one useful phrase at a time, always with English meaning and optional pronunciation help.

## Tone and prohibited themes

Keep it adventurous, kind, observant, and lightly silly. No peril, kidnapping, villains, graphic gladiator violence, romantic pressure, touching statues for luck, stereotypes, caricatured Italian accents, sibling competition, public performance, timed courage tests, surveillance, or claims that the phone knows where a child is. Never encourage running, separating, approaching water edges, touching merchandise, photographing strangers, or using the phone while the car is moving.

## Canon boundaries

- Parent read-aloud is P0; audio is optional later.
- English carries all meaning; Italian is a small phrase layer.
- Nicknames are the only child identifiers.
- Arena and Juliet’s House missions are fully playable outside. Interior guidance is deferred.
- Every mission works without GPS, audio, tickets, live maps, or an open venue.
- Thursday remains Verona-first. Friday’s two excursion blocks remain manifest-selected and TBC until the parent chooses.

