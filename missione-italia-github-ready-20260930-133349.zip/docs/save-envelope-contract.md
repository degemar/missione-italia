# Local save-envelope contract

**Schema:** `schemas/save/v1/save-envelope.schema.json` · **TypeScript:** `src/contracts/save-contract.ts` · **Authority:** `BE-020`

The envelope is the smallest durable gameplay state. IndexedDB remains the future authoritative store; Supabase is absent and disabled. JSON is UTF-8, contains no binary/base64 media, targets at most 64 KiB, and has a hard rejection limit of 256 KiB.

## Defaults

`tests/fixtures/save/valid/fresh.json` is the canonical default: schema `1`, revision `0`, `fresh`, no family members, Welcome route, no mission progress or excursion pair, English with Italian phrases, sound/motion/contrast defaults, and backup disabled/clean.

## Stored versus derived

Stored: nickname/age band/avatar reference, role rotation, stable route, mission state and chosen variant, excursion pair, small settings, local revision, and optional backup metadata.

Derived from active known content: unlocked mission/chapter, chapter completion, stamp set, compass powers, discovered facts, progress text, next mission, and finale readiness. Unknown mission IDs never contribute to a derived value.

## State transitions

| Current | Action | Next | Idempotency |
|---|---|---|---|
| `fresh` / `reset` | complete Setup | `in-progress` | Repeating identical setup produces no duplicate data. |
| no mission record | start known mission | mission `in-progress` | Repeated start returns unchanged state. |
| mission `in-progress`/absent | resolve known mission | `completed`, `manual`, or `skipped` | First resolved state wins; replay does not increment revision or award again. Parent correction is a separate future explicit action. |
| mission resolved | replay/repeat same or different resolve action | unchanged | No duplicate stamp, power, or progress because rewards are derived from one keyed record. |
| any | resolve unknown mission ID | unchanged | Unknown IDs can arrive only through recovery/import and remain inactive. |
| any | reset progress | `reset`, empty mission map, Atlas route | Family, settings, excursion choice, and backup preference remain; repeated reset is unchanged. |
| all scored known missions resolved | engine confirms finale | `completed` | Completion is derived/validated against the active manifest before storing. |
| any | Delete family | no envelope | Deletion belongs to `BE-023`, not this reducer. |

Every accepted mutation increments `localRevision` exactly once. If backup is enabled, it marks the snapshot dirty; no network work occurs in the reducer. Persistence and atomic transactions belong to `BE-021` and are intentionally absent.

## Recovery rules

- `missionProgress` is a map keyed by stable mission ID, so duplicate event replay cannot create duplicate rows.
- Unknown IDs validate and are partitioned into a recovery-only map. They stay serialized until an explicit migration/export decision.
- Route IDs that no longer resolve fall back to Atlas at runtime; the raw unknown mission progress is not deleted.
- A content mismatch never rewrites the save before compatibility and reconciliation succeed.
- `resolvedVariantId` is recorded only for the stable excursion slot actually resolved.

## Fixtures and validation

Valid fixtures cover fresh, in-progress, completed, manual, skipped, reset, and unknown-ID recovery. Invalid fixtures cover prohibited personal data, invalid state, binary media, plus a generated save above 256 KiB. Run:

```powershell
node scripts/validate-contracts.mjs
```
