# Backend data boundaries and ownership

**Contract:** `1.0.0` · **Status:** frozen for Backend Wave 0 · **Authority:** `BE-001`

One owner controls every field. Static content is build-owned, gameplay is device-owned, and any later Supabase row is backup-owned. Removing all cloud code must leave every setup, mission, completion, reward, fallback, reset, and replay path unchanged.

## Static public content

Retention is the lifetime of the immutable content release. Deletion means removing the entire release from a later build; a published version is never edited in place.

| Field path | Owner | Retention and deletion |
|---|---|---|
| `content-package.schemaVersion/contentVersion/status/immutable/createdAt` | Build release | Retain with release; replace only with a new version. |
| `content-package.hashAlgorithm/hashCanonicalization/packageHash` | Build release | Retain with release; invalid package is discarded as a unit. |
| `content-package.compatibility.*` | Build release | Retain with release; new compatibility requires a new package. |
| `content-package.entrypoint/files[].path/sha256/bytes/offlineCritical` | Build release | Retain with release; deleting a file invalidates the package. |
| `trip.schemaVersion/contentVersion/tripKey/status/generatedAt` | Story build | Retain with content version; remove only by retiring that version. |
| `trip.minimumAppVersion/minimumStorageVersion` | Backend build | Retain with content version; incompatible packages are not activated. |
| `trip.calendarAuthority/sourceRegister/rewardRegister/assetRegister` | Story build | Retain with release; references must resolve. |
| `trip.locales.default/phraseLayer[]` | Story build | Retain with release. |
| `trip.privacy.childIdentifiers/childAccounts` | Product contract | Retain with release; validation rejects a weaker value. |
| `trip.dependencies.deviceMode/gps/audio/tickets/liveData` | Product contract | Retain with release; all optional dependencies remain false. |
| `trip.excludedContent[]/epilogueMissionId` | Product contract | Retain with release; Gardaland remains exclusion-only. |
| `chapters[].id/order/dateRange/title/power/status/missionIds/openingBeat/closingBeat` | Story build | Retain with release; IDs are never reused. |
| `excursionSelection.status/selectedPairId/recommendedPairId` | Story build | Retain with release; selection may remain null. |
| `excursionSelection.thursdayShortTrip.status/recommendation/rule` | Story build | Retain with release. |
| `candidatePairs[].id/label/status/morningVariantId/afternoonVariantId/reason` | Story build | Retain with release; replacing a pair creates a new content version. |
| `missions[].id/order/chapterId/date/scored/title/status` | Story build | Retain with release; mission IDs are permanent. |
| `missions[].durationMinutes/energy/storyBeat/objective` | Story build | Retain with release. |
| `missions[].location.mode/label/coordinates` | Story build | Public landmark hint only; never a user/device position. |
| `missions[].roles[].role/action` | Story build | Retain with release. |
| `missions[].phrases[].it/en` | Story build | Optional; retain with release. |
| `missions[].choices[].id/label/correct/hint` | Story build | Retain with release; bundled quiz answers are public. |
| `missions[].facts[].label/text/sourceId` | Story build | Retain with release; external claims require a source. |
| `missions[].completion.mode/allowedStates/successLine` | Story build | Retain with release. |
| `missions[].fallbacks.noGps/closedVenue/badWeather/tiredLegs` | Story build | Retain with release. |
| `missions[].safety[]/offlineCritical/dependencies.*` | Product safety | Retain with release; validation fails closed on omission. |
| `missions[].reward.stamp/power/sourceIds[]/assetIds[]` | Story build | Retain with release; IDs must resolve. Missing `assetIds` normalizes to `[]`. |
| `missions[].variants[].id/pairId/title/locationLabel/objective/facts/sourceIds/assetIds` | Story build | Retain with release; stable slot mission ID does not change. |
| `sources.schemaVersion/registerVersion/defaultCheckedOn` | Evidence build | Retain with release. |
| `sources.claims[].id/publisher/pageTitle/url/retrievedOn` | Evidence build | Retain with release; URL host must be allowlisted. |
| `sources.claims[].claimType/claimText/stability/requiredRecheckOn/usedBy[]` | Evidence build | Retain with release; volatile copy may be hidden after failed recheck. |
| `rewards.schemaVersion/powers[].id/label/chapterId` | Story build | Retain with release; referenced IDs are permanent. |
| `rewards.stamps[].id/label` | Story build | Retain with release. |
| `assets.schemaVersion/assets[].id/path/mediaType/license/offlineCritical/sha256` | UX/build | Retain with release; removal requires a new package and no live references. |
| `walk.type/properties.id/title/chapterId/mode` | Story/build | Retain with release. |
| `walk.features[].type/id/geometry.type/geometry.coordinates` | Story/build | Fixed public geography only; retain with release. |
| `walk.features[].properties.kind/order/label/missionIds/checkpointIds` | Story/build | Retain with release; references must resolve. |

## Device-owned save

IndexedDB will be authoritative when `BE-021` is implemented. Wave 0 defines the envelope only. Browser/OS eviction can remove it; Parent **Delete family** removes the full envelope. **Reset progress** applies the per-field behavior below.

| Field path | Owner | Retention | Reset / delete behavior |
|---|---|---|---|
| `schemaVersion/tripKey/contentVersion` | Device save | Until delete/eviction | Reset retains; delete removes. |
| `journeyState/localRevision` | Device save | Until delete/eviction | Reset writes `reset` and increments revision; delete removes. |
| `family.members[].id/nickname/ageBand/avatarId` | Parent on device | Until delete/eviction | Reset retains; delete removes. Nickname is the only free text. |
| `family.roleRotationIndex` | Device save | Until delete/eviction | Reset retains; delete removes. |
| `route.screenId/chapterId/missionId/stage/selectedWalkId` | Device save | Until next stable route | Reset clears to Atlas; delete removes. |
| `missionProgress.{missionId}.state/resolvedVariantId` | Device save | Until reset/delete/eviction | Reset and delete remove. Unknown IDs are retained but inactive. |
| `excursionSelection.selectedPairId` | Parent on device | Until changed/delete | Reset retains; delete removes. |
| `settings.language/italianPhrases/sound/reducedMotion/highContrast` | Parent on device | Until changed/delete | Reset retains; delete removes. |
| `backup.enabled/dirty/lastSuccessfulRevision/lastSuccessfulSyncAt` | Device save | Until changed/delete | Reset retains backup preference/metadata; delete removes. |

No earned-stamp, power, chapter-progress, discovery, score, attempt, or unlock arrays are stored. They are derived from the current manifest plus known mission states so they cannot drift or duplicate.

## Optional backup-owned row — disabled

No cloud table or client is implemented in this wave. If `BE-040+` is later enabled, the only eligible application row is `game_saves(id, owner_id, trip_key, content_version, state, revision, updated_at)`. `state` is the exact validated envelope above; the server owns `id`, `owner_id`, `revision`, and `updated_at`. Remote deletion removes the row; local play remains intact until the parent separately deletes the device save.

Email, auth sessions, and tokens never enter the save row, export, fixtures, logs, or static content. Any future Supabase Auth identity remains an authentication-system concern reviewed under `BE-043`, not gameplay data.

## Ephemeral-only runtime values

Foreground coordinates, accuracy, permission result, current network status, answer selection before submit, and wrong-answer attempts may exist in memory only for the active interaction. They are discarded on navigation/reload and never enter IndexedDB, export, URLs, logs, analytics, or backup.

## Prohibited persisted data

Precise user location; GPS samples; route/breadcrumb history; photos, bytes, URLs, paths, EXIF, faces, or voices; full name, surname, birthday, exact age, school, biography, or free-form child profile; email; child login; access/refresh/auth tokens; password or key; device/advertising/analytics identifiers; answer or activity telemetry; chat/social content. Validation also rejects binary/base64 media and saves above 256 KiB.

## Recorded decisions

| Decision | Resolution |
|---|---|
| `DEC-B01` | Optional Supabase package may be added later, disabled by default and outside the local critical path. |
| `DEC-B02` | No email is hard-coded or requested; runtime parent auth is deferred. |
| `DEC-B03` | Whole-save conflicts require a parent choice; no automatic field merge. |
| `DEC-B04` | V1 delete removes game data and signs out; Auth-user administration stays out of the client. |
