# Install and browser use

Installation is optional; the canonical Pages URL remains fully usable in the browser.

1. Load the production URL once while online and wait for the offline-ready message.
2. Android Chrome: use the browser menu and choose **Install app** when offered.
3. iPhone Safari: use **Share → Add to Home Screen**. Do not expect an Android-style automatic install prompt.
4. Launch from the Home Screen, then repeat in airplane mode before travel.

The initial platform build supports 320–430 CSS-pixel phone widths in portrait. Larger browsers show the same phone canvas for testing; no tablet/desktop experience is promised in V1.

When an update is waiting, use **Update when ready** only between activities. The service worker never forces an automatic mid-mission reload.

