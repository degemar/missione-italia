# Child-first component behavior contract

**Depends on:** [`design-tokens.md`](design-tokens.md), [`ux-screen-state-contract.md`](ux-screen-state-contract.md)  
**Applies to:** 320–430 CSS px, touch-first with keyboard/switch and screen-reader parity

Components are built for one-handed parent operation and three children sharing one screen. A child state has one dominant action. Parent-only controls carry a lock icon, `ADULT` label, squared radius, and explicit accessible name; this is a deliberate-mode distinction, not security.

## Shared interactive states

| State | Visual and behavior contract | Accessible contract |
|---|---|---|
| Default | Solid outline and surface; target at least 48×48 px | Name, role, and purpose are available before focus |
| Pressed | Immediate ≤80 ms inset/scale or surface change; content does not move position | `aria-pressed` only for toggles; activation occurs once |
| Keyboard focus | 3 px focus ring with 2 px paper gap; never removed or clipped | Logical order; Enter/Space parity where native behavior supports it |
| Selected | Strong border + persistent indicator icon/shape + text such as “Selected” | Selected/current state is programmatically exposed |
| Disabled | Muted surface, text remains legible, no focus; only when truly unavailable | Native disabled state plus nearby reason; never used for offline/GPS fallback |
| Loading | Keep component width; label changes to a verb such as “Saving”; one nonessential indicator | `aria-busy=true`; no indefinite child spinner; cancellation when safe |
| Success | Persistent check/icon + short success text; motion optional | Polite live announcement; focus remains predictable |
| Error | Specific recovery text + icon + border; never shake-only or color-only | Error is associated with its control; focus moves only for blocking parent errors |

Wrong child answers are not system errors. Use: **“Take another look.”** Keep all children anonymous, keep points unchanged, reveal a small hint if provided, and allow immediate retry.

## Applicability matrix

`✓` means the shared state is required; `—` means not meaningful for that component. Display components still expose their current semantic state.

| Component | Default | Pressed | Focus | Selected | Disabled | Loading | Success | Error |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| Button | ✓ | ✓ | ✓ | ✓ toggle only | ✓ | ✓ | ✓ | ✓ |
| Mission card | ✓ | ✓ | ✓ | ✓ current | ✓ locked only | ✓ save/update only | ✓ resolved | ✓ content recovery |
| Role clue card | ✓ | ✓ reveal | ✓ | ✓ active role | ✓ | — | ✓ role done | — |
| Answer choice | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ checking | ✓ correct | ✓ system only |
| Progress compass | ✓ | — | ✓ if interactive | ✓ active segment | — | ✓ restore | ✓ power restored | ✓ save recovery |
| Chapter tab | ✓ | ✓ | ✓ | ✓ current | ✓ unavailable only | — | ✓ complete | ✓ content recovery |
| Badge/stamp | ✓ | ✓ if details | ✓ if details | ✓ earned | ✓ unavailable detail | ✓ award commit | ✓ save recovery |
| Bottom sheet | ✓ | — | ✓ descendants | ✓ choice row | ✓ descendants | ✓ | ✓ | ✓ |
| Dialog | ✓ | — | ✓ descendants | ✓ choice row | ✓ descendants | ✓ | ✓ | ✓ |
| Banner | ✓ | ✓ action | ✓ action | — | ✓ action | ✓ | ✓ | ✓ |
| Toast | ✓ | ✓ action | ✓ action | — | — | — | ✓ | ✓ |
| Parent entry | ✓ | ✓ hold | ✓ | ✓ hold complete | ✓ | ✓ hold progress | ✓ opens confirm | ✓ cancelled/interrupted |
| Nickname field | ✓ | ✓ | ✓ | ✓ active | ✓ | ✓ save | ✓ valid | ✓ correction |

## Component specifications

### Button

- Variants: one child primary, child secondary, quiet text, parent, and destructive parent.
- Only one primary appears in the active state. It is full available width, preferably 56 px high, and reachable near the bottom without covering content or attribution.
- Icon-only buttons are limited to familiar Back/Close/Audio controls, remain 48×48 px, and have visible tooltip text where hover exists plus an accessible name everywhere.
- Loading does not erase the verb. Success is not required before navigation when the destination itself confirms success.
- Destructive buttons never share a cluster with routine actions.

### Mission card

- Anatomy: chapter/power marker, mission title, duration/energy label, cooperative status, and one clear affordance. No logistics metadata.
- Current selection uses a border, pointer/notch shape, and “Current clue”; completion uses the exact `completed`, `manual`, or `skipped` label/icon/shape token.
- Locked means story order only, never GPS, ticket, cloud, or individual achievement. TBC slots are not locked: they show **Mystery route** and parent/manual/skip paths.
- The whole card may be one link; nested buttons are prohibited.

### Role clue card

- Always shows role label + Phosphor icon + geometric marker + short action. Color is supplemental.
- Spotter, Detective, and Navigator cards are equal-status; visual order follows mission content and may rotate without implying rank.
- Tap may reveal one clue at a time. “Role done” is a local cooperative check only and does not score a child.
- Parent reassignment changes the nickname association without penalty or celebration.

### Answer choice

- Entire row is a minimum 48 px target. Prefer 2–4 short text choices; optional image content must have equivalent text.
- Single selection uses a native-radio semantic. Selected state has a filled marker shape, 3 px outline, bold label, and accessible `checked`; it remains clear with color removed and motion disabled.
- **Check answer** is separate so exploration does not instantly submit. Correct gives a persistent check and success line. Incorrect gives “Take another look,” an eye/hint icon, and retry; no red cross, buzz, shake, loss, timer, or named child.
- If checking fails technically, keep the selected choice and offer retry or manual completion.

### Progress compass

- It is story progress, not navigation. Segment count equals `manifest.chapters.length`; each segment uses chapter label, marker shape, icon/motif reference, and semantic accent.
- Three and four entries use the same radial/flexible component with no empty segment or geometry branch. Unknown IDs use `semantic.chapter.default`. `RETURN-EP` is a separate home arrow, never a segment.
- Static text states include “2 of 4 powers awake.” Restored segments remain understandable with motion off and in monochrome.
- Bussola art is a future provenance-approved asset; until then implementation uses functional text/icon UI, not fake mascot art.

### Chapter tabs

- Render exactly the ordered manifest chapters with stable ID keys. For three or four entries, use one equal-width flexible row; labels may wrap to two lines but never truncate.
- Each tab is at least 48 px high and shows label plus marker shape. Current uses `aria-current`; complete adds a check and “Complete” accessible text.
- At 200% zoom the tablist may become a vertical list without changing order or meaning; the page itself never scrolls horizontally.
- The epilogue is a separate Home arrow action.

### Badge / stamp

- Stamps belong to the family. Anatomy: original future illustration, stamp name, earned/not-earned state, and mission association.
- Until final assets exist, use a named functional icon and text in implementation—not emoji, CSS/SVG imitation, or placeholder art.
- Award only after the completion transaction succeeds locally. Manual and skipped resolutions may show their completion marker without pretending the place-specific stamp was observed; exact reward policy follows `docs/rewards-passport.md`.
- Detail is optional; an unearned stamp never teases a child with scarcity or comparison.

### Bottom sheet

- Use for contextual parent choices, hints, completion fallback, or location explanation—not long reading.
- Opens with labelled heading; focus enters the heading/first control, background becomes inert, and Close returns focus to the invoker.
- It respects bottom safe area and browser chrome, can scroll internally, and never traps the primary action below the visible viewport.
- Swipe-to-dismiss is optional; Close/Back is always available. An unfinished destructive action cannot be dismissed into accidental confirmation.

### Dialog

- Reserve for destructive confirmation, adult confirmation, or truly blocking recovery. Routine story choices use a page or sheet.
- Title names the consequence. Body names what stays and what goes. Primary repeats the destructive verb; **Keep everything** is the safe close action.
- Focus is trapped while open and initially lands on the safe action. Escape/system Back closes unless a local transaction is actively committing.
- No fake PIN, countdown, trick wording, or preselected destructive choice.

### Banner

- Persistent, in-flow state for offline-ready/degraded, denied location, pending update, or save recovery.
- Child-safe informational banners are calm; parent-recovery banners carry `ADULT`. Icon + heading + one sentence convey state without color.
- At most one action; it remains until resolved or explicitly dismissed. It never overlays chapter content or map attribution.

### Toast

- Use only for noncritical confirmation such as “Adventure saved.” It cannot be the sole record of completion, error, permission, or destructive outcome.
- Polite live region; no focus steal. Minimum five seconds when text-only; action toasts remain until dismissed or acted upon.
- Position above the sticky action and safe area. Reduced motion uses a brief fade only.

### Press-and-hold parent entry

- Touch label: lock icon + `ADULT` + **Hold for adult**. Hold duration is 900 ms with visible progress and gentle haptic only if already permitted by the platform.
- Releasing, pointer-cancelling, scrolling, app backgrounding, or moving outside the target cancels without side effect. Success opens an adult confirmation, then Parent Corner.
- Keyboard users may hold Space/Enter; screen-reader/switch activation opens the explicit adult confirmation directly. The gate prevents accidents, not children, and makes no security claim.
- Loading/hold progress is conveyed by text and `aria-valuenow`, not an unlabeled ring. Reduced motion replaces radial travel with a numeric/filled static progress change.

### Nickname field

- Plain text only; no age, avatar upload, surname, email, or account field. Label remains visible while typing.
- Empty fields beyond the first are allowed. Validation explains duplicates/length in parent-readable language without blocking play unnecessarily.
- Keyboard never hides the current field or primary action; save occurs locally before leaving Setup.

## Responsive, outdoor, and PWA invariants

- From 320×568 to 430×932 CSS px, controls do not clip or require page-level horizontal scroll. Landscape keeps the active instruction and primary action available.
- Bright-light legibility uses solid surfaces, strong outlines, and the contrast pairs in `design-tokens.json`; texture/shadow never carries state.
- Sticky controls use dynamic viewport units and safe-area tokens. Browser and standalone modes share component markup and semantics.
- At 200% zoom, controls grow/reflow, the primary remains reachable, and text is not ellipsized.
- No component introduces booking, schedule, ticket, parking, weather, route-planning, or background-tracking UI.

