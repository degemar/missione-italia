# Story Content Contract

**Contract version:** `0.1.1` additive foundation revision · **Backend review:** required before freeze · **Canonical bundle:** `public/content/trip-manifest.json`

This is the normative Story-to-product contract through Story Wave 1. The additive fields below do not change mission IDs, completion states, local-save shape, storage version, or cloud behavior.

## Top-level manifest

Required keys: `schemaVersion`, `contentVersion`, `tripKey`, `status`, `generatedAt`, `minimumAppVersion`, `minimumStorageVersion`, `calendarAuthority`, `sourceRegister`, `rewardRegister`, `assetRegister`, `locales`, `privacy`, `dependencies`, `excludedContent`, `epilogueMissionId`, `narrative`, `chapters`, `excursionSelection`, `missions`.

- `contentVersion` is `trip-2026.10-v1`; it is content identity, not the final freeze/hash.
- `calendarAuthority` must be `planning/TRIP_CALENDAR.md`.
- `excludedContent` must include `gardaland`; exclusion means no chapter, mission, map point, reward, source task, or asset.
- `missions` contains exactly 16 records with `scored: true` and one Saturday epilogue with `scored: false`.

## Runtime narrative record

`narrative.opening` contains `storyBeat`, `youngestAction`, `familyOath`, and exactly three `tutorialSteps`. `narrative.states` supplies interruption, resume, skip, manual, retry, offline, closed-venue, tired-legs, bad-weather, both ending variants, and Monday-silent copy. These strings are content authority; components must not carry alternate story wording.

## IDs and ordering

- IDs are permanent, case-sensitive, and never reused: `ROAD-01`–`03`, `VEN-01`–`04`, `ISL-01`–`03`, `VER-01`–`06`, `RETURN-EP`.
- `order` is the calendar display order. UI must not infer order from filenames or IDs.
- Chapter `missionIds` must resolve exactly once. The epilogue is referenced by `epilogueMissionId`, not by a fifth power chapter.

## Chapter record

Required: `id`, `order`, `dateRange`, `title`, `power`, `status`, `missionIds`, `openingBeat`, `closingBeat`.

`status` is `fixed`. A power unlocks when every listed mission is resolved as `completed`, `manual`, or `skipped`; at least one mission should be completed/manual unless a parent overrides the whole chapter.

## Mission record

Required keys:

`id`, `order`, `chapterId`, `date`, `scored`, `title`, `status`, `durationMinutes`, `energy`, `storyBeat`, `objective`, `location`, `roles`, `choices`, `facts`, `completion`, `fallbacks`, `safety`, `reward`, `sourceIds`, `fact_checked_on`, `review_after`, `offlineCritical`, `dependencies`.

Optional `assetIds` defaults to `[]`; every supplied ID must resolve in `assetRegister`. This additive Backend field allows missing-asset validation while final art is pending. Optional `phrases` and `variants` retain their current Story meanings.

Rules:

- `title`, `storyBeat`, `objective`, role actions, choices, facts, fallbacks, safety, and reward copy are content—not component literals.
- `storyBeat` is the 30–60 second parent-read script and must contain 50–110 words in this package.
- `location.mode` is `parent-selected`; GPS coordinates are optional hints only and never unlock content.
- `roles` contains exactly one `spotter`, one `detective`, and one `navigator` action. Roles can be swapped.
- `facts[].label` is one of `FACT`, `TRADITION`, `LEGEND`, `OUR STORY`; every external fact/tradition/legend has a `sourceId` resolving in `sources.json`. `OUR STORY` has no source.
- `sourceIds` is the unique union of factual and parent-only visitor source IDs needed by the mission/variants. Every external fact's `sourceId` must appear; extra operational source IDs are allowed.
- `completion.allowedStates` is exactly `completed`, `manual`, `skipped`. No state is failure.
- `completion.retryLine`, `completion.explanation`, and `completion.successLine` provide the kind retry, short answer/observation resolution, and reward line.
- `fallbacks` contains non-empty `noGps`, `closedVenue`, `badWeather`, and `tiredLegs` strings.
- Mission `dependencies.gps`, `audio`, `ticket`, and `liveData` are all `false`. Operational advice can still ask a parent to recheck a source.
- `offlineCritical` is `true` for every scored mission and the epilogue.
- `fact_checked_on` records the editorial/source review date. `review_after` is the earliest required recheck and cannot precede it.
- If present, `phrases` contains no more than five English-complete Italian records with `it`, `en`, `pronunciation`, and non-verbal `gesture` fields.

## Choices and excursion slots

Ordinary missions use `choices: []`. A destination-independent mission uses observation/manual completion rather than fake answer options.

`VER-04` and `VER-05` are stable **manifest slots**. `excursionSelection.status` remains `tbc`; `selectedPairId` is `null`. Candidate pairs are:

- `sigurta-borghetto` (recommended): morning Sigurtà, afternoon Borghetto.
- `sirmione-lazise`: morning Sirmione, afternoon a low-pressure Lazise spotter.
- `verona-rain`: Natural History Museum/manual morning, prebooked Children’s Museum/manual afternoon.

Each slot has a `variants` array whose records carry stable `id` and `pairId` keys plus the same playable story, objective, three roles, choices, facts, completion copy, four fallbacks, safety, source, and review-date fields needed by a fixed mission. Choosing a pair swaps content inside the existing mission record; it never creates a new mission, state type, route engine, or score. If no pair is selected, the parent can choose a variant locally, complete manually, or skip. `VER-06` remains reachable.

## Reward contract

`reward.stamp` resolves to one of six keys in `docs/rewards-passport.md`. `reward.power` is the chapter power or `null`. Rewards belong to the team. The app must not compute sibling scores, ranks, streaks, or missed badges.

## Localization and privacy

- `locales.default` is `en`; `locales.phraseLayer` contains `it`.
- Every future user-visible string receives a localization key; variables are whole tokens, never concatenated fragments.
- Only nicknames may be stored. Content never requests surnames, birthdays, faces, voices, schools, or child accounts.

## Canonical example and validation

`public/content/examples/mission.example.json` is the canonical fixed-mission record. `schemas/content/v1` expresses the additive fields and `scripts/validate-contracts.mjs` checks required keys, read time, narrative states, review dates, role/completion/fallback invariants, references, exclusions, dependency booleans, and the 16+1 count. Backend must confirm the additive profile before freeze; no save or cloud contract changes are requested.
