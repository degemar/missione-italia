# Verona for Kids reference review

**Reviewed:** 30 September 2026 · **Scope:** official public material only

The official tourism board confirms two municipal treasure-hunt maps. **Cerca in città** covers the historic centre inside the Adige bend; **Cerca oltre l'Adige** covers Veronetta. The maps are physical material collected from the IAT office at Via Leoncino 61. The official site does not expose the two map files or their clue text for download.

Sources: [official two-map description](https://www.visitverona.it/en/plan/school-trips-to-verona), [official route overview](https://www.visitverona.it/it/esperienze/verona-for-kids-caccia-al-tesoro-1), [official brochure record](https://www.visitverona.it/en/brochures/verona-for-kids-city-treasure-hunt).

## What can be compared now

| Official material observable online | Possible geographic overlap | Missione Italia boundary |
|---|---|---|
| Two self-guided paper routes; search for culturally important sites/details | Historic centre overlaps the broad Arena/Piazza Erbe area | We use original Bussola story, stable missions, and three cooperative age roles; no official clue or reward wording is copied |
| A route inside the Adige bend | `VER-01` and `VER-02` occur in the same broad city area | Our clues are repeating Arena arches and FACT/TRADITION/OUR STORY sorting, derived from cited place facts |
| A route in Veronetta beyond the Adige | `VER-03` uses the river/Ponte Pietra corridor | Our five-arch compare/view/card mechanic is original and can be completed without following a paper route |
| Finish-and-return prize mechanic | None | No promised IAT prize, fastest finish, or completion pressure appears in the app |

Official online example itineraries such as [An invitation to Verona](https://www.visitverona.it/en/poi/an-invitation-to-verona) and [Give us a smile](https://www.visitverona.it/en/poi/give-us-a-smile) were reviewed only for the municipality's general family-exploration pattern. Their sequence, prose, questions, indoor objects, and clue wording are not reused.

## Original-clue declaration

Missione Italia independently uses:

- Spotter, Detective, and Navigator contributions on one shared phone;
- exterior-first Arena and Juliet play;
- source-labelled FACT, TRADITION, LEGEND, and OUR STORY cards;
- untimed observation, manual completion, tired/weather/card alternatives, and no child competition;
- no dependency on collecting the official maps or prize.

## Evidence limitation

`ST-045` is **partial**, not complete: both map identities and broad route mechanics are verified, but exact clue-by-clue overlap cannot be logged until a parent obtains the physical maps at IAT. Do not infer unseen clues. If maps are collected, compare landmark names and mechanics only; never transcribe or photograph their clue text into the product.
