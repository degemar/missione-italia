# Local storage and recovery

**Authority:** `BE-021`–`BE-024` · **Implementation:** `src/storage` · **Cloud:** absent

React code consumes `LocalSaveRepository`; it must not access IndexedDB directly. Every method works without a network, account, map, or Supabase client.

## Database plan

| Item | Value | Purpose |
|---|---|---|
| Database | `missione-italia-local` | Local game data only |
| Database version | `1` | Native IndexedDB structure version; independent of save schema version |
| `saves` | key `tripKey` | One canonical save per trip, including an integrity hash |
| `recovery` | key `id` | At most three prior records per trip |
| `outbox` | key `tripKey` | One coalesced revision marker; never a save payload or event log |

All stores participate in one read/write transaction. A mutation is validated and reconciled, the prior canonical record is copied when present, the new canonical record and optional outbox marker are written, and old recovery records are pruned. The promise resolves only after IndexedDB reports transaction completion. Calls are serialized, so rapid taps, background/foreground boundaries, and duplicate completion calls cannot interleave.

The internal integrity value is a deterministic corruption check, not a security signature. Portable exports use SHA-256.

## Durability and signals

| Repository result | Parent-facing behavior |
|---|---|
| `persistent` | The commit completed in IndexedDB. |
| `memory-only / unavailable` | “Progress works for now but is not saved after this app closes.” |
| `memory-only / quota` | “This device is low on storage. Progress continues for now but may be lost when the app closes.” |
| `memory-only / storage-error` | “Progress continues for now but could not be saved on this device.” |
| `warning: corrupt-canonical` | A validated recovery copy was restored; tell the parent. |
| `warning: newer-schema` | Read-only recovery state; never downgrade or overwrite. |
| `warning: invalid-save` | Do not reset silently; open parent recovery. |

IndexedDB open/write failure switches to an explicit in-memory repository and retries the action. It never reports `persisted: true`. `requestPersistentStorage()` is the only path to `navigator.storage.persist()`; Frontend may call it only from a parent gesture. Unsupported or denied requests are non-blocking.

## Migration and content reconciliation

Storage migrations are ordered in `STORAGE_MIGRATIONS`. The candidate is migrated and validated in memory, then the raw prior record and migrated canonical record are committed atomically. A failed migration leaves the old canonical record untouched; a valid older snapshot is restored when available and can immediately be exported. Future schema versions are read-only.

Compatible content changes retain stable mission progress, preserve removed mission IDs in the serialized save, exclude those IDs from active progress, and recover an unknown route to Atlas. An incompatible trip/content version is rejected. Excursion choices remain stable manifest IDs; no day-trip choice is hard-coded.

## Export, import, and deletion

- Export contains one validated save plus human label, format/storage/content versions, UTF-8 byte count, timestamp, and SHA-256 checksum.
- Import checks the outer format, byte ceilings, metadata/payload agreement, checksum, storage migration, trip key, content compatibility, and save contract before returning a preview.
- Replacement requires that unchanged preview, snapshots the current canonical record, and commits atomically.
- `resetProgress()` keeps family/settings and clears gameplay. `deleteLocalTripData()` removes and verifies canonical, recovery, and outbox data for one trip.
- Neither reset nor delete can touch bundled/service-worker-cached static content.
- No precise location, route history, photos, email, auth token, analytics/device ID, detailed attempt, or free-form child data is accepted or exported.

## Parent recovery runbook

| Event | What the app can know | Recovery action |
|---|---|---|
| Corrupt newest save | Integrity/validation fails | Restore newest valid local snapshot, show `RECOVERY`, then make a JSON export. |
| Failed migration | Candidate validation fails | Keep the prior record; restore a valid snapshot if present. Do not reset. Export the restored save before retrying an updated app. |
| Quota/write failure | IndexedDB operation fails | Continue memory-only with the parent warning. Free device space, keep the app open, export if a valid local save remains, then retry. |
| Browser data cleared | Local database is missing | Browser clearing is destructive and cannot be reversed locally. Import the latest JSON export. |
| PWA removed | Browser-dependent; storage may remain or be removed | Reopen the same site first. If progress is absent, reinstall and import the latest JSON export. |
| OS/browser eviction | Local database is missing; standards expose no reliable cause | Treat as a fresh local store and import the latest JSON export. |
| Manual JSON restore | Parent selects a prior export | Preview trip/content/version and progress counts; replace only after explicit confirmation. The displaced save becomes a recovery snapshot. |

Before travel, keep one recent validated JSON export outside browser storage. This is the only recovery that survives deliberate browser-data clearing or storage eviction; optional cloud work remains disabled and outside this wave.
