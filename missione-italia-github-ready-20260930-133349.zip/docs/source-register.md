# Authoritative Source Register

**Machine source:** `public/content/sources.json`  
**Checked:** 30 September 2026  
**Policy:** child-facing facts use official destination, municipality, museum, venue, or transport sources. Search snippets were discovery aids only; the linked pages are the evidence. Text below is paraphrased.

`FACT`, `TRADITION`, `LEGEND`, and `VISITOR` are different claim types. Visitor claims are volatile and stay in Parent Corner. Mission fiction lives in `docs/story-bible.md` and is never presented as sourced history.

| ID | Type | Claim | Authority | Recheck | Used by |
|---|---|---|---|---|---|
| `SRC-VEN-LION-01` | FACT | Winged lion of Saint Mark is a Venice symbol. | [Venezia Unica — Castello](https://www.veneziaunica.it/en/things-to-do-in-venice/itineraries/castello-naval-art-and-traditions) | 3 Oct | `VEN-01` |
| `SRC-VEN-RIALTO-01` | FACT | Rialto Bridge dates to 1588–1592 and was the Grand Canal’s only bridge until the 1800s. | [Venezia Unica — Rialto Bridge](https://www.veneziaunica.it/en/things-to-do-in-venice/monuments-and-theatres/rialto-bridge) | 3 Oct | `VEN-02` |
| `SRC-VEN-TRANSIT-01` | VISITOR | ACTV water transport and lagoon lines serve Murano/Burano. | [Venezia Unica — Public transport](https://www.veneziaunica.it/en/things-to-do-in-venice/public-transport) | 6 Oct | `ISL-02` |
| `SRC-ISL-MURANO-01` | FACT | Murano is known for glassmaking workshops. | [Venezia Unica — Murano](https://www.veneziaunica.it/en/things-to-do-in-venice/venice-areas/islands/murano) | 3 Oct | `ISL-01` |
| `SRC-ISL-GLASS-01` | FACT | The Glass Museum dates to 1861 and preserves centuries of island production. | [MUVE — Glass Museum](https://museovetro.visitmuve.it/en/il-museo/museum/) | 3 Oct | `ISL-01` |
| `SRC-ISL-BURANO-TRAD-01` | TRADITION | Bright houses are traditionally linked to fishers recognising home in fog. | [Venezia Unica — Burano](https://www.veneziaunica.it/en/things-to-do-in-venice/venice-areas/isole/burano) | 3 Oct | `ISL-03` |
| `SRC-ISL-BURANO-FACT-01` | FACT | The house-colour practice is described as comparatively recent and boundary-related. | [Venezia Unica — Burano](https://www.veneziaunica.it/en/things-to-do-in-venice/venice-areas/isole/burano) | 3 Oct | `ISL-03` |
| `SRC-ISL-BURANO-LEG-01` | LEGEND | A local tale imagines sea foam becoming a lace veil. | [Venezia Unica — Burano](https://www.veneziaunica.it/en/things-to-do-in-venice/venice-areas/isole/burano) | 3 Oct | `ISL-03` |
| `SRC-ISL-LACE-01` | FACT | The Lace Museum occupies the historic 1872 school and documents several centuries. | [Venezia Unica — Lace Museum](https://www.veneziaunica.it/en/things-to-do-in-venice/civic-museums-of-venice/lace-museum) | 3 Oct | `ISL-03` |
| `SRC-VER-ARENA-01` | FACT | Romans built the Arena around the mid-first century AD. | [Visit Verona — Arena](https://www.visitverona.it/en/poi/arena-amphitheatre) | 3 Oct | `VER-01` |
| `SRC-VER-ARENA-VISIT-01` | VISITOR | Official 2026 calendar currently lists 15:00 closing on 8 Oct. | [Visit Verona — Arena](https://www.visitverona.it/en/poi/arena-amphitheatre) | 7 Oct | `VER-01` |
| `SRC-VER-JULIET-FACT-01` | FACT | House documented 1351; acquired 1905; balcony added in 1939–40 restoration. | [Visit Verona — Juliet’s House](https://www.visitverona.it/en/poi/juliet-s-house-and-museum) | 3 Oct | `VER-02` |
| `SRC-VER-JULIET-STORY-01` | TRADITION | The site’s Juliet association followed literary versions and later identification. | [Visit Verona — Juliet’s House](https://www.visitverona.it/en/poi/juliet-s-house-and-museum) | 3 Oct | `VER-02` |
| `SRC-VER-JULIET-VISIT-01` | VISITOR | 2026 route enters through Teatro Nuovo; house visits require online booking. | [Visit Verona — Juliet’s House](https://www.visitverona.it/en/poi/juliet-s-house-and-museum) | 7 Oct | `VER-02` |
| `SRC-VER-PONTE-01` | FACT | Ponte Pietra has five arches and is pedestrian/bicycle only. | [Visit Verona — Ponte Pietra](https://www.visitverona.it/en/poi/ponte-pietra) | 3 Oct | `VER-03` |
| `SRC-VER-ERBE-01` | FACT | Piazza Erbe is Verona’s oldest square, on the Roman forum area. | [Visit Verona — Piazza Erbe](https://www.visitverona.it/en/poi/piazza-erbe) | 3 Oct | `VER-02` |
| `SRC-TRIP-VALEGGIO-01` | VISITOR | Valeggio/Borghetto are one cluster, described as about 30 minutes from Verona. | [Visit Verona — Valeggio and Borghetto](https://www.visitverona.it/en/explore/a-magical-mix-of-history-and-countryside) | 8 Oct | `VER-04`, `VER-05` |
| `SRC-TRIP-BORGHETTO-01` | FACT | Borghetto has stone houses, old water mills, and Ponte Visconteo. | [Visit Verona — Valeggio and Borghetto](https://www.visitverona.it/en/explore/a-magical-mix-of-history-and-countryside) | 3 Oct | `VER-05` |
| `SRC-TRIP-KNOT-LEG-01` | LEGEND | The Lover’s Knot tale links tortellini with Silvia, Malco, and knotted silk. | [Visit Verona — Valeggio and Borghetto](https://www.visitverona.it/en/explore/a-magical-mix-of-history-and-countryside) | 3 Oct | `VER-05` |
| `SRC-TRIP-SIGURTA-VISIT-01` | VISITOR | 2026 season runs through 15 Nov; October closes 18:00, last entry 17:00. | [Sigurtà — FAQ](https://www.sigurta.it/faq) | 8 Oct | `VER-04` |
| `SRC-TRIP-SIGURTA-RAIN-01` | VISITOR | Heavy rain can suspend internal vehicles; severe storms can close the park. | [Sigurtà — FAQ](https://www.sigurta.it/faq) | 8 Oct | `VER-04` |
| `SRC-TRIP-SIRMIONE-01` | FACT | Fourteenth-century castle has walls, battlements, walkways, and a harbour. | [Visit Sirmione — Scaligero Castle](https://visitsirmione.com/en/what-to-see/art-and-monuments/scaliger-castle/) | 3 Oct | `VER-04` candidate |
| `SRC-TRIP-SIRMIONE-PARK-01` | VISITOR | Historic-centre vehicle access is limited; Monte Baldo is the main old-town car park. | [Visit Sirmione — Parking](https://visitsirmione.com/en/info/parking/) | 8 Oct | `VER-04` candidate |
| `SRC-TRIP-SIRMIONE-HOURS-01` | VISITOR | Institutional page currently lists Friday 08:30–19:15 and outlying parking. | [Italian Ministry of Culture — Castle](https://museilombardia.cultura.gov.it/en/museums/rocca-scaligera-di-sirmione/) | 8 Oct | Friday run sheet |
| `SRC-TRIP-LAZISE-01` | FACT | Public historic centre retains Scaliger walls/gates beside the old harbour. | [Municipality of Lazise](https://www.comune.lazise.vr.it/vivere-il-comune/territorio/english/) | 3 Oct | `VER-05` candidate |
| `SRC-VER-MOBILITY-01` | VISITOR | Historic centre is largely ZTL; official page lists outside/nearby car parks. | [Visit Verona — Getting around](https://www.visitverona.it/en/plan/how-will-you-get-around) | 7 Oct | parent run sheet |
| `SRC-VER-KIDS-MAPS-01` | VISITOR | Two municipal treasure-hunt maps are collected at IAT Via Leoncino 61. | [Visit Verona — School trips](https://www.visitverona.it/en/plan/school-trips-to-verona) | 3 Oct | `ST-045` |
| `SRC-VER-KIDS-ROUTES-01` | VISITOR | Official overview names city-centre and Veronetta routes. | [Visit Verona — Caccia al tesoro](https://www.visitverona.it/it/esperienze/verona-for-kids-caccia-al-tesoro-1) | 3 Oct | `ST-045` |
| `SRC-LANG-CIAO-01` | FACT | Familiar meeting/parting greeting. | [Treccani — ciao](https://www.treccani.it/vocabolario/ciao/) | 30 Sep 2027 | `ROAD-03` |
| `SRC-LANG-BUONGIORNO-01` | FACT | Morning greeting. | [Treccani — buongiorno](https://www.treccani.it/vocabolario/ricerca/buongiorno/) | 30 Sep 2027 | `ROAD-03` |
| `SRC-LANG-GRAZIE-01` | FACT | Thanks; pronunciation /'gratsje/. | [Treccani — grazie](https://www.treccani.it/vocabolario/grazie/) | 30 Sep 2027 | `ROAD-03` |
| `SRC-LANG-FAVORE-01` | FACT | `Per favore` is a courtesy request formula. | [Treccani — favore](https://www.treccani.it/vocabolario/favore/) | 30 Sep 2027 | `ROAD-03` |
| `SRC-LANG-ARRIVEDERCI-01` | FACT | Parting greeting; stress marked on `-der-`. | [Treccani — arrivederci](https://www.treccani.it/vocabolario/arrivederci/) | 30 Sep 2027 | `ROAD-03` |
| `SRC-RAIN-NATURAL-01` | VISITOR | Natural History Museum currently lists Tue–Sun 10:00–18:00. | [Municipality of Verona — Natural History Museum](https://museodistorianaturale.comune.verona.it/nqcontent.cfm?a_id=43639&lang=en) | 8 Oct | rain fallback |
| `SRC-RAIN-CMV-01` | VISITOR | Children’s Museum serves ages 0–12 in limited 1h45 sessions. | [Children’s Museum Verona](https://www.cmverona.it/home/) | 8 Oct | rain fallback |
| `SRC-RAIN-NICOLIS-01` | VISITOR | Tue–Fri access after 1 Oct requires a booked group of 20+. | [Museo Nicolis — Info and Tickets](https://www.museonicolis.com/en/info-and-tickets/) | 8 Oct | exclusion note |

## Recheck protocol

- **2–3 October:** all stable child facts plus current Venice/MUVE notices.
- **6 October:** parent checks ACTV route and service immediately before the island day; no timetable appears in child copy.
- **7 October:** Arena and Juliet visitor notices.
- **8 October:** whichever Friday candidate, parking/closure/weather, and any booked indoor fallback.
- If a volatile source cannot be confirmed, hide its operational claim and keep the no-ticket/manual mission variant.
