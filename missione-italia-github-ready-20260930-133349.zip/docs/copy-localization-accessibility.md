# Copy, localization, read-aloud, and equivalents

**Prepared:** 30 September 2026 · **Tasks:** `ST-050`–`ST-056`

## Runtime authorities

- Static interface copy and stable keys: `src/i18n/strings.ts`.
- Story, objectives, role actions, hints, answers, safety, facts, success/retry lines, and Italian cards: JSON paths in `public/content/trip-manifest.json`.
- Reward labels: `public/content/rewards.json`.
- Components were checked for raw visible JSX text; visible interface copy routes through the string catalog or manifest. Technical error strings are not child UI.

Do not concatenate sentence fragments. Interpolate only whole templates. Keep canonical place names unchanged.

## `ST-050` child-facing microcopy sheet

| State | Stable keys/paths | Required copy behavior |
|---|---|---|
| Welcome/setup | `welcome.*`, `setup.*`, `avatar.*` | Nicknames only; action-led **Begin adventure**, **Meet Bussola**; validation states the exact fix |
| Opening/Atlas/chapter | `opening.*`, `atlas.*`, `chapter.*` | No planner language, no score pressure; unresolved Friday says **Mystery route / Parent chooses later** |
| Mission/story/look-up | `mission.*`, `story.*`, `lookup.*` plus mission paths | **Hear the story**, **Look up**, **We're ready**; safety precedes real-world action |
| Challenge/answer | `challenge.*` plus `choices[*]`, `completion.*` | No timed response; wrong answer says **Take another look** and keeps retry/manual/skip available |
| Fallbacks | `fallback.*`, `narrative.states.*`, `fallbacks.*` | No shame or reason collection; **Done another way** and **Save for later** have equal progression |
| Celebration/Passport | `celebration.*`, `passport.*`, reward registry | Shared family result; no zero, rank, sibling score, streak, or percentage |
| Offline/error/empty | `app.offline*`, `status.*`, `recovery.*`, Passport empty keys | Calm, specific next action; no raw exception, network blame, or lost-progress claim |

Child primary actions are short verbs and readable aloud. Parent-only operational explanations may be longer. Buttons describe the result, never “OK” or “Submit.”

## `ST-051` family and role copy

- Setup: “Use nicknames only. A grown-up can type while children choose an explorer symbol.”
- Privacy: “No account, surname, birthday, photo, or child login is needed.”
- Rotation: “Today’s team roles” / “Rotate role names.”
- Role meaning: Spotter notices; Detective compares; Navigator helps choose from parent-approved safe options.
- Never describe a role as easiest, hardest, youngest, smartest, leader, or best. Age bands support accessible defaults only and are not spoken as rankings.
- Shared cue: “Three clues, one team.” Inclusion promise: “Nobody is left behind.”

## `ST-052` Parent Corner copy

Existing runtime keys cover deliberate adult entry, manual completion, skip, chapter session unlock, excursion pair, install/offline/update, comfort settings, diagnostics, scoped reset, and delete. Destructive confirmation is exact:

- Reset: clears mission results; retains nicknames, family setup, and comfort settings.
- Delete: removes this family's Missione Italia save/recovery/outbox marker/owned cache/diagnostic codes; does not clear other sites or browser-wide data.

Reserved stable keys for the map/location lane:

| Key | Final copy |
|---|---|
| `location.title` | Use location now? |
| `location.body` | Location helps centre the parent map once. It never unlocks a mission, runs in the background, or saves a route. |
| `location.use` | Use location |
| `location.without` | Play without |
| `location.denied` | Location was not shared. Choose a place on the map or keep playing without it. |
| `location.unavailable` | This phone could not provide a useful location. No progress was affected. |
| `location.inaccurate` | The location is approximate. Parent, choose the correct place before navigating. |
| `navigation.title` | Open external directions? |
| `navigation.body` | Missione Italia will save first, then leave this app. Live route, traffic, access, and opening information belong to the map provider. |
| `navigation.open` | Open directions |
| `navigation.stay` | Stay in app |

These keys are content input only until maps ship; current UI must not imply location or external navigation already works.

## `ST-053` read-aloud pack

The exact scripts are the manifest's `narrative.opening.storyBeat`, every mission `storyBeat`, and all six variant `storyBeat` fields. This avoids a second drifting copy. Automated word audit on 30 September found:

- opening: 58 words;
- 17 mission/epilogue scripts: 59–67 words;
- six excursion scripts: 62–67 words.

At a conservative 90 words/minute every script is under 45 seconds, leaving time for a pause and pronunciation help. Scripts contain no numeric abbreviations that must be expanded. Parent reads role names as ordinary words.

Pronunciation notes where useful: Bussola **BOOS-soh-lah**; Murano **moo-RAH-noh**; Burano **boo-RAH-noh**; Rialto **ree-AHL-toh**; Adige **AH-dee-jeh**; Verona **veh-ROH-nah**; Sigurtà **see-goor-TAH**; Borghetto **bor-GEH-toh**; Sirmione **seer-MYOH-neh**; Lazise **lah-DZEE-zeh**. Notes assist the parent and are not performance tests.

## `ST-054` Italian mini-glossary

| Italian | Meaning/use | Syllable help | Gesture / non-audio equivalent |
|---|---|---|---|
| `ciao` | hello or goodbye; familiar | **chow** | small wave |
| `buongiorno` | good morning; neutral/polite | bwohn-**JOR**-noh | rising-sun hands |
| `grazie` | thank you | **GRAHT**-tsyeh | hand over heart |
| `per favore` | please | pehr fah-**VOH**-reh | open palm |
| `arrivederci` | goodbye / until we meet again | ah-ree-veh-**DEHR**-chee | slow wave |

Meaning/stress check: [Treccani ciao](https://www.treccani.it/vocabolario/ciao/), [buongiorno](https://www.treccani.it/vocabolario/ricerca/buongiorno/), [grazie](https://www.treccani.it/vocabolario/grazie/), [favore](https://www.treccani.it/vocabolario/favore/), [arrivederci](https://www.treccani.it/vocabolario/arrivederci/). `grazie` was corrected from “GRAHT-see-eh” to the closer child-readable “GRAHT-tsyeh.” Audio-ready text is the lowercase Italian spelling; do not synthesize an accent caricature.

## `ST-055` localization catalog

| Namespace | Owner | Variables |
|---|---|---|
| `app`, `common`, `install`, `status`, `recovery` | global/platform | `resolved`, `total`, `minutes`, `energy` |
| `welcome`, `setup`, `avatar`, `opening` | onboarding | `number`, `current`, `total` |
| `atlas`, `chapter`, `mission`, `story`, `lookup`, `challenge`, `fallback`, `celebration`, `passport`, `epilogue` | child journey | `chapter`, `route`, `power`, `role`, `nickname`, `stamp`, `mission`, `pronunciation`, `gesture` |
| `role`, `adult`, `parentEntry`, `parent` | roles/adult | `progress`, `seconds`, `usage`, `quota` |
| manifest IDs and JSON fields | destination content | no fragment assembly; values are complete strings |
| reserved `location`, `navigation` | future map lane | none |

English uses explicit complete templates such as “{resolved} of {total} clues resolved”; no runtime singular/plural concatenation is allowed. Place-name glossary: Basel, Venice, Murano, Burano, Verona, Piazza Bra, Arena di Verona, Juliet's House, Piazza Erbe, Ponte Pietra, Adige, Parco Giardino Sigurtà, Valeggio sul Mincio, Borghetto, Sirmione, Scaligero Castle of Sirmione, Lazise, Natural History Museum, Children's Museum Verona.

## `ST-056` alt text, transcripts, and non-audio equivalents

- `bussola-app-icon-source`: “A brass compass on a deep lake-teal background.” Derived install icons are decorative operating-system assets and need no duplicate in-app description.
- Phosphor icons adjacent to text are decorative/`aria-hidden`; icon-only controls require the same localized accessible name as their action.
- No narration audio ships. The exact transcript is always visible `storyBeat` text; audio failure cannot hide it.
- `VEN-03` pairs colour with icon/shape; `VEN-04` sound hunt has visual or imagined-sound cards; no hearing is required.
- Every power/result uses text plus icon/shape, not colour alone. Celebration meaning persists with reduced motion and a static status.
- Every gesture has a text/card match. Speaking Italian, public performance, photography, GPS, venue entry, and animation are optional.
- Future chapter scenes/stamps require concise subject-and-purpose alt text when informative; purely atmospheric layers must use empty alt text. Unshipped planned art is not claimed as accessible runtime content.
