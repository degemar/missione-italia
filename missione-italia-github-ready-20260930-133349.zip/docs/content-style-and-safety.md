# Content Style and Safety Guide

## Length and structure

| Element | Limit |
|---|---:|
| Mission title | 5 words / 32 characters preferred |
| Child objective | 16 words |
| Child instruction | 12 words per step; maximum 3 steps |
| Answer/choice | 6 words |
| Button | 3 words |
| Fact card | 35 words |
| Safety cue | 18 words |
| Parent note | 80 words |
| Read-aloud story | 110 words / 60 seconds |

Use active verbs, concrete nouns, and one idea per sentence. Put the safe action before the playful action. Use contractions naturally. Never assemble sentences from translated fragments.

## Voice

Warm, curious, lightly mischievous, never babyish. Humor comes from Bussola’s harmless confusion, objects, patterns, and wordplay—not people, bodies, cultures, accents, fear, reading ability, or mistakes.

Preferred: “My needle has the spaghetti wobbles.”  
Avoid: “Even the little one can do this.”

## Evidence labels

- **FACT** — supported by an authoritative source. Example: “FACT: The Arena was built by the Romans around the middle of the first century AD.”
- **TRADITION** — a community account, explicitly qualified. Example: “TRADITION: People say Burano’s bright houses helped fishers recognise home in fog.”
- **LEGEND** — a story not presented as history. Example: “LEGEND: A tale says sea foam became a lace veil.”
- **OUR STORY** — invented Missione Italia canon. Example: “OUR STORY: Creativity makes Bussola’s brass stars glow.”

Never use “legend says” as proof of a fact. Visitor hours, tickets, weather, transport, parking, and closures stay in Parent Corner with checked and recheck dates.

## Cooperative language and reward

Say “team clue,” “choose together,” and “everyone helped.” Do not say “winner,” “best,” “fastest,” “easy role,” or “failed.” Completion states are `completed`, `manual`, or `skipped`; all are resolved states.

- Manual: “You solved it your way.”
- Skip: “Clue saved. Nobody is left behind.”
- Retry: “Try a different clue—or save this one.”
- Finale with skips: “Every journey has different clues. Your team brought the compass home.”

## Italian formatting

Format the first use as **Italian term** — English meaning. Optional pronunciation appears in Parent Corner only after language review. Do not italicise every later use, pluralise Italian with an English “s,” or imitate pronunciation for comedy.

Example: “Say **grazie** — thank you — together.”

## Safety rules by setting

- **Moving car:** parent starts content before departure or at a safe stop; driver never reads/taps; children stay buckled; no instruction to identify an exact route feature unless the parent confirms it.
- **Roads/crowds:** stop before looking at the phone; remain together; never cross, run, or separate for a clue.
- **Canals/rivers/lake/bridges/boats:** stay beside an adult and behind barriers; no leaning, touching water, feeding animals, boarding decision, or edge-based photo.
- **Shops/workshops/museums:** entry and purchase are optional; do not touch merchandise; ask before photography; follow staff instructions.
- **Heights/funicular/viewpoints:** observation works from the safe public path; no climbing, posing on walls, or motion requirement.
- **Sound/photo:** never record or photograph strangers; visual/manual equivalent always exists.
- **Weather/energy:** heavy rain, closure, missed boat, sensory overload, or tired legs can switch to seated/manual/indoor play without losing a power.

## Place-specific boundaries

- Arena and Juliet’s House are exterior-complete. No ticket, queue, courtyard, balcony, or interior access is assumed.
- Juliet content clearly separates a documented building, later place tradition, and the literary story. It never asks anyone to touch the statue or leave a physical message.
- Gladiator references remain non-graphic: “performances and contests,” never injury or death.
- Burano clues respect homes and residents; no doorway blocking or treating private façades as props.
- Murano clues never require a furnace demonstration, shop visit, purchase, touch, or photo.
- Gardaland is absent from all app content.

## Pre-publish check

Every mission must have: one action per role; team resolution; eyes-up cue; no-GPS/manual/closed/tired/rain behavior; source IDs for each external claim; fact check/recheck dates; and no ticket, audio, live transport, route, or venue dependency.

