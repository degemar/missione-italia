# Screen, state, and transition contract

**Contract version:** 0.1.0  
**Inputs:** `public/content/trip-manifest.json`, `docs/content-contract.md`, `docs/story-bible.md`  
**Output boundary:** interaction states only; no wireframes, itinerary planner, booking flow, or live logistics

The app is a single cooperative story on one parent-controlled phone. Screens consume the ordered `chapters`, each chapter's `missionIds`, mission completion states, `excursionSelection`, and `epilogueMissionId` from the manifest. They do not hard-code chapter count, mission count, destination labels, or progress segments.

## Global state model

| State group | Values | Contract |
|---|---|---|
| Family | `none`, `ready` | Setup stores nicknames only; no child accounts or profiles |
| Route | `screenId`, optional `chapterId`, `missionId`, `stage` | Persist the last stable stage; never persist browser permission UI |
| Completion | `unresolved`, `completed`, `manual`, `skipped` | All three resolved values unlock the next story beat and persist; none is failure |
| Connectivity | `online`, `offline-ready`, `offline-degraded` | Bundled story and missions remain playable; unavailable tiles/cloud become calm fallbacks |
| Location | `not-requested`, `preprompt`, `granted`, `denied`, `unavailable`, `inaccurate` | Parent-triggered foreground helper only; never unlocks content or tracks history |
| Save | `clean`, `saving`, `saved`, `retry-needed` | Local save is authoritative; cloud state never blocks play |
| Content | `current`, `update-pending`, `recovery-copy` | Never replace content mid-mission; use last valid local copy |
| Excursion pair | manifest `selectedPairId` or `null` | One parent choice resolves both stable slots; null still permits manual or skip |
| Motion | `full`, `reduced` | Meaning, status, focus, and order are identical |
| Runtime | `browser`, `standalone` | Same information architecture; only chrome, install guidance, and safe-area treatment differ |

Back/close always returns to the immediately preceding stable state without changing progress. Browser Back follows the same app history; Android Back or an installed-PWA back control closes the top sheet/dialog first. A resolved mission can be reviewed but is never silently changed back to unresolved.

## Screen inventory

Primary labels are final interaction copy and stay within three words. Header back/close controls have 48×48 px targets and accessible names.

| ID | State and purpose | Visible primary action | Back/close | Required variants and persistence |
|---|---|---|---|---|
| `SYS-BOOT` | Validate bundled/cached content and local save before child UI | None; automatic | None | Resume to the last stable state. If current content fails validation, use the last valid copy; show parent recovery only if none exists. |
| `WELCOME` | Introduce Bussola and cooperative play | **Begin adventure** | Browser may leave the site; no in-app back | First visit, returning-family summary, offline-ready. Install guidance is secondary and dismissible. |
| `SETUP` | Parent enters up to three nicknames and confirms shared-phone mode | **Meet Bussola** | Back to Welcome | No ages, email, account, precise location, or child photo. Save family state before leaving. |
| `ATLAS` | Story atlas of manifest chapters, powers, current mission, Passport entry, and optional epilogue | **Continue story** | Back to Welcome only before progress; otherwise no destructive back | Zero/partial/complete progress; 3- or 4-chapter fixtures; offline banner; epilogue appears separately and unscored. It is not a route planner. |
| `CHAPTER` | Chapter opening/summary from manifest content | **Start clue** or **Next clue** | Back to Atlas | New, active, completed, and unknown-ID/default-theme states. Mission order comes from `missionIds`. |
| `MISSION` | Title, cooperative objective, duration/energy, safety cue, and three role cards | **Hear story** | Back to Chapter | Fixed, selected-variant, and unresolved TBC slot. Parent-only fallback link is visually distinct. |
| `STORY` | Short read-aloud story beat and optional Italian phrase | **Look up** | Back to Mission | Audio absent/loading/failed never affects text. Primary action moves to the phone-down handoff. |
| `LOOK-UP` | Full-attention handoff: one short instruction, safety cue, and no competing controls | **We’re ready** | Back to Story | Walking, water, road, quiet, tired-legs, and indoor/manual copy variants. Parent keeps the phone. |
| `CHALLENGE` | Role actions, answer/observation controls, hint, and team confirmation | Contextual: **Check answer**, **We found it**, or **Team done** | Back to Look-up; entered response remains local | No required typing, timing, GPS, audio, precise drag, or handwriting. Wrong answer stays here with kind feedback. |
| `RESOLVE` | Parent fallback sheet for manual completion or skip | Select one row; the single primary becomes **Done another way** or **Save for later** | Close returns to Challenge | Records `manual` or `skipped`, reason-free. Both transition to Celebration and unlock progress. |
| `CELEBRATION` | Persisted team result, success line, power/stamp status | **Next clue**; final mission uses **See Passport** | Review closes to Chapter/Atlas | `completed`, `manual`, and `skipped` have distinct label/icon/shape but equal progression. Static and reduced-motion equivalents are complete. |
| `PASSPORT` | Family-wide earned stamps and chapter powers | **Continue story** when unfinished; **Home arrow** when epilogue is available | Close to origin | Manifest-driven chapters; no individual scores, leaderboard, empty segment, or reward for the unscored epilogue. |
| `EPILOGUE` | Optional `epilogueMissionId` reflection, visually outside scored chapters | **Choose memory** then **Finish story** | Back to Atlas/Passport | May be completed, manual, skipped, or ignored; never changes scored progress. |
| `PARENT-ENTRY` | Deliberate adult affordance, not a security claim | 900 ms **Hold for adult** | Release/cancel stays in place | Touch shows hold progress; keyboard/assistive activation opens an explicit adult confirmation. No PIN. |
| `PARENT` | Parent Corner for permissions, excursion pair, install/offline status, backup status, reset/delete | **Done**; opening a section replaces it with that section's one action | Close to exact origin | Squared treatment, lock icon, and `ADULT` label. Operational links live here, never in child story states. |
| `EXCURSION-CHOICE` | Choose one manifest candidate pair or leave TBC | **Choose route** | Back to Parent; no change | Uses candidate IDs/labels/reasons from manifest. Selection is atomic for `VER-04` and `VER-05`; no extra chapter or mission. |
| `DESTRUCTIVE-CONFIRM` | Explain reset/delete scope and require deliberate confirmation | **Reset progress** or **Delete family** | **Keep everything** closes | Reset keeps nicknames and clears progress; delete clears local family/save data and returns to Welcome. Controls are separated from routine actions. |
| `RECOVERY` | Parent-readable last-valid-copy or local-save recovery | **Retry save** or **Use saved copy** | Close only when safe | No stack traces or technical wording in child UI. Mission play continues from local data whenever a valid copy exists. |

## Transition contract

| From | Trigger / guard | To | Persisted outcome |
|---|---|---|---|
| `SYS-BOOT` | no family | `WELCOME` | none |
| `SYS-BOOT` | family exists; stable route valid | saved stable screen, otherwise `ATLAS` | record recovery timestamp only |
| `WELCOME` | Begin adventure | `SETUP` | none |
| `SETUP` | valid nicknames; Meet Bussola | `ATLAS` | family + initial route before navigation |
| `ATLAS` | Continue story | active `CHAPTER` or next `MISSION` | active IDs from manifest |
| `ATLAS` | choose any manifest chapter | `CHAPTER` | selected chapter ID, not index |
| `CHAPTER` | Start/Next clue | `MISSION` | selected mission ID |
| `MISSION` | Hear story | `STORY` | stage=`story` |
| `STORY` | Look up | `LOOK-UP` | stage=`look-up` before reducing screen detail |
| `LOOK-UP` | We’re ready | `CHALLENGE` | stage=`challenge` |
| `CHALLENGE` | correct/team-confirmed | `CELEBRATION` | atomically write `completed`, reward reference, and next unlocked ID |
| `CHALLENGE` | wrong choice | `CHALLENGE` | no penalty or child attribution; optional attempt count stays session-only |
| `CHALLENGE` | parent opens fallback | `RESOLVE` | none |
| `RESOLVE` | Done another way | `CELEBRATION` | atomically write `manual` and next unlocked ID |
| `RESOLVE` | Save for later | `CELEBRATION` | atomically write `skipped` and next unlocked ID |
| `CELEBRATION` | Next clue | `CHAPTER` or next `MISSION` | stable route after completion save |
| `CELEBRATION` | final scored mission | `PASSPORT` | scored story complete regardless of prior resolved modes |
| `PASSPORT` | Home arrow | `EPILOGUE` | no scored-progress change |
| any stable child screen | adult hold completed | `PARENT` | `returnTo` screen ID |
| `PARENT` | choose excursion | `EXCURSION-CHOICE` | none until confirmed |
| `EXCURSION-CHOICE` | Choose route | `PARENT` | selected pair ID; both slot variant IDs derive from manifest |
| `PARENT` | destructive action | `DESTRUCTIVE-CONFIRM` | none until confirmed |
| `DESTRUCTIVE-CONFIRM` | Reset progress | `ATLAS` | clear completions/rewards/route; keep nicknames |
| `DESTRUCTIVE-CONFIRM` | Delete family | `WELCOME` | clear local family, progress, optional cloud link, and session location |

## Offline, location, and permission paths

1. Location starts `not-requested`. Only a parent action such as **Where are we?** opens an explanation sheet.
2. The sheet names the immediate foreground benefit and offers **Use location** as primary and **Play without** as secondary.
3. Only **Use location** invokes the browser prompt. Denied, inaccurate, unavailable, dismissed, or unsupported results show a calm parent banner and continue with parent-selected locations.
4. No coordinates, proximity, or permission state locks a mission. The app does not store location history or request background access.
5. `offline-ready` shows a small “Adventure saved offline” status. If live map tiles are unavailable, the chapter state uses its ordered checkpoint list and a later provenance-approved offline route illustration; all missions remain playable.
6. `offline-degraded` means a nonessential service such as tiles or cloud backup is unavailable. It is not styled as child failure. The local save remains authoritative.
7. An available app/content update waits until Atlas/Parent Corner and a completed local save. It never replaces the frozen trip build mid-mission.

## TBC excursion-slot behavior

- `VER-04` and `VER-05` remain stable scored mission IDs. UI never creates a fifth chapter, bonus progress segment, or itinerary day.
- When `selectedPairId` is null, child-facing cards say **Mystery route** and **Parent chooses later**. Primary child action is **Ask an adult**; parent fallback still offers manual or skip.
- Parent Corner renders only manifest candidate labels and short reasons. Tickets, opening hours, parking, weather, and driving stay outside this child contract.
- Confirming a pair resolves both slots from the candidate's morning/afternoon variant IDs. Changing the pair later updates only unresolved slots; a resolved slot retains its recorded variant for history.
- Unknown/missing candidate data falls back to the base slot title/objective and manual/skip. Finale `VER-06` is always reachable.

## Resume and failure rules

- Persist before leaving Setup, entering a new stable mission stage, and showing Celebration. A completion write includes state, mission ID, resolved variant ID if any, reward reference, and next unlock in one local transaction.
- Resume never lands inside a native permission prompt, open destructive dialog, loading animation, or unpersisted celebration. It returns to the closest prior stable stage.
- If a crash occurs after an answer but before completion is committed, resume Challenge without claiming the reward. If completion committed, resume Celebration or the next stable screen without awarding twice.
- Save failure keeps the in-memory action, retries locally, and shows parent-readable status. It never asks a child to repeat a successful mission.
- Content-version mismatch preserves stable IDs and completion. Unknown chapters use default tokens; unknown missions stay hidden from progress until valid content is available.

## Browser and installed-PWA behavior

| Concern | Browser | Installed PWA |
|---|---|---|
| Chrome/safe area | Use dynamic viewport and allow collapsing chrome | Respect all installed safe-area insets |
| Back | Browser Back maps to stable app history; top overlay closes first | In-app/system Back maps to the same stable history |
| Install | Dismissible guidance on Welcome or Parent Corner only | No install prompt |
| Offline | Same bundled/cached mission contract | Same bundled/cached mission contract |
| External maps | Parent-only handoff names destination app/site before leaving | Same; app state is saved before handoff |
| Rotation | Portrait optimized; landscape keeps primary action and progress visible | Same |

## Accessibility and safety invariants

- DOM/focus order follows title → context → instruction → choices → primary action → secondary/parent action.
- Screen changes move focus to the heading; result text is announced politely; blocking recovery is assertive only for the parent.
- Each control exposes name, role, current state, and error association. Color and motion are never the only state signal.
- No timed child response, required sound, required speech to strangers, left/right-only direction, running, unsafe crossing, or edge-seeking instruction is introduced by UI.
- Child copy remains English-complete; Italian is optional delight. Parent reads aloud without audio dependency.
