# Living Storybook Atlas — art direction contract

**Status:** locked for Wave 0  
**Scope:** phone-only, 320–430 CSS px, portrait-first, browser and installed PWA  
**Audience:** one family sharing one parent-controlled phone outdoors; children aged 9, 7, and 4

This is the only visual direction. Missione Italia is a warm pocket field book whose brass compass, inked route marks, paper layers, and earned travel stamps come alive briefly when the family acts together. It is adventurous, never babyish; tactile, never toy-like; expressive, never busy. Functional UI stays quiet so the place and the children remain the focus.

## Visual grammar

| Element | Use | Avoid |
|---|---|---|
| Paper | Warm, high-contrast surfaces; restrained fibre/noise only on non-text regions | Low-contrast parchment, distressed text areas, faux-aged stereotypes |
| Ink | Dark, crisp outlines and map marks; irregularity belongs to original illustrations only | Sketchiness that weakens labels, controls, or focus states |
| Stickers and stamps | Earned, finite story markers with a label and silhouette | Decorative clutter, individual scores, collectible pressure |
| Compass | One original brass travel object, Bussola, linking story, progress, and celebration | Human-child caricature, derivative mascot, constant idle motion |
| Route marks | Short dotted/inked connective gestures, never operational directions | Itinerary timelines, live tracking trails, booking or logistics UI |
| Controls | Crisp modern geometry, generous spacing, solid outlines, 48 px minimum targets | Glassmorphism, subtle shadow-only affordances, dense desktop patterns |

Texture and illustration never sit behind essential text at full strength. A solid semantic surface is always available underneath. Every color-coded object also has a label plus an icon, shape, number, or position.

## Annotated reference board

These are principle references, not layout or asset sources.

| Approved source | Principle retained | Translation for Missione Italia | Explicit boundary |
|---|---|---|---|
| [Design Spells](https://designspells.com/) | Editorial “magic object,” tactile cards, rounded tags, delight inside ordinary actions | Bussola is the single magic object; chapter and clue cards feel handled and finite | Do not reproduce its layouts, typography, assets, or signature interactions |
| [60fps](https://60fps.design/) | Small, legible success, reward, progress, map, mascot, and permission interactions | Motion is brief feedback at state changes; static meaning always remains | No interaction gallery sampling and no continuous decorative movement |
| [Motion by Zajno](https://motion.zajno.com/) | Short offsets, easing, and shared-object continuity | Bussola may bridge mission, celebration, atlas, and Passport states | No branded choreography, large camera moves, or scroll spectacle |
| [Viewport UI](https://viewport-ui.design/) | Crisp controls beside occasional dimensional paper surfaces | Functional controls stay modern; story cards carry the paper quality | No copied component composition or effect recipe |
| [Recent](https://recent.design/) | Expressive focal illustration with quiet surrounding UI | One original chapter image or Bussola moment can lead a state | No illustration imitation or competing focal objects |
| [SeeSaw](https://www.seesaw.website/) | Disciplined spacing, grouping, and scan order | One action, one reading group, and one clear next step per phone state | Do not borrow its dense desktop gallery layout |

[Posts Design](https://posts.design/) and [CollectUI](https://collectui.com/) are secondary catalogs and do not define this system. [Web Interaction Gallery](https://webinteractions.gallery/) returned a deployment 404 during the approved review; [Mobbin](https://mobbin.com/discover/apps) exposed only a logged-out shell; Inspora Design and Motionin Design were network-blocked. No design claim or asset comes from those unavailable surfaces.

## Chapter mood notes

Chapter order and count come only from `public/content/trip-manifest.json`. Mood changes through semantic tokens, an original chapter illustration, and story copy—not a new layout.

| Manifest key | Mood | Original motif brief | Never imply |
|---|---|---|---|
| `road` | Curious, seated, anticipatory | Folded route mark, tunnel rhythm, country-card shapes | Live route guidance, driver interaction, exact tunnel detection |
| `venice` | Watery wonder, observation, quiet sound | Wing, arch, ripple, boat-job silhouettes | Edge-seeking, transport choice, crowd-following |
| `lagoon-islands` | Maker energy, pattern, respectful color | Glass reflection, route symbol, named-color shapes, lace rhythm | Touching merchandise, copying commercial glass/lace designs, photographing residents |
| `verona` | Teamwork, layered history and story | Arch, bridge span, message ribbon, converging compass marks | Guaranteed entry, romance pressure, crowd or crossing tasks |
| Epilogue (`chapterId: null`) | Calm reflection and homeward closure | One home arrow and a chosen earned stamp | A fifth scored chapter or retained location history |

Unknown chapter IDs use the default chapter tokens and supplied content; the layout does not invent an empty tab or compass segment.

## Outdoor and shared-phone rules

- Child-facing body and read-aloud text starts at 18 CSS px; essential text uses the highest-contrast ink pair.
- One visually dominant action appears per state. Secondary and parent-only actions are quieter but still legible.
- Parent controls use the `ADULT` label plus lock icon and squared-corner treatment; child controls use sentence-case labels and rounded treatment.
- “Look up” states deliberately remove interactive detail after the parent reads the cue.
- Reduced motion removes travel, bounce, parallax, shake, burst, and autoplay sequencing without removing status or reward.
- Browser chrome, installed-PWA safe areas, bright light, one-handed parent use, and three-child viewing determine spacing; desktop density does not.

## Asset boundary

Functional icons will use a locally bundled, version-recorded Phosphor Icons package under its MIT licence. Bussola, chapter scenes, stamps, map markers, and offline route art must be original and receive source/generation provenance before use. This contract creates no final images, wireframes, emoji substitutes, CSS drawings, placeholder boxes, or ad-hoc SVG illustrations.

