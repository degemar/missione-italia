# Reward and Passport Vocabulary

## Model

The passport belongs to the family team. It records shared discoveries, never individual scores. A mission resolves as `completed`, `manual`, or `skipped`; all three permit chapter and finale progress.

## Compass powers

| Key | Power | Chapter | Unlock line |
|---|---|---|---|
| `curiosity` | Curiosity | Road | “Compass awake: Curiosity is glowing.” |
| `wonder` | Wonder | Venice | “Compass awake: Wonder is glowing.” |
| `creativity` | Creativity | Lagoon Islands | “Compass awake: Creativity is glowing.” |
| `teamwork` | Teamwork | Verona | “Compass awake: Teamwork is glowing.” |

A power is restored when its chapter is resolved. “Resolved” means the family has completed at least one mission and explicitly closed the rest as completed, manual, or skipped. Parent override is allowed.

## Reusable stamps

Use no more than these six stamp types:

| Key | Label | Use |
|---|---|---|
| `eagle-eye` | Eagle Eye | spotting a visible detail |
| `pattern-maker` | Pattern Maker | comparing or creating a pattern |
| `story-sleuth` | Story Sleuth | separating fact, tradition, legend, and fiction |
| `kind-navigator` | Kind Navigator | helping the team choose safely |
| `sound-scout` | Sound Scout | listening or using its visual alternative |
| `team-spark` | Team Spark | combining three role contributions |

Stamps are collectible labels, not points. Repeated types are expected.

## State vocabulary

- `completed`: “Team clue solved.”
- `manual`: “You solved it your way.”
- `skipped`: “Clue saved for another explorer.”
- chapter ready: “All clues are accounted for. Ready to wake **{power}**?”
- resumed: “Welcome back. Bussola kept your place.”
- offline: “The adventure is packed on this phone.”
- closed place: “Doors closed? The outside clue still works.”
- quiet celebration: “Power restored.” plus a static glow/checkmark.

Never display a zero, missed badge, incomplete sibling, streak, rank, timer, or percentage to children.

## Finale language

`VER-06` checks resolved states, not a perfect score. The parent may resolve a cancelled Friday excursion as `skipped`; the finale then says: “Different route, same team. You brought Curiosity, Wonder, Creativity, and Teamwork together.” The Saturday epilogue awards no stamp or power.

