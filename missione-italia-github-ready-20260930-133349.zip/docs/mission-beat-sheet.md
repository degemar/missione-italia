# Final Mission Manifest and Beat Sheet

**Authority:** `public/content/trip-manifest.json` · **Count:** 16 scored missions + 1 unscored epilogue · **Order:** calendar order · **Wave 1:** playable copy complete

Every fixed mission and excursion variant now carries a 50–67 word parent-read story, one-sentence objective, all three role actions, observation/answer resolution, retry, explanation, success, safety, four fallbacks, and fact-review dates. The manifest—not this summary—is runtime authority.

## Calendar beats

| Date | Morning anchor | Afternoon anchor | Story result |
|---|---|---|---|
| Sun 4 Oct | Road observations, started before driving | Phrase match at a safe stop/while children remain seated | Curiosity |
| Mon 5 Oct | Family day outside app | Transfer outside app | Silent: no chapter, mission, marker, or reward |
| Tue 6 Oct | Venice lions/bridges | Boats/sound; short route is valid | Wonder |
| Wed 7 Oct | Murano pattern + parent-controlled lagoon navigation | Burano colour/lace; leave transfer buffer | Creativity |
| Thu 8 Oct | Arena exterior, Juliet/Piazza Erbe trail | Ponte Pietra; optional car outing TBC **replaces** this block | Teamwork clues 1–3 |
| Fri 9 Oct | `VER-04` selected morning slot | `VER-05` selected afternoon slot, then `VER-06` anywhere | Teamwork restored |
| Sat 10 Oct | Optional before departure/safe stop/home | — | Unscored epilogue |

Recommended Friday pairing remains Sigurtà + Borghetto. Sirmione + optional Lazise is the alternate. Heavy rain selects the Verona indoor/manual variants. The parent has not chosen; this is deliberately `TBC`, not assumed.

## Manifest-driven Friday variants

| Stable slot | `sigurta-borghetto` | `sirmione-lazise` | `verona-rain` |
|---|---|---|---|
| `VER-04` morning | `sigurta-team-maze` | `sirmione-castle-water` | `verona-natural-history` |
| `VER-05` afternoon | `borghetto-water-mill` | `lazise-bonus-spotter` | `verona-childrens-museum` |

Each variant is fully playable without GPS, audio, live data, venue entry, or a ticket. `selectedPairId` remains `null`; a parent choice, manual completion, or skip resolves the same stable slot.

## Mission beats

| # | ID | Scored | Power | Hook and three-role resolution | Safe fallback | Stamp |
|---:|---|:---:|---|---|---|---|
| 1 | `ROAD-01` | Yes | Curiosity | Mixed-up country cards; Spotter points, Detective compares, Navigator orders parent-announced cards. | Offline cards/manual; no border detection. | Eagle Eye |
| 2 | `ROAD-02` | Yes | Curiosity | Dark/light pattern; Spotter signals, Detective compares cards, Navigator keeps count. | Route-neutral offline pattern; no tunnel name without confirmation. | Pattern Maker |
| 3 | `ROAD-03` | Yes | Curiosity | Five kind Italian phrases; gesture, meaning match, family phrase choice. | Gesture-only and no audio. | Team Spark |
| 4 | `VEN-01` | Yes | Wonder | Find a winged lion; point, identify wings, confirm safe stop. | Any public lion or offline reference image. | Eagle Eye |
| 5 | `VEN-02` | Yes | Wonder | Read a bridge through shape/material; spot, compare, choose safe side. | Any bridge/offline arch cards; no leaning. | Pattern Maker |
| 6 | `VEN-03` | Yes | Wonder | Compare two observed boat shapes/roles without choosing transport. | Offline silhouettes; parent controls travel. | Story Sleuth |
| 7 | `VEN-04` | Yes | Wonder | Phone down: notice three sounds or visual equivalents. | Quiet/visual/seated mode; no recording. | Sound Scout |
| 8 | `ISL-01` | Yes | Creativity | Build a three-part Murano-inspired pattern. | Offline cards; no shop, furnace, ticket, touch, or photo required. | Pattern Maker |
| 9 | `ISL-02` | Yes | Creativity | Match route/stop symbols while stationary. | Offline symbols/manual; parent validates real ACTV service. | Kind Navigator |
| 10 | `ISL-03` | Yes | Creativity | Match colour-plus-shape and sort fact/tradition/legend. | Offline sort; museum optional; respect homes. | Story Sleuth |
| 11 | `VER-01` | Yes | Teamwork | Arena exterior becomes a non-graphic time machine; spot/compare/choose viewpoint. | Exterior/offline fully completes mission. | Pattern Maker |
| 12 | `VER-02` | Yes | Teamwork | Sort documented house, later Juliet tradition, and our fiction; create a kind message. | Exterior/offline; no courtyard, touch, ticket, or physical message. | Story Sleuth |
| 13 | `VER-03` | Yes | Teamwork | Five Ponte Pietra arches; point/compare/choose cross, view, or offline mode. | Do not cross; seated/manual. A Thursday trip replaces this block. | Kind Navigator |
| 14 | `VER-04` | Yes | Teamwork | Morning manifest slot: Sigurtà maze, Sirmione castle, or Verona indoor pattern. | Parent selects locally, manual, or skip. | Kind Navigator |
| 15 | `VER-05` | Yes | Teamwork | Afternoon slot: Borghetto fact/legend, optional Lazise spotter, or indoor team spark. | One clue only, manual, or skip. | Story Sleuth |
| 16 | `VER-06` | Yes | Teamwork | Three different role actions align the four power cards. | Anywhere, seated, static, quiet; Friday cancellation does not block. | Team Spark |
| 17 | `RETURN-EP` | **No** | — | Choose one favourite discovery and point the offline home arrow. | Before driving, safe stop, or home; one-tap close. | None |

## Finale rule

`completed`, `manual`, and `skipped` are all resolved states. `VER-06` never checks for a perfect score or selected Friday destination. The app acknowledges the route taken without listing skipped clues as failures.
