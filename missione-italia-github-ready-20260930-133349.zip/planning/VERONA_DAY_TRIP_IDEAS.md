# Verona Day-Trip Idea Register

**Status:** ideas only; no destination is locked into child-facing content  
**Decision deadline:** before final destination missions and offline checkpoints are frozen

The user-provided [Verona.in family day-trip article](https://www.verona.in/verona/useful-tips/best-family-friendly-day-trips-from-verona) is used only to discover candidates. It is a commercial editorial source, and its specific promotions, prices, routes, opening claims, and “local secret” details must not enter the app until verified through an official operator or destination source.

| Candidate | Best use | Family fit | Current evidence status | Main caution |
|---|---|---|---|---|
| Sigurtà + Borghetto | Friday full day | Strong: maze/nature plus compact village and water-mill mystery | Supported by official Visit Verona and Sigurtà sources | Outdoor/weather dependent |
| Sirmione + short Lazise stop | Friday full day | Strong scenery, castle, lake, gelato | Sirmione parking/access officially documented; final hours require recheck | Parking, crowds, and more walking |
| Soave Castle | Thursday short trip replacing the Verona afternoon | Strong medieval clue potential; self-paced castle | Official Visit Verona page lists 15:00–18:00 afternoon hours through 25 October | Makes Thursday full; castle may close in bad weather |
| Custoza agriturismo/farm | Thursday short trip or Friday alternative | Potentially excellent for younger children | Idea discovered on Verona.in; named farm, prices, animals, and grape activities unverified | Requires venue-level verification and booking |
| Valpolicella family cycling | Friday alternative | Active and scenic for confident riders | Idea discovered on Verona.in; named trail/rental claims unverified | Weather, bike skill, child-seat availability, and road safety |

## Recommended decision frame

- Choose **Sigurtà + Borghetto** for the easiest child-focused full day.
- Choose **Sirmione + Lazise** if lake and castle scenery matter more than logistics.
- Choose **Soave** only if a Thursday car excursion is more important than Verona's Ponte Pietra/Funicular afternoon.
- Keep Custoza and Valpolicella as research leads, not app content, until operator details are verified.

## Verification tasks after selection

1. Confirm official opening hours, tickets/reservations, parking, accessibility, and weather closure rules.
2. Confirm realistic drive and return cut-offs from the actual Verona lodging.
3. Build a no-ticket and poor-weather fallback.
4. Create missions only from observable features and verified facts.
5. Recheck all live information on 2–3 October and the evening before travel.

## Official sources already identified

- [Visit Verona — Soave Castle](https://www.visitverona.it/en/poi/castello-di-soave)
- [Visit Verona — Valeggio, Sigurtà, and Borghetto](https://www.visitverona.it/en/explore/a-magical-mix-of-history-and-countryside)
- [Parco Giardino Sigurtà FAQ](https://www.sigurta.it/faq)
- [Visit Sirmione — parking](https://visitsirmione.com/en/info/parking/)
