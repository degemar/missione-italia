# Manual account handoff

No account value is required to start implementation.

## Personal GitHub — needed at deployment

- Personal repository URL or owner/repository name.
- Default branch name if it is not `main`.
- Final GitHub Pages URL after the first deployment.

Codex will deliver the source tree, pinned lockfile, GitHub Actions workflows, and `MANUAL_IMPORT.md`. The user copies/pushes them through the personal GitHub account and enables Pages. Codex must not use the connected professional GitHub identity.

## Supabase — needed only when cloud backup is activated

- Project URL.
- Browser-safe publishable key beginning `sb_publishable_`.
- Final GitHub Pages URL for the Auth redirect allowlist.

Put these values in `.env.local` for local testing and in the personal repository's configured variables/secrets as directed by `SUPABASE_SETUP.md`. Do not paste them into chat. Never provide an `sb_secret_` key, legacy `service_role` key, database password, personal access token, or SMTP credential.

Codex will deliver `.env.example`, migration SQL, RLS policies/tests, and `SUPABASE_SETUP.md`. The user reviews and applies remote SQL/configuration manually.

## Release QA — needed near freeze

- Primary and backup phone model, OS version, and browser.
- Thursday optional trip and Friday day-trip choice.
