# Missione Italia — Frontend Implementation Backlog

**Scope:** React screens, client state, gameplay orchestration, adapter integration, accessibility, and frontend tests.  
**Target:** frozen build by 3 October 2026 for travel from 4–10 October 2026. No code is implemented by this document.

## Ownership boundaries

- **Frontend owns:** React views/components, in-app navigation, UI state, gameplay sequencing, content rendering, accessibility behavior, and integration tests.
- **Story owns:** facts, narrative, mission records, answers, safety wording, localization keys, and final content/assets.
- **UX/UI owns:** visual direction, tokens, component behavior, motion rules, responsive rules, and visual QA.
- **Infrastructure owns:** scaffold/build, service worker, offline cache, browser-storage health signals, geolocation adapter, Leaflet/provider setup, Maps URL builder, CI/CD, diagnostics, and security controls.
- **Backend/data owns:** content/save schemas, IndexedDB adapter and migrations, export/import/reset, optional Supabase auth, RLS, save synchronization, and cloud deletion.
- Frontend must depend on typed adapters for those services; it must not recreate their logic inside components.

## Priority

- **P0:** required for the trip-ready build.
- **P1:** add only after the complete P0 offline loop passes on the family phone.
- **P2:** post-trip.

## Current itinerary contract

- Required chapters are **Venice**, **Murano & Burano / Lagoon Islands**, and **Verona**.
- **Gardaland is excluded** and must not appear in navigation, content fixtures, tests, or fallback copy.
- **Road & Return** is included: Sunday is a lightweight chapter and Saturday is a short, non-required epilogue.
- Chapter order, enabled chapters, final mission count, finale trigger, rewards, and completion totals still come only from the validated trip manifest. Frontend code must not assume fixed indices.

## Shared gates

| Gate | Complete when |
|---|---|
| `SHELL-GATE` | `INF-003`, `INF-004`, and `INF-007` are available. |
| `CONTENT-GATE` | `ST-007`, the latest approved trip manifest, `ST-050`–`ST-056`, `BE-010`, `BE-011`, and `INF-024` agree on one validated contract matching the current itinerary. |
| `DESIGN-GATE` | `UX-001`–`UX-004`, `UX-006`, and `UX-010` are approved; no wireframe is required. |
| `LOCAL-DATA-GATE` | `BE-020`–`BE-024` expose tested typed adapters; `INF-017` exposes browser-storage health signals. |
| `MAP-GATE` | `INF-019`–`INF-022` expose Leaflet, location, navigation, and fallback contracts. |
| `BACKEND-GATE` | Optional backend adapter passes its own auth/RLS/sync tests; it is not a P0 dependency. |

## App foundation and state

| ID | Pri | Dependencies | Deliverable | Acceptance criteria |
|---|---:|---|---|---|
| `FE-001` | P0 | `SHELL-GATE`, `UX-002`, `ST-015` | Typed app-state model and transition reducer | Covers welcome, setup, atlas, chapter, mission card, story, three clues, celebration, passport, Parent Corner, and degraded states; every event has a deterministic destination; invalid/transient state recovers to the nearest safe screen; no URL router is introduced. |
| `FE-002` | P0 | `FE-001`, `DESIGN-GATE` | Phone app shell and shared screen layout | Applies tokens, safe areas, focus target, header/progress, one primary action, and consistent back/close behavior; works from 320–430 CSS px in mobile browsers and installed mode; no screen depends on hover. |
| `FE-003` | P0 | `CONTENT-GATE`, `SHELL-GATE` | Content repository and typed loader | Loads base-safe versioned JSON/GeoJSON/assets; exposes manifest-ordered chapters, missions, rewards, walks, and source metadata through one API; accepts three or four chapters and any validated mission count; malformed/mismatched content fails into a recoverable parent state; no factual copy is embedded in components. |
| `FE-004` | P0 | `FE-003`, `ST-055` | Lightweight localization layer | All visible strings resolve by stable key; selected V1 language and Italian glossary render without fragment concatenation; missing keys fail tests and show a safe fallback; no large i18n framework is added for a one-language V1. |
| `FE-005` | P0 | `FE-001`, `LOCAL-DATA-GATE` | Startup, hydration, and resume controller | Distinguishes first run, returning family, loading, migration/recovery, and non-persistent session; hydrates before showing progress; refresh/force-close returns to a stable screen; an incomplete mission restarts at its mission card rather than inventing partial completion. |

## Core family journey

| ID | Pri | Dependencies | Deliverable | Acceptance criteria |
|---|---:|---|---|---|
| `FE-006` | P0 | `FE-002`, `FE-004`, `ST-010`, `UX-002` | Welcome and Lost Compass opening | New families can start setup; returning families can continue; opening stays within the approved three-screen maximum; the youngest child can trigger the first child-facing action. |
| `FE-007` | P0 | `FE-005`, `ST-051`, `UX-004`, `UX-010` | Family setup flow | Captures nicknames/role names, age bands, approved avatars, and sound preference only; validates without requiring typing from children; explains shared play and role rotation; saves locally and requires no account. |
| `FE-008` | P0 | `FE-003`, `FE-005`, `ST-008`, `UX-008` | Living Storybook adventure atlas | Renders Road, Venice, Lagoon Islands, and Verona with manifest-defined powers, progress, next mission, completed/available/locked states, a clear Passport entry, and a lightweight return epilogue; status never relies on color alone; manual parent unlock works; it contains no booking UI. |
| `FE-009` | P0 | `FE-008`, `CONTENT-GATE`, `ST-040`–`ST-043`, `UX-008` | Chapter screen, mission cards, and walk choice | Mission cards show approved duration, energy, distance/location, and completion state; Venice, Lagoon Islands, and Verona render their manifest-declared walk/transit/checkpoint variants; Road & Return renders only when enabled; no dynamic routing or fixed chapter-specific mission count is implied. |

## Mission engine and cooperative play

| ID | Pri | Dependencies | Deliverable | Acceptance criteria |
|---|---:|---|---|---|
| `FE-010` | P0 | `FE-001`, `FE-003`, `LOCAL-DATA-GATE`, `UX-005` | Content-driven mission engine | One engine runs every mission declared by the active manifest through card → story → eyes-up handoff → three role clues → resolution → celebration; chapter and mission totals are derived at runtime; mission-specific copy/data does not create bespoke flows; retry, hint, skip, manual completion, interruption, and resume are deterministic; completion is committed once and idempotently. |
| `FE-011` | P0 | `FE-007`, `FE-010`, `ST-051`, `UX-005` | Role rotation and reassignment | Spotter, Detective, and Navigator are visibly assigned and rotate predictably from completed-mission count; parent can reassign without penalty; no role is labelled easiest, smartest, or best; all three contributions remain required unless parent overrides. |
| `FE-012` | P0 | `FE-010`, `CONTENT-GATE`, `UX-004`, `UX-005` | Reusable clue and answer renderers | Supports visual spotting/matching, multiple choice, counting/ordering, riddles, observation confirmation, and parent-led group responses required by frozen content; typing is never required; selected/focus/correct/retry states are non-color-dependent; wrong answers are neutral and hints never shame. |
| `FE-013` | P0 | `FE-010`–`FE-012`, `ST-015`, `ST-050` | Safety and interruption handoffs | “Stop and look,” “eyes up,” parked-only, quiet-listening, pause, closed-place, bad-weather, tired-legs, and no-location variants render from content; the screen never asks a moving driver for input; skip/manual paths cannot block chapter or finale completion. |
| `FE-014` | P0 | `FE-010`, `ST-008`, `CONTENT-GATE`, `UX-006` | Celebration and reward flow | Local completion is saved before celebration; compass power, stamp, fact, and next action reflect the saved result; celebration is skippable and has a static/reduced-motion equivalent; duplicate taps/reloads cannot award twice; finale and completion threshold come from the manifest and adapt to the actual completion set. |
| `FE-015` | P0 | `FE-003`, `FE-005`, `FE-014`, `ST-008` | Family Passport | Shows shared compass powers, chapters, stamps, and discoveries without individual scores; skipped/manual missions use approved neutral treatment; empty, partial, complete, and restored states match local progress; no absent mission is framed as failure. |

## Parent controls and degraded operation

| ID | Pri | Dependencies | Deliverable | Acceptance criteria |
|---|---:|---|---|---|
| `FE-016` | P0 | `FE-005`, `ST-052`, `UX-004`, `INF-032`, `INF-033` | Parent Corner | Deliberate press-and-hold opens controls but is never presented as authentication; supports role reassignment, skip/unlock/manual complete, walk choice, install/help, diagnostics, sound/motion settings, and reset/delete; destructive actions have explicit confirmation and cannot be triggered accidentally. |
| `FE-017` | P0 | `FE-005`, `FE-016`, `INF-012`, `INF-013`, `INF-017`, `UX-009` | Offline, update, storage, and cloud-state presentation | Calmly presents offline-ready/not-ready, update available, storage unavailable, tile failure, GPS states, and optional cloud failure; cached gameplay remains primary; raw errors never reach children; network changes do not eject the current mission; updates wait for a safe parent action. |
| `FE-018` | P0 | `FE-010`, `FE-017`, `BACKEND-GATE` only if enabled | Optional cloud UI boundary | With cloud off, no sign-in/sync UI or request appears; with cloud on, parent-only status distinguishes local saved, syncing, backed up, auth expired, conflict, and unavailable; every failure preserves local play and offers a local-only continuation. |

## Map and navigation integration

| ID | Pri | Dependencies | Deliverable | Acceptance criteria |
|---|---:|---|---|---|
| `FE-019` | P0 | `FE-009`, `MAP-GATE`, `UX-008` | Lazy Leaflet walk/chapter view | Renders approved route line, checkpoint states, selected/next marker, and current in-memory position/accuracy state; Leaflet loads only when opened; attribution is visible; a synchronized ordered list provides the same actions without using the map; tile/location failure swaps to `FE-021`. |
| `FE-020` | P0 | `FE-019`, `INF-020`, `UX-009` | “Where are we?” location interaction | Explains the immediate benefit before requesting permission; calls the foreground adapter only on tap; shows locating, found, low accuracy, denied, timeout, unavailable, and stale states; offers play/manual check-in in every failure state; never displays or persists a coordinate history. |
| `FE-021` | P0 | `FE-009`, `FE-019`, `INF-021`, `INF-022` | Offline route and Google Maps handoff UI | Offline view shows bundled illustration and ordered checkpoints with full mission access; Walk/Drive buttons name Google Maps and destination before leaving; URLs come only from the infra builder; returning to the PWA retains the selected checkpoint and progress. |

## Accessibility, motion, and frontend quality

| ID | Pri | Dependencies | Deliverable | Acceptance criteria |
|---|---:|---|---|---|
| `FE-022` | P0 | `FE-002`, `FE-006`–`FE-021`, `UX-003`, `UX-010`, `UX-011`, `ST-056` | Accessibility and responsive implementation | Semantic landmarks/headings, logical focus after transitions, visible focus, useful names/states/errors, polite progress announcements, alt text, and decorative hiding are complete; all actions work by keyboard/switch-style input; 200% text, large text, portrait/landscape, and 48×48 targets do not obscure primary actions. |
| `FE-023` | P0 | `FE-014`, `UX-006`, `INF-030`, `INF-031` | Motion/reduced-motion controller | Uses shared motion tokens and compositor-friendly effects; respects system and parent reduced-motion preference from first render; celebrations remain understandable with zero motion and muted sound; listeners/timers stop when hidden; no loop competes with reading or maps. |
| `FE-024` | P0 | `FE-006`–`FE-023` | Frontend component/interaction tests | Tests navigation/recovery, setup validation, hydration, role rotation, every clue renderer, retry/skip/manual completion, idempotent reward, Passport, Parent Corner confirmations, degraded states, focus management, reduced motion, and map/list equivalence; fixtures use adapter contracts rather than bypassing them. |
| `FE-025` | P0 | `FE-024`, `ST-064`, `INF-027` | Production-like end-to-end scenarios | Adds frontend journeys to the infra browser harness: new family, returning family, one full mission per chapter, lightweight return epilogue, all renderer types, reload mid-mission, offline restart, denied GPS, missing tiles, external navigation return, update prompt, reset cancel/confirm, and optional cloud disabled; unexpected console/network/accessibility failures fail the run. |
| `FE-026` | P0 | `FE-001`–`FE-025`, draft complete content, `INF-027` | Production integration candidate | Every chapter, mission, and fallback declared by the active manifest renders with no missing key/asset/renderer; Venice, Lagoon Islands, and Verona are always present, Road & Return is conditional, and Gardaland is absent; the full story works without GPS, tiles, audio, or Supabase; the candidate is ready for cross-lane and family-phone testing. |
| `FE-027` | P0 | `FE-026`, `ST-060`–`ST-066`, `UX-012`, `INF-028`, `INF-029`, `INF-038` | Field-test fixes and frozen frontend release | Actual-phone defects are closed or marked release-blocking; the frozen 4–10 October 2026 content manifest is integrated unchanged; final build satisfies accessibility, size, 60 fps, privacy, offline, migration, and rollback gates; only blocking fixes follow. |

## Optional enhancements after P0 stability

| ID | Pri | Dependencies | Deliverable | Acceptance criteria |
|---|---:|---|---|---|
| `FE-028` | P1 | `FE-027`, `ST-053`, `DEC-S05` | Read-aloud enhancement | Browser speech/approved audio is parent-controlled, stoppable, and optional; on-screen text remains authoritative; unavailable voices/audio fall back silently; playback works without changing mission completion. |
| `FE-029` | P1 | `FE-027`, `INF-020` | Foreground proximity suggestion | While the relevant map screen is visibly open, proximity may suggest a mission; it never runs in background, auto-completes, or hard-locks; manual start/check-in remains equal; no coordinate is stored. |
| `FE-030` | P1 | `FE-027`, `UX-013` | Camera handoff, sound cues, and easter egg | Camera use leaves photos in the phone camera roll and uploads nothing; sounds default off/follow setup and have visual equivalents; each enhancement is feature-flagged and removable without affecting saves or offline play. |
| `FE-031` | P2 | Trip observations, new product decision | Post-trip frontend follow-up | Implements only approved recap/generalization work after a new privacy/content contract; frozen travel build remains unchanged; observed behavior is separated from assumptions. |

## Critical path

`FE-001 → FE-002/FE-003 → FE-004/FE-005 → FE-006–FE-009 → FE-010–FE-015 → FE-016–FE-021 → FE-022–FE-025 → FE-026 → FE-027`

P1/P2 tasks are not permitted to delay `FE-027`.
