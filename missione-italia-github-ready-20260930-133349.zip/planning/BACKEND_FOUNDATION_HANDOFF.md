# Backend/data Wave 0 handoff

**Completed:** 29 September 2026 · **Scope:** `BE-001`, `BE-010`, `BE-011`, `BE-020` · **Result:** pass

No repository, remote, account, Supabase project, cloud service, or privileged value was accessed. IndexedDB remains authoritative by contract but is intentionally not implemented until `BE-021`; Supabase remains absent and disabled.

## Deliverables

| Task | Artifact |
|---|---|
| `BE-001` | `docs/backend-data-boundaries.md`; field ownership, retention, reset/delete behavior, ephemeral boundary, prohibited data, `DEC-B01`–`DEC-B04` |
| `BE-010` | `schemas/content/v1/*.schema.json`; rewards/assets registries; valid/invalid content and GeoJSON fixtures; `config/content-validation-policy.json`; `scripts/validate-contracts.mjs` |
| `BE-011` | `docs/content-versioning-and-rollback.md`; `schemas/content/v1/content-package.schema.json`; hashed `public/content/content-package.json` |
| `BE-020` | `schemas/save/v1/save-envelope.schema.json`; `src/contracts/save-contract.ts`; `docs/save-envelope-contract.md`; seven valid and three invalid save fixtures |

## Acceptance evidence

### BE-001

| Criterion | Evidence | Result |
|---|---|---|
| Every field has one owner, retention, and deletion behavior | Static, device, optional backup, and ephemeral tables in `backend-data-boundaries.md` | Pass |
| Gameplay local-owned; content build-owned; cloud backup-owned | Contract opening and three ownership sections | Pass |
| No precise location/history/photo/full name/birthday/child login/analytics/free-form profile | Prohibited-data section, save schema `additionalProperties: false`, policy scan, invalid fixtures | Pass |
| Cloud removable without changing mission play | No Supabase dependency or value exists; save reducer and all fixtures are network-free | Pass |

### BE-010

| Criterion | Evidence | Result |
|---|---|---|
| Stable unique IDs and resolved references | Trip/chapter/mission/source/reward/asset schemas plus semantic validator | Pass |
| Roles, choices, completion, fallbacks, sources, assets, safety, offline criticality | `mission.schema.json` plus current-bundle validation | Pass |
| GeoJSON geometry, `[longitude, latitude]` ranges, checkpoint order, mission/place refs | `walk.schema.json`, valid and four-defect invalid fixtures | Pass |
| Missing assets, duplicate/dangling IDs, unapproved URLs, prohibited fields fail | Six deterministic mutation fixtures produce exact diagnostic codes | Pass |
| Compatibility checked before last-known-good replacement | Package schema and activation transaction in versioning policy | Pass as foundation contract; runtime wiring belongs to app shell |

### BE-011

| Criterion | Evidence | Result |
|---|---|---|
| Published `trip-2026.10-v1` immutable; corrections versioned | Foundation/frozen distinction and immutable release rule | Pass |
| Partial/hash-mismatched candidate cannot replace usable package | Staging, exact SHA-256, package hash, atomic pointer rules | Pass |
| Save binds stable mission IDs and content version | Save schema/type and reconciliation rules | Pass |
| Bundled content opens without Pages, tiles, or Supabase | Permanent bundled fallback and rollback sequence | Pass as contract; cache implementation belongs to Infra/Frontend |

### BE-020

| Criterion | Evidence | Result |
|---|---|---|
| Fresh, in-progress, completed, manual, skipped, reset validate | Seven valid fixtures and schema validation | Pass |
| Completion/reward idempotent | Mission-keyed map; first resolved state wins; rewards derived; reducers return unchanged state on replay | Pass |
| Unknown IDs preserved but inactive | `unknown-id-recovery.json`, partition helper, validator active/unknown assertion | Pass |
| Below 256 KiB; no binary/base64 | Bounds, fixture byte checks, three invalid fixtures, generated oversize rejection | Pass |
| Drift-prone UI state derived | No stored reward/power/unlock/progress arrays; derivation boundary documented | Pass |

## Validation record

`node scripts/validate-contracts.mjs`

```text
PASS 32 JSON/GeoJSON files parse
PASS 12 versioned schemas use draft 2020-12 and all $ref targets resolve
PASS current manifest, sources, rewards, assets, IDs, references, exclusions, and exterior-first rules validate
PASS canonical mission example validates in the current bundle
PASS 6 content mutation fixtures fail with their expected diagnostics
PASS valid GeoJSON walk passes coordinate, order, mission, place, and chapter checks
PASS invalid GeoJSON fixture is rejected for range, order, mission, and place defects
PASS 7 save fixtures validate; unknown IDs remain preserved but inactive
PASS 3 invalid saves and a synthetic >256 KiB save are rejected
PASS TypeScript save contract matches schema version, states, fields, and 256 KiB limit
PASS content package file hashes and deterministic package hash validate
All 11 contract check groups passed.
```

PowerShell `Test-Json` independently validated all seven valid save fixtures and the valid walk against their JSON Schemas; all three invalid save fixtures were rejected.

## Necessary additive Story-contract corrections

- Added `rewardRegister` and `assetRegister` to the trip manifest so rewards/assets can be resolved instead of hard-coded.
- Defined optional `mission.assetIds`/`variant.assetIds` with default `[]`; no fake asset ID or placeholder art was introduced.
- Corrected the Story document’s `variants keyed by` wording to match the existing array of stable `id`/`pairId` records.
- Mission IDs, copy, itinerary meaning, Gardaland exclusion, exterior-first Verona behavior, and TBC day-trip slots did not change.

## Non-blocking follow-ups

- `content-package.json` is an integrity-checked **foundation**, not the travel freeze. Freeze/copy to the versioned release path belongs to `BE-060`/Infra.
- The asset register is intentionally empty until provenance-approved UX assets arrive; any later reference must resolve and the file must exist.
- The walk files are schema fixtures, not production Venice/Verona routes.
- Runtime JSON Schema library selection and atomic cache-pointer implementation belong to Frontend/Infra; the contract and failure behavior are complete.
- IndexedDB, migration/import, and Supabase work remain deferred to `BE-021+` and `BE-040+`.

## True blockers

None.
