# Missione Italia — Infrastructure Backlog

**Status:** implementation-ready plan; no code implemented here  
**Target:** frozen, trip-ready production build by 3 October 2026  
**Scope:** repository, PWA platform, local persistence, maps/location boundaries, CI/CD, quality, security, and operations

## Infrastructure decisions

| ID | Status | Decision |
|---|---|---|
| DEC-INF-01 | Resolved | Build a portable `missione-italia` package. Codex does not authenticate to, connect, push, or deploy through either the professional or personal GitHub account. |
| DEC-INF-02 | Resolved | Include GitHub Pages workflow/configuration and a `MANUAL_IMPORT.md`; the user imports the package into the personal repository. Base path and final URL remain configurable until import. |
| DEC-INF-03 | Deferred, non-blocking | V1 targets phone viewports only. Record the primary and backup phone model/OS/browser before the real-device release gate. |
| DEC-INF-04 | Resolved | The Supabase project exists, but IndexedDB remains authoritative. Cloud backup stays feature-flagged until all P0 local/offline tests pass. |

All static source, content, and built assets will be public. Nicknames, age bands, progress, precise location, photos, credentials, and private travel details must never be committed.

## Fixed technical choices

- React, TypeScript, and Vite.
- Installable PWA using `vite-plugin-pwa`.
- Phone-only V1 UI: 320–430 CSS px, portrait-first; tablet/desktop design is out of scope.
- One internal app state flow; no URL router for V1.
- GitHub Pages project-site workflow included in the package; the user performs personal-repository import and deployment.
- IndexedDB is the source of truth for family state; gameplay never requires a backend.
- Leaflet uses live OpenStreetMap raster tiles only while online.
- No service-worker prefetch or offline storage of `tile.openstreetmap.org` tiles.
- Offline maps are bundled illustrations and ordered checkpoint lists.
- Google Maps is opened through keyless Maps URLs; no Google Maps SDK or API key.
- Geolocation is foreground-only, initiated by a parent action, and never persisted.
- No application analytics, advertising, session replay, tracking pixels, or remote error service.
- No external font, script, icon, or animation CDN. Approved assets are self-hosted.
- Service-worker updates are prompted and applied only at a safe parent-controlled moment; never reload during a mission.

## Priority and dependency notation

- **P0:** required for the trip-ready release.
- **P1:** resilience or optional cloud work, attempted only after every P0 gate is green.
- **P2:** post-trip improvement.
- **UX-GATE:** selected visual direction, tokens, motion rules, and final asset list. No wireframe is required.
- **STORY-GATE:** stable mission/content fields, IDs, chapter order, and approved local assets.
- **BACKEND-GATE:** approved local-save contract; Supabase migrations/RLS are required only before cloud backup is enabled.

## Delivery sequence

| Date | Infrastructure outcome | Tasks |
|---|---|---|
| 29 Sep | Decisions and repository boundary locked | INF-001–INF-005 |
| 30 Sep | Deployable, installable shell | INF-006–INF-011 |
| 1 Oct | Durable local state, safe updates, and validated offline content | INF-012, INF-014–INF-017, INF-023–INF-025 |
| 2 Oct | Degraded states, maps/location, and automated checks | INF-013, INF-018–INF-022, INF-026–INF-027 |
| 3 Oct | Performance, security, real-phone field test, freeze, and rollback proof | INF-028–INF-039 |

## Foundation and repository

### INF-001 — Lock the portable handoff contract

**Priority:** P0  
**Dependencies:** DEC-INF-01–DEC-INF-04  
**Deliverable:** short decision record covering package boundaries, configurable Pages base path, deferred device matrix, and cloud-backup flag.

**Acceptance criteria:**

- Package defaults to repository slug `missione-italia`, while one documented setting controls any different Pages base path.
- The handoff explicitly states that a free GitHub Pages deployment and all static content are public.
- Personal GitHub owner, repository URL, Pages URL, and phone models are marked as manual deployment/release inputs rather than build blockers.
- `V1_CLOUD_BACKUP` defaults to `off`; missing cloud settings never fail the build or app.
- No credential, remote URL, GitHub token, or personal account identity is required to build and verify the local package.

### INF-002 — Establish a portable isolated source package

**Priority:** P0  
**Dependencies:** INF-001  
**Deliverable:** standalone source tree rooted at `missione-italia`, with no configured Git remote and with a clean manual-import boundary.

**Acceptance criteria:**

- The package can be copied into an empty personal repository without parent-workspace files or paths.
- Codex does not configure, read credentials for, push to, or deploy from a Git remote.
- Included workflows assume the personal repository's default branch is `main`; the manual guide explains the one-line change if it differs.
- `.gitignore` excludes `.env*` except `.env.example`, build output, coverage, test artifacts, local diagnostics, and editor files.
- No unrelated Learning files, private travel documents, photos, or parent-repository changes are staged.
- README states the public-data boundary and lists the supported local commands; `MANUAL_IMPORT.md` covers personal GitHub import, Pages enablement, validation, and rollback.

### INF-003 — Pin the toolchain and dependency baseline

**Priority:** P0  
**Dependencies:** INF-002  
**Deliverable:** reproducible Node/npm, React, Vite, and TypeScript project baseline.

**Acceptance criteria:**

- An active Node LTS version compatible with the selected Vite release is pinned locally and in CI.
- `packageManager` and a committed npm lockfile make `npm ci` reproducible from a clean clone.
- TypeScript strict mode is enabled; production code contains no unchecked blanket `any` escape hatch.
- Runtime dependencies are limited to the approved stack; design-gallery code and dependencies are not copied.
- A clean install and production build complete without unreviewed warnings.

### INF-004 — Create the source and command contract

**Priority:** P0  
**Dependencies:** INF-003, UX-GATE  
**Deliverable:** agreed repository structure and npm command surface.

**Acceptance criteria:**

- Source separates app shell, features, platform adapters, content access, styles, and tests.
- Static content and local assets live under versioned, predictable paths compatible with GitHub Pages.
- Commands exist for development, type-check, lint, unit tests, content validation, production build, preview, and full verification.
- Production uses one app entry and internal view state; refreshing the canonical URL cannot produce a Pages 404.
- All asset references are base-aware and avoid hard-coded root-relative paths.

### INF-005 — Define the public environment contract

**Priority:** P0  
**Dependencies:** INF-003  
**Deliverable:** typed environment schema, `.env.example`, and build-time validation.

**Acceptance criteria:**

- The app builds and runs with no Supabase variables present.
- Browser variables are limited to public configuration such as Supabase URL, Supabase publishable key, cloud feature flag, and configurable tile URL.
- Validation rejects variables named or shaped like Supabase secret or legacy service-role keys.
- `.env.example` contains placeholders only; local `.env` files are ignored.
- Documentation states that every `VITE_*` value is bundled and readable by anyone.

## CI, GitHub Pages, and installability

### INF-006 — Add the validation workflow

**Priority:** P0  
**Dependencies:** INF-003–INF-005  
**Deliverable:** GitHub Actions workflow for pull requests and pushes.

**Acceptance criteria:**

- The workflow uses `npm ci`, then type-checks, lints, validates content, tests, and builds.
- Validation jobs have `contents: read` only and receive no deployment or Supabase secrets.
- Node version exactly matches the pinned project version.
- Failed validation prevents deployment.
- All third-party actions are pinned to verified full commit SHAs with readable version comments.

### INF-007 — Configure the GitHub Pages base path

**Priority:** P0  
**Dependencies:** INF-001, INF-004  
**Deliverable:** one canonical base-path configuration shared by Vite, manifest, service worker, content, and asset URLs.

**Acceptance criteria:**

- A project site uses `/<repo>/`; a user site or later custom domain uses `/`.
- App code derives paths from Vite's base value rather than duplicating the repository slug.
- Local preview can run under the production subpath and catches root-relative URL mistakes.
- Manifest `start_url` and `scope` remain inside the project-site path.
- Opening the deployed URL, refreshing it, and launching the installed PWA all reach the same app shell.

### INF-008 — Build the Pages deployment workflow

**Priority:** P0  
**Dependencies:** INF-006, INF-007  
**Deliverable:** GitHub Actions build-artifact-deploy pipeline using the official Pages actions, plus user-run import/deployment instructions.

**Acceptance criteria:**

- GitHub Pages source is GitHub Actions, and only the built `dist` artifact is deployed.
- Build and deploy are separate jobs; deploy requires the successful build artifact.
- Deploy permissions are limited to `contents: read`, `pages: write`, and `id-token: write`.
- The deployment uses the `github-pages` environment and one concurrency group.
- Main pushes deploy production; pull requests validate but cannot deploy or gain write permissions.
- The job exposes the final Pages URL and runs an HTTP/app-shell smoke check after deployment.
- Delivery stops at validated local files: Codex never connects the professional GitHub identity, pushes to the personal repository, or activates Pages.
- `MANUAL_IMPORT.md` tells the user exactly which folders/files to copy, which repository settings to enable, and how to verify and roll back the first deployment.

### INF-009 — Create the PWA manifest and install assets

**Priority:** P0  
**Dependencies:** INF-007, UX-GATE  
**Deliverable:** valid web app manifest, icons, theme metadata, and platform-specific installation guidance.

**Acceptance criteria:**

- Manifest includes name, short name, stable app ID, base-safe start URL/scope, standalone display, theme/background colors, and portrait-friendly behavior.
- At minimum, 192 px and 512 px icons plus a maskable icon render correctly; no icon contains transparent unsafe-zone content.
- Apple touch icon and status-bar metadata are included without claiming unsupported install-prompt behavior on iOS.
- Android Chrome recognizes the app as installable; iPhone Safari can add it to the Home Screen.
- Parent-facing install instructions are available but never block browser use.

## Service worker and offline platform

### INF-010 — Select and implement the service-worker strategy

**Priority:** P0  
**Dependencies:** INF-007, INF-009  
**Deliverable:** `vite-plugin-pwa` configuration using the generated-service-worker path unless a documented requirement forces a custom worker.

**Acceptance criteria:**

- The service worker registers at the correct Pages subpath and controls the installed app.
- Update behavior is `prompt`, with no automatic reload during onboarding, a story, challenge, or celebration.
- Old versioned caches are removed only after the replacement worker activates safely.
- Registration failure leaves the online app usable and shows a parent-readable offline-readiness warning.
- Service-worker behavior is verified against the exact pinned plugin version before release.

### INF-011 — Define the precache boundary

**Priority:** P0  
**Dependencies:** INF-010, STORY-GATE  
**Deliverable:** audited list of files required for complete offline gameplay.

**Acceptance criteria:**

- App shell, every manifest-enabled chapter, every mission/quiz/reward, route illustrations, essential fonts, and required media are precached after the first complete load.
- OpenStreetMap tiles, Google URLs, Supabase responses, diagnostics, and future family photos are excluded.
- Oversized or missing assets fail the production build instead of being silently omitted by Workbox.
- A generated cache inventory records URL, revision, and compressed/uncompressed size.
- Airplane mode never produces a browser-default offline error for an in-app action.

### INF-012 — Implement safe application updates

**Priority:** P0  
**Dependencies:** INF-010, INF-015  
**Deliverable:** parent-controlled update state and content/app compatibility check.

**Acceptance criteria:**

- A waiting version displays a non-blocking parent action: “Update when ready.”
- Update is disabled while an unsaved transaction or mission completion is in flight.
- Current IndexedDB state is committed before activating and reloading into the new worker.
- App version, content version, database version, and commit SHA are visible in diagnostics.
- Upgrade and rollback tests prove that completed missions remain completed.

### INF-013 — Provide explicit offline and degraded states

**Priority:** P0  
**Dependencies:** INF-011, INF-021, UX-GATE  
**Deliverable:** platform state model for online, offline-ready, offline-not-ready, tile failure, and backend failure.

**Acceptance criteria:**

- Offline status is clear without persistent alarming banners or reliance on color alone.
- Missions, stories, quizzes, celebrations, passport, and parent overrides remain usable without network access.
- Map tile failure swaps to the bundled route/checkpoint fallback, not an empty grid.
- Google navigation is labeled as requiring an external online service and remains optional.
- Supabase outage or pause never blocks startup or local saves.

## IndexedDB and local-first state

### INF-014 — Define the IndexedDB schema

**Priority:** P0  
**Dependencies:** STORY-GATE  
**Deliverable:** versioned schema and TypeScript data contract for settings, family profile, progress, metadata, and optional sync outbox.

**Acceptance criteria:**

- The schema stores nicknames/role names, age bands, avatars, settings, mission completion, stamps, compass state, revision, and timestamps only.
- `meta` records database, content, and app versions.
- No precise location, location history, full name, birth date, photo, navigation history, or credential field exists.
- Keys are stable mission/chapter IDs, never translated display text or array positions.
- Multi-store changes required for one completion can be committed in one transaction.

### INF-015 — Implement local-first reads and writes

**Priority:** P0  
**Dependencies:** INF-014  
**Deliverable:** one persistence adapter used by all features.

**Acceptance criteria:**

- The app hydrates entirely from bundled content plus IndexedDB before any cloud request.
- A mission completion is idempotent and commits progress, reward, and revision atomically.
- The UI confirms completion only after the local transaction succeeds, or clearly reports a recoverable failure.
- Refresh, browser restart, installed-app force-close, network loss, and duplicate taps do not lose or duplicate progress.
- No feature writes directly to IndexedDB outside the adapter.

### INF-016 — Add schema and content-version migrations

**Priority:** P0  
**Dependencies:** INF-014, INF-022  
**Deliverable:** forward-only local database migrations plus mission-ID reconciliation rules.

**Acceptance criteria:**

- Every schema change has a deterministic migration from the previously released version.
- Renamed or removed mission IDs use an explicit mapping; completed progress is never silently discarded.
- Migration failure preserves the old data and offers parent recovery rather than resetting automatically.
- Automated fixtures cover empty, partial, completed, previous-version, and malformed local state.
- A rollback build can read the release save format or is explicitly blocked before deployment.

### INF-017 — Handle storage durability and deletion

**Priority:** P0  
**Dependencies:** INF-015  
**Deliverable:** storage health check, best-effort persistence request, and complete reset path.

**Acceptance criteria:**

- When supported, storage usage/quota and persisted status are available in Parent Corner diagnostics without requesting unrelated permissions.
- A best-effort `navigator.storage.persist()` request never blocks gameplay and never claims persistence when the browser returns `false`.
- IndexedDB unavailable/private-mode failures are detected before the trip begins; the app can continue in-session with a prominent “progress will not persist” warning.
- “Delete trip data” requires deliberate confirmation and removes the app's IndexedDB records and relevant app caches.
- Deletion never attempts to clear browser-wide data or unrelated origins.

### INF-018 — Add the optional cloud adapter boundary

**Priority:** P1  
**Dependencies:** INF-015, INF-016, BACKEND-GATE, DEC-INF-04=`on`  
**Deliverable:** feature-flagged save adapter and retry/outbox contract; backend implementation remains owned by the backend lane.

**Acceptance criteria:**

- With the flag off or environment absent, no Supabase code path or network request runs.
- Local commit always completes before sync is attempted.
- Offline, auth-expired, rate-limited, and paused-project failures leave a bounded retry item and never alter local success.
- Sync payload contains only the approved full save state and its content version/revision; it excludes location, diagnostics, and photos.
- Latest-save-wins conflict behavior is visible to the parent and covered by tests.

## Maps, navigation, and location

### INF-019 — Isolate Leaflet and the tile provider

**Priority:** P0  
**Dependencies:** INF-004, INF-007, UX-GATE  
**Deliverable:** lazy-loaded map feature behind a provider adapter.

**Acceptance criteria:**

- Leaflet code/CSS loads only when the map is opened and is not part of the first-screen bundle.
- Tile URL and attribution are configured in one place; “© OpenStreetMap contributors” remains visible and unobscured.
- The default URL is the current official HTTPS tile endpoint and can be replaced without editing feature code.
- The service worker has no prefetch, bulk-download, or custom runtime cache rule for public OSM tiles; ordinary browser HTTP caching headers are respected.
- Tile HTTP errors, slow responses, or total unavailability trigger INF-021 without blocking missions.

### INF-020 — Implement the foreground geolocation boundary

**Priority:** P0  
**Dependencies:** INF-015, INF-019  
**Deliverable:** a small location adapter with explicit state transitions.

**Acceptance criteria:**

- Location is requested only after “Where are we?” or another explicit parent-controlled action.
- V1 uses a one-shot foreground check; any later watch stops when its screen closes or the document is hidden.
- Success is kept in memory only and is never sent to IndexedDB, diagnostics, Supabase, or analytics.
- Permission prompt, granted, denied, timeout, unavailable, stale, and low-accuracy states each have a tested fallback.
- Proximity never hard-locks content: manual check-in/parent unlock always remains available.

### INF-021 — Build and test Google Maps URL handoff

**Priority:** P0  
**Dependencies:** INF-022  
**Deliverable:** deterministic URL builder for walking and driving directions.

**Acceptance criteria:**

- URLs use the official directions endpoint, include required `api=1`, encode all parameters, and stay below the documented URL length limit.
- Destination uses validated coordinates and an optional reviewed place ID; no Google API key is present.
- Origin is omitted so the Missione Italia app never passes stored/current coordinates to Google.
- The link opens in Google Maps when installed and in the browser otherwise, with a safe return path to the PWA.
- Tests cover walking, driving, negative coordinates, decimal separators, special characters, iOS, Android, and desktop fallback.

### INF-022 — Deliver the offline map fallback

**Priority:** P0  
**Dependencies:** STORY-GATE, UX-GATE, INF-011  
**Deliverable:** bundled chapter illustration, ordered checkpoints, distances supplied by approved content, and manual next-stop control.

**Acceptance criteria:**

- Venice and Verona short/full walks are usable without map tiles or GPS.
- Each checkpoint has a stable ID, title, illustration/marker, sequence, and manual completion path.
- The fallback never implies live turn-by-turn routing or current-position accuracy.
- “Open external navigation” is separate from progressing the game.
- A complete offline walkthrough reaches every required mission and final reward.

## Content validation and asset integrity

### INF-023 — Lock machine-readable content schemas

**Priority:** P0  
**Dependencies:** STORY-GATE  
**Deliverable:** one authoritative schema for trip, chapters, missions, role clues, rewards, places, and curated walks.

**Acceptance criteria:**

- Required fields, enum values, localization-ready strings, stable IDs, content version, and asset references are explicit.
- GeoJSON geometry types and coordinate order are constrained.
- Mission schema supports the visual, simple-reasoning, and harder-clue contributions without storing child identity.
- Runtime types and build validation derive from or are checked against the same schema source.
- Content changes cannot bypass the validator in CI.

### INF-024 — Add semantic content validation

**Priority:** P0  
**Dependencies:** INF-023  
**Deliverable:** deterministic validator run locally and in CI.

**Acceptance criteria:**

- CI fails on duplicate IDs, broken chapter/mission/checkpoint references, missing answers/rewards, missing assets, invalid GeoJSON, swapped/out-of-range coordinates, or unsupported role/difficulty values.
- Destination-specific bounds catch coordinates far outside optional Basel/Road, Venice, Murano/Burano, Verona, or approved day trips; Gardaland is not an app destination.
- Walk checkpoints are ordered, unique, and reference known places/missions.
- Filenames are checked case-sensitively so Windows-authored content works on GitHub Pages.
- Content-supplied URLs reject non-HTTPS and unsafe schemes; navigation URLs are generated in code rather than copied into JSON.

### INF-025 — Audit offline assets and package size

**Priority:** P0  
**Dependencies:** INF-011, INF-024  
**Deliverable:** production-build asset report and cache-coverage test.

**Acceptance criteria:**

- Every referenced essential asset exists, is licensed/owned, optimized, and included in the offline cache inventory.
- No design-inspiration site asset, hotlink, remote font, or undocumented third-party resource ships.
- Images have explicit dimensions/aspect ratios and appropriate compressed mobile formats.
- Optional audio or large celebration media has a text/static fallback and cannot prevent service-worker installation.
- The report enforces the size budgets in INF-029.

## Automated and real-device verification

### INF-026 — Build the unit and contract test suite

**Priority:** P0  
**Dependencies:** INF-015, INF-016, INF-020, INF-021, INF-024  
**Deliverable:** fast deterministic tests for infrastructure-critical logic.

**Acceptance criteria:**

- Tests cover state hydration, atomic/idempotent completion, migrations, reset, feature flags, location state mapping, proximity math, and Maps URL construction.
- IndexedDB tests use a controlled browser-compatible implementation, not mocks that bypass transactions.
- Content fixtures include valid and intentionally invalid cases for every validator rule.
- Time, random IDs, and network are controlled; tests are repeatable offline.
- Any regression that could lose progress or hard-lock a mission fails CI.

### INF-027 — Add production-preview integration tests

**Priority:** P0  
**Dependencies:** INF-008, INF-010–INF-013, INF-026  
**Deliverable:** browser tests against the built app under the real repository subpath.

**Acceptance criteria:**

- A clean browser can load, complete setup, finish a mission, reload, and retain progress.
- After one successful online visit, the test blocks all network and restarts into a playable mission/passport experience.
- Tiles and Supabase are independently blocked to prove their failures are non-essential.
- Tests cover a waiting service-worker update and preserve state across activation.
- Console errors, unhandled rejections, mixed content, missing assets, and unexpected network hosts fail the run.

### INF-028 — Execute the actual-phone acceptance matrix

**Priority:** P0  
**Dependencies:** DEC-INF-03, INF-027, INF-029–INF-035  
**Deliverable:** signed test record with screenshots only where they contain no private information.

**Acceptance criteria:**

- Primary and backup phones each complete browser launch, installation, standalone launch, setup, mission, reward, and restart.
- Airplane-mode launch is tested after force-closing the installed app, not only with DevTools offline emulation.
- Location allowed, denied, system-location-off, timeout/weak signal, and manual check-in paths are exercised.
- Google walking/driving links reach the intended checkpoint on each phone.
- Portrait, landscape, large text, reduced motion, muted audio, low battery mode, and accidental double taps remain usable.
- Device/browser versions, pass/fail, blockers, and retest evidence are recorded.

### INF-029 — Run a short outdoor field test

**Priority:** P0  
**Dependencies:** INF-028  
**Deliverable:** one nearby walking test on the production candidate.

**Acceptance criteria:**

- Test covers a location check in open sky, a weak/obstructed position, network loss, external navigation handoff, manual override, and return to the PWA.
- Screen interaction while moving is avoided; missions can pause safely when the family needs attention elsewhere.
- No breadcrumb trail or precise coordinate remains after closing/reopening the app.
- Any confusing permission, offline, or recovery state is fixed and retested before freeze.
- All children can contribute without the phone becoming the main activity.

## Performance and motion

### INF-030 — Enforce mobile performance budgets

**Priority:** P0  
**Dependencies:** INF-019, INF-025, UX-GATE  
**Deliverable:** documented budgets and automated build-size checks.

**Acceptance criteria:**

- Initial JavaScript is at most **180 KiB gzip**; map code is lazy and excluded from that initial chunk.
- Initial CSS is at most **40 KiB gzip** and first-screen transfer, excluding map tiles, is at most **500 KiB compressed**.
- Essential offline precache targets **15 MiB** and cannot exceed **25 MiB** without an explicit release decision.
- Lab targets on a mobile profile are LCP ≤ 2.5 s, INP ≤ 200 ms, and CLS ≤ 0.1; failures are investigated on the actual primary phone.
- No core transition produces a main-thread task over 50 ms on the primary phone without a documented exception.

### INF-031 — Protect 60 fps interaction and battery use

**Priority:** P0  
**Dependencies:** INF-030, UX-GATE  
**Deliverable:** motion implementation checklist and real-device trace for the heaviest custom celebration/transition.

**Acceptance criteria:**

- Custom animations use compositor-friendly transforms/opacity and target the 16.7 ms frame budget on a 60 Hz phone.
- The selected celebration and screen transitions show no sustained frame drops in the primary-phone trace.
- Reduced-motion mode removes non-essential travel, parallax, looping, and flashing while preserving meaning.
- Map rendering is not animated behind covered screens; timers/listeners stop when screens unmount or the document is hidden.
- Audio, geolocation, and animation loops never continue in the background.

## Diagnostics, privacy, and security

### INF-032 — Add local-only diagnostics without tracking

**Priority:** P0  
**Dependencies:** INF-012, INF-017  
**Deliverable:** Parent Corner diagnostics panel and bounded local error-code buffer.

**Acceptance criteria:**

- Panel shows app/content/database versions, commit SHA, service-worker state, offline readiness, storage usage/persistence, feature flags, and connectivity.
- It shows location permission/status only, never coordinates or accuracy history.
- At most 20 sanitized error codes/timestamps are retained locally; no nickname, answer, URL query, auth token, stack containing local paths, or child data is stored.
- Copy/export requires a deliberate parent action and previews exactly what will be copied.
- No diagnostics request leaves the device; GitHub Actions deployment logs are the only app-team operational logs.
- Network audit permits same-origin assets, live OSM tiles while the map is visible, optional enabled Supabase, and Google only after a navigation tap.

### INF-033 — Add infrastructure error recovery

**Priority:** P0  
**Dependencies:** INF-013, INF-015, INF-032  
**Deliverable:** error boundary and recovery catalogue with stable error codes.

**Acceptance criteria:**

- Render, content-load, IndexedDB, service-worker, map, location, and optional cloud failures have distinct parent-readable recovery paths.
- A feature-level failure does not blank the whole app when passport/manual mission access can remain available.
- Recovery offers retry, continue offline, manual override, diagnostics, or deliberate reset as appropriate.
- Reset is never the first or automatic response to a storage/migration problem.
- No raw exception, token, internal path, or third-party response body is shown to children or stored.

### INF-034 — Produce the threat model and privacy inventory

**Priority:** P0  
**Dependencies:** INF-005, INF-014, INF-018, INF-020  
**Deliverable:** one-page data-flow/threat review covering public hosting, device storage, location, navigation handoff, and optional Supabase.

**Acceptance criteria:**

- Data is classified as public static, local family, ephemeral sensitive location, optional authenticated cloud, or prohibited.
- Threats include accidental publication, XSS/content injection, malicious links, exposed keys, over-broad RLS, location retention, lost phone, stale service worker, dependency compromise, and child-triggered destructive actions.
- Every threat has an owner, preventative control, detection/test, and recovery step.
- Privacy copy accurately says the app adds no analytics while GitHub Pages and requested external providers receive ordinary request metadata; GitHub documents that Pages logs visitor IPs for security.
- No production approval relies on a pretend Parent Corner PIN or long-press as a security boundary.

### INF-035 — Harden the static client

**Priority:** P0  
**Dependencies:** INF-019–INF-024, INF-034  
**Deliverable:** reviewed client security policy compatible with GitHub Pages and Leaflet.

**Acceptance criteria:**

- Content renders as text/components; raw HTML injection, `eval`, dynamic script insertion, and unsafe URL schemes are absent.
- A tested CSP meta policy restricts scripts/workers/manifest to self and permits only required image/connect origins. Its inability to enforce `frame-ancestors`, sandboxing, or violation reporting is documented.
- Referrer policy does not suppress the valid Referer required by the OSM tile policy.
- External windows use safe opener isolation, and only parent actions can initiate external navigation.
- Production contains no source maps with private paths unless deliberately reviewed, no secrets, and no unapproved third-party calls.

### INF-036 — Secure dependencies and workflows

**Priority:** P0  
**Dependencies:** INF-003, INF-006, INF-008  
**Deliverable:** supply-chain policy and automated dependency checks.

**Acceptance criteria:**

- Lockfile is mandatory and CI uses `npm ci`; dependency additions require an explicit purpose and license review.
- Dependabot alerts/updates and dependency review are enabled for the public repository.
- New known high/critical runtime vulnerabilities block release; accepted exceptions identify exposure, mitigation, and removal date.
- Workflow actions are full-SHA pinned, permissions are explicit, and untrusted pull-request code never receives deployment write access.
- Repository and built-artifact searches find no password, token, Supabase secret/service-role key, private URL, or personal trip file.

### INF-037 — Verify optional Supabase containment

**Priority:** P1  
**Dependencies:** INF-018, BACKEND-GATE  
**Deliverable:** browser/backend integration security evidence.

**Acceptance criteria:**

- Only the current Supabase publishable key is used by the browser; secret and legacy service-role keys are absent from source, CI, artifacts, and diagnostics.
- RLS and table grants deny signed-out access and cross-owner select/insert/update/delete attempts.
- Auth expiration, revoked sessions, network loss, and a paused free project preserve local gameplay and local progress.
- “Delete trip data” removes the authenticated parent's cloud save when online and makes local deletion available regardless of backend state.
- Cloud backup remains feature-flagged off until these tests pass in the production build.

## Release, rollback, and operations

### INF-038 — Create and rehearse the release/rollback mechanism

**Priority:** P0  
**Dependencies:** INF-008, INF-012, INF-016, INF-027  
**Deliverable:** immutable trip-ready release tag, retained build metadata, and tested redeploy procedure.

**Acceptance criteria:**

- Production candidate embeds commit SHA/content/database versions and is tagged `trip-ready-2026-10-03` after acceptance.
- The corresponding built artifact, checksums, validation report, and device-test record are retained with the release.
- A manual deployment can rebuild and deploy a named known-good tag using the lockfile; it cannot silently deploy an arbitrary moving branch.
- Rollback from a deliberately broken candidate to the previous known-good tag is rehearsed on Pages.
- Existing local progress survives forward deployment and rollback, and installed clients receive a safe prompted update.

### INF-039 — Freeze production and publish the runbook

**Priority:** P0  
**Dependencies:** all P0 tasks  
**Deliverable:** concise parent/operator runbook and signed release gate.

**Acceptance criteria:**

- Runbook covers clean install, first online cache, Add to Home Screen, offline verification, update, deployment smoke test, rollback, reset, and direct-browser fallback.
- If Supabase is enabled, the runbook also covers checking/resuming a paused free project, but clearly states that gameplay does not depend on it.
- Production is frozen after the 3 October field test; only blocking fixes may create a new tagged candidate.
- Final network audit finds no analytics or unapproved host, and final artifact audit finds no private data or secret.
- Primary phone passes install → airplane-mode restart → mission completion → force-close → progress recovery on the exact production URL.
- A known-good installed copy and the bundled offline checkpoint lists remain available for 4 October travel.

## Trip-ready infrastructure gate

Infrastructure is complete only when all of the following are evidenced:

- A clean clone can install, verify, build, and reproduce the deployed artifact.
- GitHub Pages serves every asset from the correct repository subpath over HTTPS.
- The PWA installs and restarts offline on the actual primary phone.
- All essential content is cached; map tiles, Google, and Supabase are non-essential.
- Progress is transactional, versioned, migration-tested, and retained across reload/update/rollback.
- Geolocation is explicit, foreground-only, ephemeral, and manually bypassable.
- No secret, precise location, child data, or private photo is published or transmitted unexpectedly.
- Custom interactions meet the performance budgets on the primary phone.
- Rollback has been rehearsed, not merely documented.

## Official references checked 29 September 2026

- [Vite: Deploying a Static Site](https://vite.dev/guide/static-deploy)
- [GitHub: What is GitHub Pages?](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages)
- [GitHub: Using custom workflows with GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages)
- [GitHub: Secure use reference for Actions](https://docs.github.com/en/actions/reference/security/secure-use)
- [GitHub: Dependency review](https://docs.github.com/en/code-security/concepts/supply-chain-security/dependency-review)
- [Vite PWA: Service-worker strategies and behaviors](https://vite-pwa-org.netlify.app/guide/service-worker-strategies-and-behaviors)
- [OpenStreetMap Foundation: Tile Usage Policy](https://operations.osmfoundation.org/policies/tiles/)
- [Google Maps: Maps URLs](https://developers.google.com/maps/documentation/urls/get-started)
- [MDN: IndexedDB API](https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API)
- [MDN: StorageManager.persist()](https://developer.mozilla.org/en-US/docs/Web/API/StorageManager/persist)
- [MDN: Geolocation API](https://developer.mozilla.org/en-US/docs/Web/API/Geolocation_API)
- [web.dev: Core Web Vitals thresholds](https://web.dev/articles/defining-core-web-vitals-thresholds)
- [web.dev: Rendering performance](https://web.dev/articles/rendering-performance)
- [OWASP: Content Security Policy Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Content_Security_Policy_Cheat_Sheet.html)
- [Supabase: API keys](https://supabase.com/docs/guides/getting-started/api-keys)
- [Supabase: Row Level Security](https://supabase.com/docs/guides/database/postgres/row-level-security)
- [Supabase: Free project pausing](https://supabase.com/docs/guides/platform/free-project-pausing)
