# Story Wave 1 Handoff

**Scope:** `ST-010`–`ST-035` · **Runtime authority:** `public/content/trip-manifest.json` · **Prepared:** 29 September 2026

## Gate result

Story Wave 1 is complete: exactly 16 scored missions plus unscored `RETURN-EP` retain their stable IDs and order. Every fixed mission and all six manifest-driven excursion variants have a 50–67 word parent-read story, objective, Spotter/Detective/Navigator actions, resolution, kind retry, explanation, success, safety, four fallbacks, source/review dates, and offline/no-dependency behavior.

`VER-04` and `VER-05` remain TBC slots. `selectedPairId` is still `null`; no excursion was assumed. Monday has no mission. The excluded family day has no chapter, mission, reward, source consumer, or asset. `ROAD-02` stays route-neutral. `VER-01` and `VER-02` fully complete outside.

## Task evidence

| Task | Status | Concrete evidence |
|---|---|---|
| `ST-010` | Complete | `trip-manifest.json#/narrative/opening`: 56-word opening, youngest tap, oath, exactly three tutorial steps. |
| `ST-011` | Complete | Road chapter, `ROAD-01`–`03`, and unscored `RETURN-EP`; driver-phone prohibitions and parked/safe-stop modes included. |
| `ST-012` | Complete | Lagoon Islands chapter and `ISL-01`–`03`; glass/navigation/colour/lace maker arc with FACT/TRADITION/LEGEND separation. |
| `ST-013` | Complete | Venice chapter and `VEN-01`–`04`; lion/bridge/boat/quiet-sensory arc with crowd, water-edge, weather, and offline fallbacks. |
| `ST-014` | Complete | Verona chapter, `VER-01`–`06`, six candidate variants, and anywhere finale; Roman, literary, Adige, Scaliger, garden/village/lake threads join Teamwork. |
| `ST-015` | Complete | `narrative.states` supplies interruption, resume, skip, manual, retry, offline, closed, tired, weather, Monday-silent, and two ending variants. |
| `ST-016`–`ST-019` | Not defined | No tasks with these IDs exist in `planning/STORY_TASKS.md`; nothing was inferred. |
| `ST-020` | Complete | `ROAD-01`: parent-announced country clues; stationary/manual fallback; no border detection. |
| `ST-021` | Complete | `ROAD-02`: no named route feature, GPS, or driver interaction; light-dark-light fallback is explicit. |
| `ST-022` | Complete | `ROAD-03`: five English-complete Italian phrases with pronunciation aid and gesture; no audio or stranger interaction. |
| `ST-023` | Complete | `ISL-01`: observable Murano pattern; no entry, touch, photo, furnace, or purchase dependency. |
| `ST-024` | Complete | `ISL-02`: stationary symbol matching; parent owns service and boarding decisions; volatile source recheck 6 October. |
| `ST-025` | Complete | `ISL-03`: colour-plus-shape and lace clue; official FACT, TRADITION, and LEGEND labels; homes/residents protected. |
| `ST-026` | Complete | `VEN-01`: sourced winged-lion answer, hints, safe public view, and text-card fallback. |
| `ST-027` | Complete | `VEN-02`: alternate bridge works; material/arch comparison; no leaning, climbing, running, or blocking. |
| `ST-028` | Complete | `VEN-03`: compares two boat roles/shapes; parent controls all real transport; no promised vessel. |
| `ST-029` | Complete | `VEN-04`: family stops first, parent lowers phone, sound is optional, visual cards are equivalent, no recording. |
| `ST-030` | Complete | `VER-01`: sourced Roman fact, non-graphic copy, exterior is full completion, interior never required. |
| `ST-031` | Complete | `VER-02`: exterior trail to Piazza Erbe; documented history, literary tradition, and OUR STORY are distinct. |
| `ST-032` | Complete | `VER-04/sigurta-team-maze`: nature/navigation candidate with no-rush, stay-together, card/manual, closure, and weather paths. |
| `ST-033` | Complete | `VER-05/borghetto-water-mill`: mill fact vs Lover's Knot legend; safe route stays away from river edge. |
| `ST-034` | Complete | `VER-04/sirmione-castle-water`: sourced castle/harbour shapes; exterior/card completion; parking remains parent-only. |
| `ST-035` | Complete | `VER-06`: one action per role, any completion count, quiet/static anywhere finale, no perfect-score gate. |

The apparent `ST-032`–`ST-034` mission numbers in the original backlog were reconciled to the locked slot model without renaming runtime IDs: Sigurtà and Sirmione are `VER-04` candidates; Borghetto is a `VER-05` candidate.

## Additive content contract for Backend review

- Top-level `narrative` owns opening and reusable state copy.
- Missions require `fact_checked_on` and `review_after`.
- `completion` adds `retryLine` and `explanation`.
- Phrase records add `pronunciation` and `gesture`.
- Excursion variants now carry the full playable mission subset.

These additions are reflected in `schemas/content/v1`, the canonical mission example, `docs/content-contract.md`, and `scripts/validate-contracts.mjs`. They do not alter save schema version 1, completion state names, cloud behavior, IDs, rewards, or scoring.

## Validation

- `npm run validate:content`: passed all 11 contract groups, including 32 JSON/GeoJSON parses, 12 schema/reference checks, manifest invariants, canonical fixture, invalid fixtures, save-contract isolation, and deterministic package hashes.
- `npm run verify`: passed typecheck, zero-warning lint, content validation, 14/14 tests, production build, and precache audit. The first sandboxed test launch hit Windows `spawn EPERM`; the permitted local rerun completed cleanly.

## Non-blocking follow-ups

- Parent still chooses the Friday pair; the recommendation remains Sigurtà + Borghetto.
- Recheck volatile visitor/service sources on their recorded dates; failed checks hide operational guidance, not missions.
- `ST-054` remains the independent pre-freeze review of the five Italian pronunciation aids.
- Illustration/card polish may replace text-native fallback cards later, but no mission depends on it.

## Blockers

None.
