# Story Foundation Wave 0 Handoff

**Completed:** 29 September 2026 · **Scope:** `ST-001`–`ST-009` · **Result:** ready for UX/Frontend/Backend formalization; no implementation code added

| Task | Status | Acceptance evidence |
|---|---|---|
| `ST-001` | Complete | `planning/TRIP_CALENDAR.md` is the dated scheduling authority, covers 4–10 Oct with origin/activity/overnight/app inclusion, generic lodging where unknown, and verified weekdays. |
| `ST-002` | Complete by deliberate defer | `planning/TRIP_CALENDAR.md` and `public/content/trip-manifest.json` lock Thu morning/afternoon and Fri morning/afternoon anchors. Thursday extra and Friday destination stay `TBC`; stable `VER-04`/`VER-05` slots let product work continue. |
| `ST-003` | Complete | `docs/content-language-accessibility.md`: English + small Italian layer, parent read-aloud P0, age-role actions, nicknames only, color/hearing/motion/reading fallbacks. |
| `ST-004` | Complete | `docs/story-bible.md`: compact Bussola canon, four powers, no-villain stakes, arc/finale, rotation, recurring phrases, prohibited themes, fact/tradition/legend/fiction boundary. |
| `ST-005` | Complete | `docs/content-style-and-safety.md`: copy limits, voice, evidence labels, cooperative/skip language, Italian formatting, setting-specific safety and pre-publish checks. |
| `ST-006` | Complete | `docs/source-register.md` + `public/content/sources.json`: 26 claim records with official URL, page, publisher, retrieved date, type, paraphrased claim, stability, recheck date, and consumers. |
| `ST-007` | Complete for Story handoff | `docs/content-contract.md` + `public/content/examples/mission.example.json` + manifest: chapters, missions, roles, choices, facts, sources, rewards, locations, fallbacks, dependencies, and stable excursion-slot behavior. Backend JSON Schema remains its planned formalization task. |
| `ST-008` | Complete | `docs/rewards-passport.md`: four powers, six reusable team stamps, celebrations, unlock/resume/offline vocabulary, and resolved-state behavior without individual scores. |
| `ST-009` | Complete | `public/content/trip-manifest.json` + `docs/mission-beat-sheet.md`: exactly 16 scored missions in calendar order plus unscored `RETURN-EP`; Friday cancellation/manual/skip cannot block `VER-06`. |

## Locked constraints encoded

- English carries full meaning; Italian is optional. Parent read-aloud is P0.
- One parent phone; cooperative Spotter/Detective/Navigator contributions for ages 4/7/9; roles may swap.
- Nicknames only. Inclusive no-sound, no-motion, no-color-only, tired, rain, closed, and manual paths remain.
- No mission depends on GPS, audio, ticket, live data, or venue entry.
- Arena and Juliet missions are fully playable outside; interior guidance is deferred.
- Gardaland is absent and listed in `excludedContent` only.
- Road chapter is included; Saturday epilogue is optional and unscored.

## Non-blocking assumptions and follow-ups

- Exact Gardaland-area, Venice-area, and Verona hotel localities remain TBC and are not needed by Story foundation.
- Thursday optional short trip and Friday pair remain a parent choice. Recommended: no Thursday car trip; Friday Sigurtà + Borghetto. Selection only changes `VER-04`/`VER-05` variants.
- Italian pronunciations need the planned independent language check before `ST-054`; current P0 needs no audio.
- Volatile official information must be rechecked on the dates in `sources.json`; failing verification hides operational copy, not the mission.
- Full per-mission 30–60 second scripts and production localization keys belong to downstream `ST-010`–`ST-056`, not Wave 0.
- Formal JSON Schema, hashes, and immutable freeze remain Backend/`ST-064`–`ST-066` work.

## Validation record

Run after any content edit:

1. Parse all JSON.
2. Assert 16 `scored: true` records and one `scored: false` epilogue.
3. Assert unique mission/source IDs; calendar order 1–17.
4. Resolve every chapter mission ID and external fact/source ID.
5. Assert every scored mission has three distinct roles, four fallback keys, allowed completion states, `offlineCritical: true`, and all four dependency flags `false`.
6. Assert `gardaland` occurs only in calendar/planning exclusions and manifest `excludedContent`, never as a mission/chapter/source.

