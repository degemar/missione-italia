# UX/UI Wave 1 handoff — UX-005 through UX-007

**Status:** contract work complete  
**Prepared:** 29 September 2026  
**Runtime content authority:** `public/content/trip-manifest.json`  
**Asset truth boundary:** only files already present in `public/content/assets.json` are runtime assets

No UI screens, wireframes, final story art, fonts, sound, emoji substitutes, placeholder boxes, CSS drawings, or handwritten SVG assets were created.

## Deliverables

| Task | Artifact | Implementation purpose |
|---|---|---|
| UX-005 | [`docs/cooperative-mission-interaction.md`](../docs/cooperative-mission-interaction.md) | Deterministic role rotation/reassignment, read-aloud/look-up loop, clue/choice/observation behavior, retry/manual/skip, persistence and reward semantics, TBC variants |
| UX-006 | [`docs/motion-and-celebration-system.md`](../docs/motion-and-celebration-system.md) | Exact timing/choreography, shared Bussola continuity, celebration storyboards, segment formula, reduced motion, default-off P1 sound |
| UX-006 | [`docs/design-tokens.json`](../docs/design-tokens.json) and [`docs/design-tokens.md`](../docs/design-tokens.md) | Machine/human motion tokens: response, timing, delay, distance, scale, easing, performance, reduced-motion slots |
| UX-007 | [`docs/asset-production-contract.md`](../docs/asset-production-contract.md) | Illustration system, exact prompts, inventory, dimensions/crops, alt intent, 1×/2×, light/dark, budget, provenance/licence gate |
| UX-007 | [`planning/UX_ASSET_PRODUCTION_MANIFEST.json`](UX_ASSET_PRODUCTION_MANIFEST.json) | Planning-only machine inventory separating five verified existing assets from twelve real assets still to generate |

## Acceptance evidence

### UX-005 — cooperative mission interaction

| Acceptance criterion | Evidence | Result |
|---|---|---|
| Every mission gives Spotter, Detective, and Navigator meaningful actions | Mission loop, role contribution table, manifest-driven role copy | Pass |
| Roles rotate visibly and can be reassigned without penalty | Deterministic formula, swap/session/reload rules | Pass |
| Pointing/read-aloud can complete a mission; typing is never required | Read-aloud, mission-mode table, accessibility invariants | Pass |
| Youngest child's action affects completion | Three-role normal-completion gate explicitly includes assigned age-four action | Pass |
| Family receives one reward; no individual score/leaderboard | Persistence/reward section and keyed idempotency | Pass |
| Clue reveal, answer/observation, hint, retry, manual and skip are defined | Mission loop and dedicated interaction sections | Pass |
| Persistence completes before Celebration | Resolve transaction boundary; memory-only result is explicit before navigation | Pass |
| TBC variants preserve stable mission/reward flow | `VER-04`/`VER-05` rules and `resolvedVariantId` behavior | Pass |

### UX-006 — motion and celebration

| Acceptance criterion | Evidence | Result |
|---|---|---|
| Tap response ≤100 ms; transitions 150–300 ms; celebrations ≤2.5 s and skippable | Exact token table, choreography, 600 ms skip, 2200/2500 ms ceilings | Pass |
| Transform/opacity motion targets 60 fps on family phone | Property constraints, 16.67 ms frame budget, maximum two moving elements, field gate | Contract pass; physical-phone measurement remains UX-012/Infra |
| Bussola links Mission, Celebration, Atlas, and Passport | Shared-object section with crossfade fallback | Pass; transparent character asset remains to generate |
| Power/finale segments derive from manifest | `segmentCount = chapters.length` and compressed timing formula | Pass |
| No looping motion competes with reading/maps/permissions | System principle, choreography, performance gate | Pass |
| Reduced motion removes spatial/decorative motion without hiding state | Reduced-motion section and tokens | Pass |
| Sound is default-off and muted success is complete | Save default, P1 cue contract, no wrong/skip/error sounds | Pass |

### UX-007 — illustration and assets

| Acceptance criterion | Evidence | Result |
|---|---|---|
| Bussola is an original brass travel object, not human-child/derivative | System rules and exact character prompt anchored only to verified project icon | Pass |
| Chapter art shares line, texture, palette, light, crop, and density rules | One illustration system, derivative/crop rules, common base prompt | Pass |
| Lagoon art distinctly covers boat, glass, lace, and colourful streets respectfully | Exact Lagoon subject clause and explicit commercial/resident exclusions | Pass |
| Phosphor version/MIT licence and original-art provenance are recorded | Installed package evidence; 2.1.10 exports/licence; six-step provenance gate | Pass |
| No fake visible assets stand in for missing art | Asset truth boundary and final prohibition | Pass |
| Essential assets are local, optimized, 1×/2×, and budgeted | Runtime file matrix and 2 MiB new / 4 MiB total targets | Pass |
| Every asset has informative/decorative/label-equivalent intent | Existing/planned tables and planning manifest | Pass |
| PWA/install assets and existing hashes/provenance are factual | Five-file evidence table and verified README/tool record | Pass |
| Asset register contains only files that exist | `public/content/assets.json` unchanged; existing file/hash verification | Pass |

## Existing evidence captured

- `@phosphor-icons/react@2.1.10` is installed/locked; its local licence file is MIT and all ten named exports resolve.
- Bussola master is 1254×1254, 2,082,101 bytes, SHA-256 `92ce7573bae68f6c336b5745debdc3f01375b378146f2e034238ef91fab19a6d`; all four icon derivative dimensions, bytes, and hashes match the runtime register/provenance README.
- Pillow `11.3.0` matches the derivative provenance record.
- Current production precache before new art is 1,046,361 raw bytes / 813,553 gzip bytes.
- Vite/PWA manifest already uses the existing 192/512/maskable icons, paper background, teal theme, and portrait-primary orientation.

## Still to generate or acquire

- One transparent Bussola character master and two runtime WebP derivatives.
- Five scene masters—Road, Venice, Lagoon Islands, Verona, epilogue—and ten 1×/2× WebP derivatives. The four chapter images double as offline route-card art.
- Six stamp masters and twelve 1×/2× transparent WebP derivatives.
- Exact self-hosted Fredoka and Atkinson Hyperlegible Next WOFF2 files plus authoritative version/source/OFL evidence; these are acquisitions, not generated art.
- Optional P1 sound cues (`success-soft`, `stamp-paper`, `power-chime`) remain unproduced and default-off.

No separate role-symbol, map-marker, offline-route, install-splash, or additional PWA icon raster is required.

## Validation record

| Check | Result |
|---|---|
| `design-tokens.json` and planning asset JSON parse | Pass |
| Token references resolve | Pass |
| Manifest contains 16 scored + one epilogue; every playable record has three roles and valid resolved states | Pass |
| Three TBC pairs map to morning/afternoon variants | Pass |
| Motion response/transition/celebration/reduced values satisfy contract | Pass |
| Existing runtime asset paths, dimensions, byte sizes, and SHA-256 match register/provenance | Pass |
| Planned IDs are absent from runtime asset register | Pass |
| Internal Markdown links resolve | Pass |
| `npm run verify` | Pass — typecheck, zero-warning lint, 11 content groups, 47 tests, production build, service worker and precache audit |

## Non-blocking assumptions

- Story art generation/selection is the next asset-production step; implementation uses actual functional icons and text until approved files exist.
- Physical-phone 60 fps and outdoor visual QA remain release evidence for UX-012/Infra, not claims from this contract pass.
- Font package/version and licence evidence stays pending until the exact files are acquired; system fallbacks remain valid.
- `selectedPairId` may remain null; manual/skip keeps both slots and finale playable.

## True blockers

None for completing UX-005 through UX-007 contracts. Final visual implementation cannot claim the shared Bussola character, chapter scenes, stamps, or custom fonts until those real files pass the registration gate.
