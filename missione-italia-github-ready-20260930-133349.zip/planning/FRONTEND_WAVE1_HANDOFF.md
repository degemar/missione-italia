# Frontend Wave 1 handoff

**Completed:** 30 September 2026  
**Scope:** `FE-001`–`FE-015`  
**Result:** playable local-first React journey complete; full verification passes

The production entry now runs the Lost Compass journey instead of the infrastructure placeholder. It uses the existing local repository/controller boundary, the validated manifest, the real generated app icon, bundled Phosphor icons, and system fonts. No Git remote, deployment, account, Supabase, map, geolocation, analytics, or cloud code was accessed or added.

## Acceptance evidence

| Task | Implementation evidence | Result |
|---|---|---|
| `FE-001` | `src/app/app-state.ts` defines the typed single reducer and safe saved-route recovery for boot, welcome, setup, atlas, chapter, mission stages, celebration, Passport, epilogue, parent, and degraded states. Invalid routes recover to Atlas; no URL router exists. | Pass |
| `FE-002` | `src/components/AppShell.tsx` and `src/styles/global.css` provide the phone shell, safe areas, sticky primary action, back/Passport controls, focus target, ≥48 px actions, no-hover interactions, reduced-motion handling, and a 320–430 CSS px layout. | Pass; browser visual QA intentionally delegated to root |
| `FE-003` | `src/content/content-repository.ts` loads five base-safe bundled JSON files, validates manifest/playable mission/variant shape and package compatibility, sorts by manifest order, resolves references, and exposes chapters, missions, rewards, sources, assets, walks, and lookup maps through one typed bundle. | Pass |
| `FE-004` | `src/i18n/strings.ts` owns visible interface copy and interpolation; TS key types reject missing static keys. Destination story/fact/safety text stays manifest-owned. `InstallGuide` was also moved onto the same string layer. | Pass |
| `FE-005` | `src/app/game-controller.ts`, `src/app/App.tsx`, and `screenFromSave` hydrate before progress UI, distinguish first/returning runs, surface recovery/durability states, resume committed Celebration, and restart an interrupted clue at its Mission card. | Pass |
| `FE-006` | Welcome and the manifest-owned Lost Compass opening are wired as a three-step maximum with the youngest-explorer action and a direct setup/atlas path. | Pass |
| `FE-007` | Setup captures up to three nicknames, age bands, approved icon IDs, and sound preference only; validation prevents empty/duplicate/overlong nicknames; save completes locally before the opening. | Pass |
| `FE-008` | Atlas is ordered from the manifest and shows four current chapters, powers, text+icon state, progress, next access, session parent unlock, Passport, and the separate unscored epilogue. | Pass |
| `FE-009` | Chapter cards derive mission count/order, duration, energy, location, and state from content. Verona exposes the three manifest candidate pairs without silently selecting one; unresolved TBC slots retain manual/skip paths. | Pass |
| `FE-010` | One engine wires card → story → eyes-up → three roles/answer → persisted resolution → celebration for every manifest mission. Retry, pause, resume, skip, manual completion, and duplicate resolve are deterministic; no mission-specific component flow exists. | Pass |
| `FE-011` | `src/game/roles.ts` assigns and rotates Spotter/Detective/Navigator from committed completion count; parent session reassignment changes no score or save until normal completion advances once. | Pass |
| `FE-012` | Reusable role, phrase, observation, and multiple-choice controls cover the frozen content without typing, timing, GPS, audio, drag, or custom per-mission UI. Selection/correct/retry states use text, native state, icon, border, and color redundantly. | Pass |
| `FE-013` | Story and eyes-up screens render manifest safety; pause returns safely to the mission card; all four manifest fallbacks are visible in the adult-labelled sheet; manual/skip remain progression-resolving. | Pass |
| `FE-014` | `LocalGameController.resolveMission` is awaited before Celebration. Saved state determines the result, exact variant, role rotation, stamp, power state, facts, and next action. Repository idempotency prevents duplicate awards; reduced motion keeps all meaning static. | Pass |
| `FE-015` | `derivePassport` and `PassportScreen` show shared powers, completed/manual stamps, neutral saved-for-later markers, and discoveries, with empty/partial/complete/restored data derived only from active saved progress. | Pass |

## Frontend tests

Added:

- `tests/frontend/app-state.test.ts`
- `tests/frontend/content-repository.test.ts`
- `tests/frontend/game-controller.test.ts`
- `tests/frontend/roles-passport.test.ts`
- `tests/frontend/helpers.ts`

Coverage includes reducer transitions, invalid-route recovery, interrupted hydration, committed Celebration resume, base-safe/malformed/mismatched content, excursion variant resolution, setup, full 16-mission local journey, role rotation/reassignment, duplicate completion idempotency, skipped progression, and Passport derivation.

## Validation record

`npm run verify` passed on 30 September 2026:

- TypeScript project build: pass.
- ESLint: pass with zero warnings.
- Content/save/package validator: all 11 groups pass; 34 JSON/GeoJSON files parse.
- Vitest: 10 files, 61 tests pass.
- Vite production build: pass; 4,580 modules transformed.
- PWA precache audit: 15 files, 1,150,100 bytes raw / 839,603 bytes gzip.

The sandboxed Vite/Vitest launch can report Windows `spawn EPERM`; the approved local-process run passed. No browser visual QA was performed in this lane, as requested.

## Files changed in this resume

- `src/app/App.tsx`
- `src/app/app-state.ts`
- `src/components/AppShell.tsx`
- `src/components/InstallGuide.tsx`
- `src/components/screens.tsx`
- `src/content/content-repository.ts`
- `src/game/progress.ts`
- `src/i18n/strings.ts`
- `src/styles/global.css`
- `tsconfig.node.json`
- `tests/frontend/*`
- `TASKS.md`
- `planning/FRONTEND_WAVE1_HANDOFF.md`

## Deferred by scope, not failed

- Root should perform the production-like browser journey and visual checks at 320, 375, and 430 CSS px.
- `FE-016`–`FE-018` Parent Corner/degraded/cloud UI, maps `FE-019+`, and field-test work are later waves.
- Transparent Bussola character, chapter scenes, stamp art, optional sounds, and self-hosted fonts remain optional asset-production work. Missing art is omitted; no placeholder, emoji, CSS drawing, or invented SVG was introduced.
- Physical-phone, installed-PWA, force-close, and airplane-mode checks remain release gates.

## Blockers

None for `FE-001`–`FE-015`.
