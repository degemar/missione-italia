# Verona family run sheets

**Travel dates:** Thursday 8 and Friday 9 October 2026  
**Checked:** 30 September 2026 · **Live recheck:** 2–3 October, then the evening before each block  
**Rule:** at most two main activities per day. Times are pacing targets, not reservations. No hotel, ticket, session, boat, or parking space is represented as booked.

## Thursday 8 October — Verona

### Main plan

| Time | Family block | Mission and parent note |
|---|---|---|
| 08:45 | Parent check | Check the Arena notice and weather. Keep the car outside the historic-centre ZTL; choose a listed car park or walk from lodging. |
| 09:00–10:00 | **Main activity 1: Piazza Bra and Arena exterior** | Play `VER-01` outside. Entry is optional. The official calendar currently closes the Arena at **15:00**, last entry 30 minutes earlier, so do not postpone a desired interior visit. |
| 10:00–10:30 | Toilet, drink, snack | A real pause, not a mission. |
| 10:30–12:00 | Juliet exterior and Piazza Erbe | Play `VER-02` from the public approach and continue to Piazza Erbe. From April 2026 the paid visitor route enters at Teatro Nuovo, Piazzetta Navona, and requires advance online booking; without a booking, use the complete exterior/card version. |
| 12:00–13:30 | Lunch and seated rest | Stop the story. Review energy before choosing the afternoon. |
| 13:30–15:30 | **Main activity 2, full-city choice:** Adige/Ponte Pietra **or** a parent-selected short outing | Preferred: play `VER-03` from a safe viewpoint; crossing is optional. Any car outing replaces this entire block and never becomes a third activity. |
| From 15:30 | Free time / return | No catch-up missions. Use manual or save-for-later if energy is low. |

**Short-city choice:** finish after Piazza Erbe and lunch. `VER-03` can be completed from an offline card, manually, or later.  
**Full-city choice:** take the Piazza Erbe–Adige/Ponte Pietra block only if all three children still have energy.  
**Navigation points:** Piazza Bra → Piazzetta Navona/Teatro Nuovo public approach → Piazza Erbe → optional Ponte Pietra viewpoint. These are parent waypoints, not child instructions.

### Thursday swaps

- Light rain: keep the compact Arena exterior + Juliet/Piazza Erbe block; use shelter and card variants, then stop after lunch if needed.
- Heavy rain: replace the outdoor day with **one** Natural History Museum visit, or a pre-booked Children's Museum session; hotel cards are the zero-ticket equivalent.
- Arena closed/queue unsuitable: `VER-01` is complete outside.
- Juliet route unavailable/not booked: do not queue for entry; use the public exterior/card mission and Piazza Erbe.
- Tired legs or stroller friction: Arena exterior, seated break, one Piazza Erbe observation, then manual/card mode. Do not add Ponte Pietra.

## Friday candidate A — Sigurtà + Borghetto

This is the recommended candidate because both stops form one Valeggio/Borghetto cluster. Parent confirms live driving time.

| Target | Block | Cut-off rule |
|---|---|---|
| 08:15 | Leave Verona after weather/closure check | If severe-weather warnings or a park closure appear, select `verona-rain`; do not drive out hoping conditions improve. |
| 09:00–12:15 | **Main activity 1: Parco Giardino Sigurtà** | Play `VER-04/sigurta-team-maze` on one marked route. Current October hours are 09:00–18:00, last entry 17:00. The park says an average visit is half a day; do not promise flowers, animals, a maze finish, or internal transport. |
| 12:15–14:00 | Lunch, toilet, quiet rest | Park kiosks/benches exist, but parent decides food plan. Decide at 13:45 whether the village block still fits. |
| 14:15–15:45 | **Main activity 2: Borghetto** | Play one short `VER-05/borghetto-water-mill` observation away from the river edge. No restaurant, purchase, or interior is required. |
| 16:15 | Return to car | Leave the cluster by 16:30. Live traffic controls the Verona arrival; the app never promises it. |

**Rain rule:** light rain permits a short on-foot park visit only if the park is open and the parent accepts conditions; skip Borghetto if surfaces or energy are poor. Heavy rain, thunder, strong wind, or official severe-storm closure cancels both stops and activates `verona-rain`. Sigurtà states that internal vehicles may be suspended in heavy rain and the park may close in severe storms.

## Friday candidate B — Sirmione + optional Lazise

Never combine this candidate with Sigurtà/Borghetto.

| Target | Block | Cut-off rule |
|---|---|---|
| 08:00 | Leave Verona; parent checks traffic and parking | Target **Piazzale Monte Baldo**, the official main old-town car park. Historic-centre vehicle access is limited. No space is promised. |
| 09:15–12:00 | **Main activity 1: Sirmione** | Play `VER-04/sirmione-castle-water` from the exterior. Choose **one** extra only: castle entry, or a short local boat if it is operating, calm, uncrowded, and the parent accepts it. Do not do both. Current institutional castle hours list Friday 08:30–19:15; entry remains optional. |
| 12:00–14:00 | Lunch, toilet, long rest | Decide after the rest, not before it. |
| 14:00 decision | Return to Verona **or** low-pressure Lazise bonus | If anyone is tired, parking is difficult, weather worsens, or it is later than planned, skip Lazise without replacement. |
| 14:45–15:45 | **Main activity 2: Lazise, only if easy** | One-minute `lazise-bonus-spotter` at a safe public view of a wall/gate or the old harbour. No entry and no location unlock. |
| 16:15 | Walk back / depart by 16:30 | The departure cut-off wins over completing the bonus. |

**Walking load:** Sirmione is pedestrian-first after outlying parking and can be crowded; castle entry adds stairs. Exterior/card mode is the full low-mobility route. A boat is never promised and never a third activity.

## Friday candidate C — Verona indoor fallback

| Time | Block | Booking boundary |
|---|---|---|
| 10:00–11:45 | **Main activity 1: Natural History Museum** | Current hours Tue–Sun 10:00–18:00, last entry 17:30. If unavailable, use the hotel pattern cards. |
| 11:45–14:00 | Lunch and rest | No story requirement. |
| 14:30–16:15 | **Main activity 2: Children's Museum**, only with confirmed availability | Current weekday sessions shown are 14:30–16:15 and 16:45–18:30; capacity is limited and online purchase is strongly advised. If not booked, use hotel cards instead. |

## Weather, energy, closure, and mobility matrix

| Block | Light rain | Heavy rain | Tired child | Closed/unavailable | Stroller/mobility |
|---|---|---|---|---|---|
| Verona core | Short exterior route, shelter breaks | One indoor venue or hotel cards | Arena exterior + one seated clue | Exterior/card versions | Level public viewpoints; do not assume historic interiors are step-free |
| Ponte Pietra afternoon | View only; no crossing needed | Replace with indoor/rest | Skip/manual | Offline five-arch card | Nearest safe viewpoint only |
| Sigurtà | Short marked walk if open | Cancel cluster | One pattern near entrance, then stop | Cards/manual | Official FAQ says paths/lawns are generally stroller-friendly; choose shortest route |
| Borghetto | One sheltered shape | Cancel with park | Skip after lunch | Fact/legend cards | One public view away from river; no bridge crossing required |
| Sirmione | Exterior castle shape | Cancel lake candidate | Exterior/card only | Cards/manual | No castle stairs required; allow pedestrian approach and crowds |
| Lazise | One gate/harbour shape | Skip | Skip | Offline shape card | Nearest safe public view; no waterfront edge |
| Verona indoor | Normal | Normal | One room/session or hotel cards | Hotel cards | Parent checks venue access; card mode is equivalent |

No substitution creates a third activity. A cancelled afternoon stays cancelled.

## Parent-only facts and live-data boundary

| Item | Type | Checked 30 Sep | Recheck | Official source |
|---|---|---|---|---|
| Arena built around mid-first century | Stable fact | Yes | 3 Oct | [Visit Verona — Arena](https://www.visitverona.it/en/poi/arena-amphitheatre) |
| Arena 8 Oct closure 15:00; last entry 14:30 | Volatile | Yes | 7 Oct | [Visit Verona — Arena](https://www.visitverona.it/en/poi/arena-amphitheatre) |
| Juliet route/online booking | Volatile | Yes | 7 Oct | [Visit Verona — Juliet's House](https://www.visitverona.it/en/poi/juliet-s-house-and-museum) |
| Verona ZTL and car-park list | Volatile | Yes | 7 Oct | [Visit Verona — Getting around](https://www.visitverona.it/en/plan/how-will-you-get-around) |
| Sigurtà October 09:00–18:00, last 17:00; rain rule | Volatile | Yes | 8 Oct | [Sigurtà — FAQ](https://www.sigurta.it/faq) |
| Valeggio/Borghetto cluster and mills | Mixed | Yes | 3/8 Oct | [Visit Verona — Valeggio and Borghetto](https://www.visitverona.it/en/explore/a-magical-mix-of-history-and-countryside) |
| Sirmione parking/ZTL | Volatile | Yes | 8 Oct | [Visit Sirmione — Parking](https://visitsirmione.com/en/info/parking/) |
| Sirmione castle Friday hours | Volatile | Yes | 8 Oct | [Italian Ministry of Culture — Castle](https://museilombardia.cultura.gov.it/en/museums/rocca-scaligera-di-sirmione/) |
| Lazise walls, gates, old harbour | Stable fact | Yes | 3 Oct | [Municipality of Lazise](https://www.comune.lazise.vr.it/vivere-il-comune/territorio/english/) |
| Natural History Museum hours | Volatile | Yes | 8 Oct | [Municipality of Verona — Museum visit](https://museodistorianaturale.comune.verona.it/nqcontent.cfm?a_id=43639&lang=en) |
| Children's Museum sessions/capacity | Volatile | Yes | 8 Oct | [Children's Museum Verona](https://www.cmverona.it/home/) |

The user-supplied [verona.in idea page](https://www.verona.in/verona/useful-tips/best-family-friendly-day-trips-from-verona) was used only to discover the Sirmione/Lazise direction. Its specific timing, ferry, farm, swimming, market, and commercial claims are not used because they were not established by the primary official sources above.
