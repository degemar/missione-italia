# UX foundation handoff — UX-001 through UX-004

**Status:** complete for Wave 0 contract gate  
**Direction:** Living Storybook Atlas only  
**Runtime boundary:** one parent-controlled phone, 320–430 CSS px, browser and installed PWA  
**Content input validated against:** `public/content/trip-manifest.json` schema `0.1.0`, content `trip-2026.10-v1`

No screens, wireframes, prototype code, final illustrations, emoji substitutes, placeholder art, CSS drawings, or ad-hoc SVG assets were created in this wave.

## Handoff artifacts

| Artifact | Task | Implementation use |
|---|---|---|
| [`docs/ux-art-direction.md`](../docs/ux-art-direction.md) | UX-001 | Locked visual grammar, annotated references, chapter moods, use/avoid, asset boundary |
| [`docs/ux-screen-state-contract.md`](../docs/ux-screen-state-contract.md) | UX-002 | Screen inventory, primary/back behavior, transition table, offline/permission/TBC/resume/destructive paths |
| [`docs/design-tokens.md`](../docs/design-tokens.md) | UX-003 | Human-readable color, type, geometry, role/chapter, safe-area, layer, and motion rules |
| [`docs/design-tokens.json`](../docs/design-tokens.json) | UX-003 | Machine-consumable token source with resolvable references and manifest-keyed chapter semantics |
| [`docs/component-behavior-contract.md`](../docs/component-behavior-contract.md) | UX-004 | Child-first component anatomy, state matrix, accessibility, parent distinction, responsive/PWA behavior |

## Acceptance evidence

### UX-001 — visual direction

| Acceptance criterion | Evidence | Result |
|---|---|---|
| Living Storybook Atlas is the only direction; no concepts or wireframes | Art direction title/status and opening contract; asset boundary | Pass |
| Paper, sticker, ink, and compass usage is defined without imitation | Art direction “Visual grammar” and annotated reference boundaries | Pass |
| One system covers Road, Venice, Lagoon Islands, Verona, and epilogue | Art direction “Chapter mood notes”; shared token lookup | Pass |
| Lagoon motifs are original and avoid tourism/commercial copying | Lagoon mood boundary plus asset provenance boundary | Pass |

### UX-002 — screen/state and transitions

| Acceptance criterion | Evidence | Result |
|---|---|---|
| Every screen has one primary and defined back/close | Screen inventory columns “Visible primary action” and “Back/close” | Pass |
| Normal, manual, and skip paths reach Celebration and persist | Transition rows from Challenge/Resolve to Celebration; atomic completion rule | Pass |
| Story/clue deliberately hands attention back to the place | `STORY` → `LOOK-UP` → `CHALLENGE` states | Pass |
| Parent actions are distinct without a fake PIN | `PARENT-ENTRY`, `PARENT`, adult label/shape rules | Pass |
| No logistics, booking, or itinerary-management UI | Output boundary, Parent scope, TBC rules, component invariant | Pass |
| Navigation/progress is ordered-manifest-driven and supports 3/4 chapters | Global contract, Atlas/Chapter states, manifest compatibility check | Pass |
| Offline, permission, skip/manual, destructive, resume, and TBC paths exist | Dedicated sections and screen/transition rows for every path | Pass |
| Browser and installed-PWA differences are explicit | Runtime state and browser/PWA table | Pass |

### UX-003 — design tokens

| Acceptance criterion | Evidence | Result |
|---|---|---|
| Exact paper, ink, tomato, teal, gold, and violet assignments | Token table and `color.base` / `color.semantic` JSON | Pass |
| Roles use icon + label + shape, not color alone | Role table and `semantic.role` JSON | Pass |
| Chapters key by ID with a safe default and no fixed count | `semantic.chapter`, `meta.chapterLookup`, compatibility check | Pass |
| Body/read-aloud ≥18 px and targets ≥48×48 px | `font.size.childBody/readAloud`, `touch.minimum`, geometry rules | Pass |
| Essential contrast is AA; outdoor-critical pairs target 7:1 where practical | Deterministic contrast results below | Pass |
| Fonts are free/self-hostable and support English/Italian | Exact Fredoka/Atkinson stacks and bundling/licence gate | Contract pass; package/version evidence belongs to UX-007 asset manifest |
| Spacing, radii, borders, shadows, layers, icons, safe areas, and motion slots are exact | Machine token groups and human explanations | Pass |

### UX-004 — child-first components

| Acceptance criterion | Evidence | Result |
| Required applicable states are defined | Shared state table plus per-component applicability matrix | Pass |
| Selected answers work without animation or color | Answer-choice border, marker, text, and `checked` requirements | Pass |
| Wrong answers are kind and have no shame/points/losing child | Exact “Take another look” behavior | Pass |
| Controls work one-handed and for three children sharing one screen | Contract opening, ≥48 px targets, one primary, role/answer rules | Pass |
| Reset/delete are separated and clearly confirmed | Button and Dialog specifications; destructive screen contract | Pass |
| Chapter tabs, Passport/compass support 3 or 4 entries | Chapter tabs and Progress compass specifications; compatibility check | Pass |
| All named components are covered | Buttons, mission/role/answer, compass, tabs, stamps, sheets, dialogs, banners, toasts, parent entry | Pass |
| Reduced motion, outdoor use, no-color-only meaning, and parent/child distinction apply | Shared states and responsive/outdoor/PWA invariants | Pass |

## Validation evidence

| Check | Result |
|---|---|
| Token JSON parses | Pass |
| Token references resolve | Pass — 34/34 |
| Ink on paper / white | Pass — 15.47:1 / 16.38:1 (7:1 target) |
| Muted ink on paper | Pass — 7.35:1 (4.5:1 target) |
| White on tomato / teal / violet | Pass — 6.67:1 / 8.01:1 / 8.48:1 (4.5:1 target) |
| Ink on sun gold | Pass — 7.42:1 (7:1 outdoor target) |
| White on success / danger | Pass — 7.18:1 / 7.76:1 (4.5:1 target) |
| Focus blue on paper | Pass — 5.65:1 (3:1 non-text target) |
| Manifest chapter IDs resolve to a chapter token or default | Pass — `road`, `venice`, `lagoon-islands`, `verona` |
| Three- and four-chapter fixtures use the same lookup | Pass — no missing token set, empty slot, or ordinal key |
| Completion states match the manifest | Pass — `completed`, `manual`, `skipped` |
| TBC slots and candidate-pair mappings remain stable | Pass — `VER-04`, `VER-05`; three pair IDs map morning/afternoon variants |
| Epilogue is outside scored chapter progress | Pass — `RETURN-EP`, `chapterId: null`, `scored: false` |
| Internal Markdown links resolve | Pass |
| Excluded-destination or planner UI introduced by Wave 0 artifacts | Pass — none |

## Implementation invariants

- Render chapter order and progress from the manifest, then look up `semantic.chapter[id] ?? semantic.chapter.default`.
- Keep `completed`, `manual`, and `skipped` equally progression-resolving; retain their distinct label/icon/shape.
- Do not gate play on location, maps, data, tickets, audio, or Supabase.
- Keep all operational details and destructive actions in deliberate adult mode.
- Use only bundled, licence-recorded Phosphor functional icons. Do not fabricate Bussola, stamps, chapter scenes, markers, or route art while final assets are pending.

## Non-blocking assumptions and downstream inputs

- Font files, exact package versions, and licence records are added with the UX-007 asset manifest before implementation freeze; system fallbacks are already defined.
- Final illustration crops, asset sizes, and provenance are UX-007/Infra inputs; these contracts do not depend on temporary visible art.
- Backend owns the local transaction and recovery implementation behind the named save states; local-first behavior is mandatory.
- Infra owns runtime signals for browser/PWA, safe update, offline readiness, tile failure, and permission support.
- `excursionSelection.selectedPairId` may remain null through launch; manual and skipped resolution keep the finale reachable.

## True blockers

None for UX-001 through UX-004.
