# Frontend Parent Corner handoff

**Completed:** 30 September 2026  
**Scope:** `FE-016`; non-map/non-cloud portions of `FE-017`; cloud-off boundary of `FE-018`  
**Result:** Parent Corner is a complete local-first family-test vertical slice; map/GPS and enabled-cloud states remain correctly open

No Git remote, deployment, account, Supabase, map provider, geolocation request, external network, new dependency, or browser-wide deletion was used or added.

## Acceptance evidence

| Requirement | Implementation evidence | Result |
|---|---|---|
| Deliberate adult entry | `ParentEntry` requires a measured 900 ms pointer/keyboard hold, cancels on release/pointer cancel/leave/visibility loss, exposes numeric progress, and sends switch/screen-reader activation to an explicit adult confirmation. Copy states that the gate is not authentication. | Pass |
| Accessible modal behavior | `AccessibleDialog` uses native modal behavior, safe-action initial focus, Escape cancel, focus loop, and invoker focus restoration. | Pass |
| Reliable return | Reducer stores the exact session origin. Closing Parent Corner persists and returns to that screen without losing in-progress clue reveals, checks, choice, or role reassignment. | Pass |
| Mission and role controls | Parent Corner shows the current mission, session-only role reassignment, manual completion, and save-for-later. Completion still goes through `LocalGameController.resolveMission` and the central transaction wrapper. | Pass |
| Chapter and Verona controls | Session chapter unlock and manifest-owned Verona candidate-pair choice live in Parent Corner. Child Atlas/Chapter screens now point adults to the deliberate entry instead of exposing operational controls inline. | Pass |
| Help and install | Existing base-safe install guide plus local-play help are included. Maps, location, and cloud are not presented as working features. | Pass |
| Settings | Sound and reduced-motion preferences persist through the new typed `LocalGameController.updateSettings`; reduced motion applies immediately to the shell. | Pass |
| Storage health | Parent gesture can inspect estimate/quota/persisted status and request best-effort persistence through controller/storage adapters. Denial or unsupported status never blocks play. | Pass |
| Diagnostics | Preview uses the allowlisted snapshot contract and local diagnostic-code buffer. Copy is deliberate and reports unavailable clipboard support calmly. Preview contains no nicknames, answers, coordinates, URLs, tokens, stack, or raw exceptions. | Pass |
| Reset/delete | Each action requires initiate then explicit consequence confirmation. Reset retains family/settings and clears progress. Delete invokes confirmed trip maintenance for only the trip stores, exact owned cache, and diagnostic key; it never enumerates or clears browser-wide data. | Pass |
| Offline/update state | `PlatformStateController` tracks connectivity/readiness; existing-worker readiness is recognized. Banners and Parent Corner keep cached play primary. Waiting updates can activate only at Atlas/Parent and with no save transaction in flight. | Local pass; tile/GPS variants remain open |
| Cloud off | Platform cloud is initialized disabled; no auth client, sign-in, sync control, network request, or Supabase code is rendered or invoked. | Boundary pass; enabled-cloud states remain open |
| Recovery containment | App feature rendering is wrapped by `InfrastructureErrorBoundary`; only catalogue diagnostic codes are retained, while retry and Parent diagnostics remain available. | Pass |

## Deterministic tests

- Full-hold success, early-release cancel, and direct assistive activation.
- Prepare/cancel/commit maintenance state.
- Exact Parent Corner return with in-progress challenge state intact.
- Offline-ready/not-ready presentation, update waiting/ready gating, and cloud-disabled visibility.
- Persisted sound/reduced-motion settings.
- Reset preserving family/settings and clearing progress.
- Delete removing only the trip save and clearing diagnostics.
- Existing infrastructure suites continue to cover safe-update transaction blocking, scoped cache deletion, storage-health requests, diagnostic allowlisting, and recovery catalogue behavior.

## Files added or changed

- `src/parent/parent-controls.ts`
- `src/components/{AccessibleDialog,ParentEntry,ParentCorner}.tsx`
- `src/components/{AppShell,screens}.tsx`
- `src/app/{App,app-state,game-controller}.ts(x)`
- `src/platform/use-pwa-lifecycle.ts`
- `src/i18n/strings.ts`
- `src/styles/global.css`
- `tests/frontend/{parent-controls,game-controller}.test.ts`
- `TASKS.md`

## Deferred, not failed

- `FE-017` stays open for tile failure and GPS permission/status UI because the map/location adapters and map screens are not implemented.
- `FE-018` stays open for enabled-cloud states until `BACKEND-GATE` passes. The trip build remains cloud-off.
- `FE-019`–`FE-021`, production-like browser journeys, 200%/landscape checks, and physical-phone/installed/airplane-mode evidence remain later release gates.
- Root browser QA should visually inspect the complete Parent Corner and destructive-dialog cancel paths at 320, 375, and 430 CSS px; this lane verified the updated production build loaded, the adult entry appeared accessibly, and the stale waiting worker could activate only after returning to Atlas.

## Blockers

None for the first local family test or manual GitHub Pages import. Supabase remains unnecessary and disabled.
