# Missione Italia — Story and Content Backlog

**Workstream:** story, missions, destination content, copy, audio/localization, and content QA  
**Release target:** trip-ready by 3 October 2026  
**Audience:** one cooperative family team; children aged 9, 7, and 4  
**Last source check:** 29 September 2026

This backlog does not create wireframes or application code. It supplies content artifacts to the UX/UI, frontend, backend, and infrastructure workstreams.

**Wave 0 status (29 September 2026):** `ST-001`–`ST-009` completed. Acceptance evidence and downstream caveats are recorded in `planning/STORY_FOUNDATION_HANDOFF.md`; the machine-readable authority is `public/content/trip-manifest.json`.

**Wave 1 status (29 September 2026):** `ST-010`–`ST-015` and `ST-020`–`ST-035` completed. (`ST-016`–`ST-019` are not defined.) Evidence is recorded in `planning/STORY_WAVE1_HANDOFF.md`; `npm run verify` passes.

## Release rules

- **P0:** required for the trip build; **P1:** add only after every P0 mission is playable; **P2:** post-trip.
- The confirmed trip runs **Sunday, 4 October through Saturday, 10 October 2026**; use `planning/TRIP_CALENDAR.md` as the scheduling authority.
- **Gardaland is excluded from the app.** No Gardaland story, mission, checkpoint, unlock, map marker, reward, source task, or branded asset may ship.
- Keep the MVP at **16 scored missions**: Road 3, Venice 4, Lagoon Islands 3, Verona and day trips 6. The four powers are Curiosity, Wonder, Creativity, and Teamwork. Saturday adds only a short unscored epilogue.
- Each mission must work without GPS, live maps, audio, tickets, or an open venue.
- Historical claims, legends, and live visitor information must remain distinct. Label folklore as a legend.
- Do not copy text, illustrations, maps, branded characters, or challenge wording from tourism or inspiration sites.

## Critical decisions

| ID | Decision needed | Default if approved | Why it blocks work |
|---|---|---|---|
| `DEC-S01` | **Resolved:** 4–10 October calendar and overnight sequence. | See `planning/TRIP_CALENDAR.md`; exact hotel localities remain generic until supplied. | No longer blocks chapter order. |
| `DEC-S02` | **Deliberately deferred behind manifest slots:** Thursday's optional short trip and Friday's full-day excursion remain TBC. | Recommended: no Thursday car trip; Friday Sigurtà + Borghetto. Alternate: Friday Sirmione + short Lazise stop. | No longer blocks foundation: `VER-04`/`VER-05` are stable slots. Parent selects variants before content freeze. |
| `DEC-S03` | **Resolved:** English child-facing UI/story with a small Italian phrase layer. | Keep strings localization-ready; adult controls also use English. | No longer blocks final copy. |
| `DEC-S04` | **Product default locked:** nicknames only. | No surnames, birthdays, faces, or story text generated from private data. | No longer blocks setup copy. |
| `DEC-S05` | **Product default locked:** parent read-aloud is P0. | Browser speech or recorded audio is P1 and cannot delay the playable build. | No longer blocks story production. |
| `DEC-S06` | **Resolved:** no specific family constraint or booked interior was declared. | Preserve inclusive read-aloud, reduced-motion, no-ticket, outdoor/manual, tired-legs, and no-GPS fallbacks. | No longer blocks missions; revisit only if needs change. |
| `DEC-S07` | **Resolved:** include the outbound Road chapter and Saturday return epilogue. | Road restores Curiosity; Saturday is short and unscored. | No longer blocks the manifest. |

## Shared mission definition of done

Every mission task below delivers one versioned mission record plus its story and source notes. It is accepted only when it contains:

- a 30–60 second parent-read story, a one-sentence objective, expected duration, energy level, and location/checkpoint;
- one meaningful contribution for each rotating role: **Spotter (4)**, **Detective (7)**, and **Navigator (9)**;
- a cooperative resolution: no sibling score, fastest-child reward, forced ride, public performance, or courage test based on fear;
- one correct response or an observation-based completion rule, a short explanation, and one surprising fact;
- an explicit `eyes up / stop walking` instruction wherever the phone is used;
- GPS/proximity, manual check-in, closed-venue, tired-legs, and bad-weather behavior;
- source IDs for every factual claim, plus `fact_checked_on` and `review_after` fields;
- no instruction to run, separate from adults, cross a road to collect a clue, climb unsafe structures, photograph strangers, or use a phone in a moving car.

## Foundation backlog

| ID | Pri | Depends on | Deliverable | Acceptance criteria |
|---|---:|---|---|---|
| `ST-001` | P0 | `DEC-S01` | `planning/TRIP_CALENDAR.md` with one row per date and overnight | **Complete:** every date from departure through return has origin, principal activity, destination/overnight, and app inclusion; unknown hotel localities and excursion choices are explicitly TBC. |
| `ST-002` | P0 | `ST-001`, `DEC-S02` | Manifest-driven 8–9 October destination set | Exactly one Verona city day and at most one full-day car excursion; Thursday's optional extra and Friday's destination are explicitly TBC; every day has one morning and one afternoon anchor; stable slots prevent the decision from blocking product work. |
| `ST-003` | P0 | `DEC-S03`, `DEC-S06` | Language, reading, pronunciation, and accessibility brief | Uses English plus a small Italian phrase layer, parent read-aloud, age-appropriate reading levels, and inclusive color/hearing/motion defaults. |
| `ST-004` | P0 | `ST-003`, `DEC-S04` | `docs/story-bible.md` | Defines compass personality, four powers, stakes without a villain, beginning/middle/finale, role rotation, tone, canon facts, recurring phrases, and prohibited themes in no more than four pages. |
| `ST-005` | P0 | `ST-004` | `docs/content-style-and-safety.md` | Sets word limits, sentence length, humor style, legend labeling, cooperative language, safe-motion rules, no-shame skip wording, and Italian-term formatting with examples. |
| `ST-006` | P0 | None | `public/content/sources.json` plus human-readable source register | Each claim has an authoritative URL, page title, retrieved date, claim text, stability level, and required recheck date; official venue/destination sources are preferred. |
| `ST-007` | P0 | `ST-004`, UX mission states, frontend content schema | Content contract for chapters, missions, choices, facts, rewards, fallbacks, locations, and source IDs | One canonical example validates against the agreed schema; no copy is embedded only in components; day-trip multi-stop content does not require a new engine. |
| `ST-008` | P0 | `ST-004`, UX reward model | Reward and passport vocabulary | Defines four compass powers, six or fewer reusable stamp types, celebration phrases, unlock language, and how skipped/manual missions still preserve the shared story. |
| `ST-009` | P0 | `ST-001`–`ST-008` | Final mission manifest and chapter beat sheet | Contains exactly the 16 scored missions below in calendar order plus the unscored Saturday epilogue; the finale remains reachable if Friday's excursion is cancelled. |

## Chapter narrative backlog

| ID | Pri | Depends on | Deliverable | Acceptance criteria |
|---|---:|---|---|---|
| `ST-010` | P0 | `ST-004`, `ST-008` | Opening and family oath | Explains the Lost Compass and cooperative roles in under 90 seconds; the youngest child can trigger the first action; no tutorial exceeds three screens. |
| `ST-011` | P0 | `ST-004`, `ST-009` | Road chapter, Curiosity restoration, and return epilogue | Both are deliberately lightweight, work while parked or as parent-led audio, never ask the driver to look at or touch the phone, and the Saturday epilogue carries no required power. |
| `ST-012` | P0 | `ST-004`, `ST-009` | Murano/Burano Lagoon Islands chapter and Creativity restoration | Connects glass patterns, lagoon navigation, color, and lace into an original maker mystery; distinguishes craft history from legend and treats public transport as parent-controlled. |
| `ST-013` | P0 | `ST-004`, `ST-009` | Venice chapter intro, transitions, and Wonder restoration | Connects lions, bridges, canals, and boats into one mystery; includes crowd, high-water, and transport fallbacks; avoids encouraging children to approach canal edges. |
| `ST-014` | P0 | `ST-004`, `ST-009` | Verona chapter arc and compass finale | Connects Roman Verona, the Adige, Scaliger places, garden/village/lake discoveries, and Teamwork; finale works at Castel San Pietro or anywhere manually selected. |
| `ST-015` | P0 | `ST-010`–`ST-014` | Resume, skip, retry, offline, closed-place, and ending variants | Every interruption returns the family to the story without blame; skipped missions never block a compass power; final text acknowledges all completed discoveries without exposing missing ones as failure. |

## Mission-writing backlog

The task-specific acceptance criteria below are additional to the shared mission definition of done.

| ID | Pri | Depends on | Mission deliverable | Additional acceptance criteria |
|---|---:|---|---|---|
| `ST-020` | P0 | `ST-006`, `ST-011` | `ROAD-01 Country Detective` | Uses observable road signs/flags chosen by the parent; offers a stationary fallback; never relies on automatic border detection. |
| `ST-021` | P0 | `ST-006`, `ST-011` | `ROAD-02 Alpine Tunnel Hunt` | Parent starts it before driving; children count or listen without unbuckling; facts name only verified tunnels actually on the confirmed route. |
| `ST-022` | P0 | `ST-003`, `ST-011` | `ROAD-03 First Italian Words` | Teaches no more than five useful, polite words with checked meaning and pronunciation; includes picture/gesture participation for age 4. |
| `ST-023` | P0 | `ST-006`, `ST-012` | `ISL-01 Murano Glass Pattern Lab` | Uses observable shape, color, reflection, and repeated-pattern clues; museum/furnace entry is optional; never prompts touching merchandise or taking a photo. |
| `ST-024` | P0 | `ST-006`, `ST-012` | `ISL-02 Lagoon Navigator` | Parent chooses and validates the actual vaporetto; children identify safe stop/route symbols while stationary; timetable and service claims stay parent-only and receive a final live check. |
| `ST-025` | P0 | `ST-005`, `ST-006`, `ST-012` | `ISL-03 Burano Colour-and-Lace Code` | Combines house-color spotting with a simple lace/pattern clue; the fisher-recognition story and foam-born lace story are labeled tradition/legend rather than fact; respects homes and residents. |
| `ST-026` | P0 | `ST-006`, `ST-013` | `VEN-01 Find the Winged Lion` | Explains the symbol with a verified source; clue is solvable from a safe public position and has an included-image/manual fallback. |
| `ST-027` | P0 | `ST-006`, `ST-013` | `VEN-02 Bridge Detective` | Uses patterns, materials, or safe counting; explicitly forbids leaning over rails; works on an alternate bridge if the route changes. |
| `ST-028` | P0 | `ST-006`, `ST-013` | `VEN-03 Venice Boat Detective` | Children compare two safely observed boat roles or shapes without making the real travel decision; no vessel type or service is promised at a specific checkpoint. |
| `ST-029` | P0 | `ST-006`, `ST-013` | `VEN-04 Canal Sound Hunt` | Family stops before the parent lowers the phone; includes quiet and visual alternatives and never instructs recording strangers. |
| `ST-030` | P0 | `ST-006`, `ST-014` | `VER-01 Arena Time Machine` | Uses verified Roman/Arena facts; keeps gladiator content non-graphic; V1 is fully playable from the exterior, with interior guidance deferred. |
| `ST-031` | P0 | `ST-006`, `ST-014`, `ST-045` | `VER-02 Juliet's Message Mystery and Verona City Trail` | Is fully playable outside Juliet's House, distinguishes Shakespearean fiction and later Verona tradition from documented history, and uses original clues linking Piazza Bra, Piazza Erbe, Ponte Pietra/Adige, and the viewpoint. Interior guidance is deferred. |
| `ST-032` | P0 | `ST-002`, `ST-006`, `ST-014` | `VER-04` candidate `sigurta-team-maze` | Includes navigation, nature spotting, and a no-entry/manual path; does not promise blooms, animals, transport hire, or event programming. |
| `ST-033` | P0 | `ST-002`, `ST-006`, `ST-014` | `VER-05` candidate `borghetto-water-mill` | Connects the river, old mills, bridge, and the Lover's Knot story; clearly labels the knot story as legend; safe riverside behavior is explicit. |
| `ST-034` | P0 | `ST-002`, `ST-006`, `ST-014` | `VER-04` candidate `sirmione-castle-water` | Uses the castle, fortified harbour, battlements, and lake shapes; entry is optional; restricted historic-centre vehicle access remains parent-only. |
| `ST-035` | P0 | `ST-008`, `ST-014`, completed mission-state contract | `VER-06 Restore the Compass` | Each child performs one different cooperative action; adapts to any completion count; takes under five minutes; provides a quiet/no-motion celebration option. |

## Murano/Burano day-content backlog

| ID | Pri | Depends on | Deliverable | Acceptance criteria |
|---|---:|---|---|---|
| `ST-036` | P0 | `ST-001`, `ST-012`, `ST-023`–`ST-025` | Wednesday 7 October Lagoon Islands run sheet | Uses Murano as the morning anchor and Burano as the afternoon anchor, omits Torcello, includes food/toilet/rest buffers, and protects sufficient time for the confirmed transfer to Verona. |
| `ST-037` | P0 | `ST-006`, `ST-036` | Lagoon weather/transport fallback | Defines full two-island, single-island, heavy-rain, missed-boat, and service-disruption paths; the Glass and Lace Museums are optional indoor anchors, and manual completion never blocks Creativity. |
| `ST-038` | P0 | `ST-006`, `ST-036` | Parent-only island transport facts | Records official stop names and candidate routes without hard-coding a timetable into child copy; actual ACTV service is rechecked on 2–3 October and again on 6 October. |
| `ST-039` | P0 | `ST-006`, `ST-023`–`ST-025` | Murano/Burano craft fact audit | Separates documented glass/lace history from Burano color and lace legends; every child-facing claim is paraphrased from Venezia Unica or MUVE evidence and respects active workshops and residents. |

## Verona-base plan and place-content backlog

### Confirmed dates; excursion choices TBC

The calendar is confirmed. Thursday's optional extra and Friday's excursion remain `DEC-S02`, not assumptions.

| Date | Morning block | Rest/lunch | Afternoon block | Bad-weather fallback |
|---|---|---|---|---|
| **Thu 8 Oct — Verona** | Arena first, then Juliet's House and a compact Piazza Bra → Via Mazzini → Piazza Erbe trail. The Arena currently lists a 15:00 closure; Juliet's House requires online booking for interior access. | Long lunch and hotel reset. | Verona afternoon or one short car trip TBC; a car trip replaces Ponte Pietra/Funicular rather than being added. | Castelvecchio or Natural History Museum; a 1h45 Children's Museum session is the hands-on option and should be booked. |
| **Fri 9 Oct — full-day trip TBC** | **Recommended:** Parco Giardino Sigurtà, approximately 09:00–12:30, focusing on nature and the maze. | Lunch in Valeggio/Borghetto. | Compact Borghetto water-mill and river mystery, then return to Verona. | Cancel the outdoor trip: Natural History Museum in the morning and prebooked Children's Museum in the afternoon. Museo Nicolis is not a practical Friday fallback because weekday access after 1 October is currently restricted to prebooked groups of at least 20. |

**Why this pairing:** Verona receives a real city day instead of a rushed half-day, while Friday's two stops form one nearby cluster that the official destination site places about half an hour from Verona. It offers active garden play, a maze, a compact village, and only one main experience per half-day. For ages 9, 7, and 4, this is more manageable than adding a Thursday drive and then combining several Lake Garda towns on Friday.

**Alternate:** choose Sirmione in the morning and a short Lazise waterfront stop in the afternoon if lake/castle scenery is the priority. This carries more parking, walking, and weather risk; Sirmione's official portal confirms restricted historic-centre vehicle access. Do not combine this alternate with Sigurtà on the same day.

### Planning tasks

| ID | Pri | Depends on | Deliverable | Acceptance criteria |
|---|---:|---|---|---|
| `ST-040` | P0 | `ST-001`, `ST-002`, `ST-030`, `ST-031` | Thursday 8 October Verona run sheet | Includes Arena and Juliet's House, meal/rest buffer, short/full city choice, booking/exterior fallbacks, the Arena's 15:00 closure, parent navigation points, and indoor swaps; any car trip visibly replaces—not adds to—the afternoon block. |
| `ST-041` | P0 | `ST-001`, `ST-002`, `ST-032`, `ST-033` | Friday 9 October Sigurtà/Borghetto candidate run sheet | Keeps both places in one geographic cluster; includes October 09:00–18:00 park hours/17:00 last entry, realistic rest, return cut-off, and a rain cancellation rule. |
| `ST-042` | P0 | `ST-001`, `ST-002`, `ST-034` | Friday 9 October Sirmione/Lazise alternate run sheet | Includes verified parking target, walking load, one main Sirmione activity, optional boat only if operating/calm, Lazise as a low-pressure bonus, and a return-to-Verona cut-off; never combines with Sigurtà. |
| `ST-043` | P0 | `ST-040`–`ST-042` | Weather and energy substitution matrix | For each block, defines light-rain, heavy-rain, tired-child, venue-closed, and stroller/mobility alternatives; no swap creates more than two main activities in one day. |
| `ST-044` | P0 | `ST-001`, `ST-006`, `ST-040`–`ST-043` | Parent-only visitor facts | Separates stable place facts from volatile hours, tickets, ZTL/parking, booking, and navigation details; volatile claims show checked date and direct official link. |
| `ST-045` | P0 | `ST-006` | Reference review of official Verona for Kids hunts | Obtain or download both official hunts, log overlapping landmarks/mechanics, retain only factual inspiration, and document how Missione Italia's clues are original and age-role cooperative. |
| `ST-046` | P1 | `ST-042`, `ST-044` | `Lazise Bonus Spotter` card | A one-minute, unscored observation card with no location unlock and no factual dependency beyond a verified public landmark. |

## Copy, audio, and localization backlog

| ID | Pri | Depends on | Deliverable | Acceptance criteria |
|---|---:|---|---|---|
| `ST-050` | P0 | UX state inventory, `ST-005` | Child-facing UI microcopy sheet | Covers all labels, instructions, answers, errors, offline/location states, celebrations, empty states, and confirmations; reading level is checked and buttons are action-led. |
| `ST-051` | P0 | `ST-003`, `DEC-S04` | Family setup and role-rotation copy | Uses nicknames only, explains rotation without age hierarchy, and never labels one role smartest/easiest/best. |
| `ST-052` | P0 | UX Parent Corner states, `ST-044` | Parent-only microcopy sheet | Clearly explains manual unlock, skip, reset/delete, location permission, external navigation, live-data caveats, and child safety; destructive actions have precise confirmation text. |
| `ST-053` | P0 | `ST-010`–`ST-035` | Read-aloud script pack | Every narration is speakable in 60 seconds or less, expands abbreviations/numbers naturally, includes pronunciation notes, and matches on-screen meaning exactly. |
| `ST-054` | P0 | `ST-003`, `ST-022` | Italian phrase mini-glossary | Meanings, age-appropriate use, syllable/pronunciation help, and audio-ready text are independently checked; avoids caricatured accents. |
| `ST-055` | P0 | `ST-003`, `ST-007`, `ST-050`–`ST-054` | Localization key catalog and glossary | Every user-visible string has a stable key, variables/plurals are identified, place names remain canonical, and no text is assembled by concatenating fragments. |
| `ST-056` | P0 | All written content and selected assets | Alt text, transcripts, and non-audio equivalents | Every meaningful image/audio cue has an equivalent; decorative art is marked decorative; no mission depends only on color, sound, or animation. |
| `ST-057` | P1 | `DEC-S05`, `ST-053`, stable playback implementation | Compressed optional narration/audio pack | Normalized, intelligible on a phone speaker, fully downloadable before travel, licensed/owned, and removable without breaking the mission. |

## Content QA and release backlog

| ID | Pri | Depends on | Deliverable | Acceptance criteria |
|---|---:|---|---|---|
| `ST-060` | P0 | All P0 narrative/mission content | Factual and source audit report | Every externally checkable claim resolves to a source record; unsupported claims are removed or labeled fiction/legend; no search-result snippet is the final evidence. |
| `ST-061` | P0 | All P0 missions, `ST-043` | Safety, inclusion, and privacy audit | Reviews roads, crowds, water edges, rides, heights, photos, GPS, motion, sensory load, reading, and skip behavior; every issue has a tested fallback. |
| `ST-062` | P0 | `ST-020`–`ST-035`, `ST-050` | Three-age desk review | A reviewer can identify one non-token action for ages 4, 7, and 9 in every mission; no clue depends on reading ability beyond its role. |
| `ST-063` | P0 | Playable build, `ST-062` | Family dry-run log | Each child completes at least one unseen mission; capture completion time, confused wording, adult coaching, role imbalance, motion/sound response, and one revision decision per issue. |
| `ST-064` | P0 | `ST-007`, all content and assets | Content package validation report | Schema validation passes; all IDs/links/source references resolve; essential text/assets are in the offline bundle; stale draft or PII files are absent. |
| `ST-065` | P0 | `ST-001`, `ST-038`, `ST-044`, `ST-060` | Final live-information recheck dated 2–3 October | Rechecks Venice/Murano/Burano ACTV service and museum notices, Verona Arena early closing, Sigurtà hours, Sirmione castle/parking if selected, weather fallbacks, and booked sessions; app copy changes only where essential. Gardaland is intentionally outside this review. |
| `ST-066` | P0 | `ST-060`–`ST-065`, product field-test gate | Immutable `trip-2026.10-v1` content manifest | Records content hash/version, source-check date, included missions/assets, known caveats, and rollback version; only blocking corrections occur after freeze. |
| `ST-067` | P2 | Trip complete | Post-trip content debrief template and results | Records which missions were started/completed/skipped, child quotes with parent consent, factual corrections, route friction, best role moments, and candidates for a reusable trip format. |

## Dependency handoffs

| Receiving lane | Story/content provides | Story/content needs back |
|---|---|---|
| UX/UI | Story bible, mission manifest, text-length limits, role model, state microcopy, fallback matrix | Final state inventory, interaction order, visual capacity per screen, reduced-motion behavior |
| Frontend/infra | Versioned JSON/GeoJSON-ready content, asset list, localization keys, source metadata, offline criticality | Validated schema, base-path/asset rules, cache budget, content validation command |
| Backend | Save-state meanings for chapter, mission, reward, skip, and content version | Stable progress/revision fields and migration behavior; no child profile expansion |
| Parent/travel planning | Confirmed calendar, decision list, candidate Verona blocks, verified visitor facts | Exact hotel localities if needed, Arena/Juliet interior booking choice, accessibility/sensory needs, and final 8–9 October excursion choices |

## Current official-source register for island and Verona planning

The calendar is confirmed; live transport, venue, and excursion facts remain time-sensitive. `ST-065` must recheck them before travel.

| Source | Current planning evidence |
|---|---|
| [Venezia Unica — Murano](https://www.veneziaunica.it/en/things-to-do-in-venice/venice-areas/islands/murano) | Official destination overview and glassmaking context; use for facts, not copied prose or images. |
| [MUVE — Murano Glass Museum hours](https://museovetro.visitmuve.it/en/pianifica-la-tua-visita/opening-times/) | Currently open daily 10:00–18:00 through 31 October, last admission 17:00; optional indoor anchor on Wednesday 7 October. |
| [Venezia Unica — Burano](https://www.veneziaunica.it/en/things-to-do-in-venice/venice-areas/isole/burano) | Official destination evidence for colorful homes, fishing/craft context, lace history, and which popular explanations are tradition or legend. |
| [MUVE — Burano Lace Museum hours](https://museomerletto.visitmuve.it/en/pianifica-la-tua-visita/opening-times/) | Currently 10:00–16:00, last admission 15:30, closed Mondays; optional indoor anchor on Wednesday 7 October. |
| [ACTV — navigation timetables](https://actv.avmspa.it/en/content/orari-servizio-di-navigazione-0) | Official source for the F.te Nove–Murano–Mazzorbo–Burano corridor; actual 7 October services and disruption notices require a final check. |
| [Visit Verona — Arena Amphitheatre](https://www.visitverona.it/en/poi/arena-amphitheatre) | Roman context; regular Tuesday–Sunday hours; currently lists 15:00 closure on 7, 8, 9, and 10 October 2026. |
| [Visit Verona — Juliet's House and Museum](https://www.visitverona.it/en/poi/juliet-s-house-and-museum) | From April 2026, entry uses Teatro Nuovo/Piazzetta Navona and online booking is required for the house; mission content must separate the literary story from documented history and retain an exterior fallback. |
| [Visit Verona — Verona for Kids](https://www.visitverona.it/it/esperienze/verona-for-kids-caccia-al-tesoro-1) | The tourist office offers two child treasure hunts; use as overlap/reference research, not copied content. |
| [Visit Verona — Funicular](https://www.visitverona.it/en/poi/funicolare-di-castel-san-pietro) | Reaches the Castel San Pietro viewpoint; current April–October hours are daily 10:00–21:00. |
| [Visit Verona — Valeggio and Borghetto](https://www.visitverona.it/en/explore/a-magical-mix-of-history-and-countryside) | Places Sigurtà and Borghetto in one cluster about half an hour from Verona; describes the mills and Lover's Knot legend. |
| [Parco Giardino Sigurtà — FAQ](https://www.sigurta.it/faq) | 2026 season runs through 15 November; October hours currently 09:00–18:00, last entry 17:00. |
| [Visit Sirmione — parking](https://visitsirmione.com/en/info/parking/) | Historic-centre vehicle access is limited; Monte Baldo is the principal nearby car park and SirmioPark shows covered availability. |
| [Visit Sirmione — Scaligero Castle](https://visitsirmione.com/en/what-to-see/art-and-monuments/scaliger-castle/) | Castle, walkways, tower, and fortified harbour provide the mission facts; exact dated opening must be checked through its official ticket link. |
| [Children's Museum Verona](https://www.cmverona.it/home/) | Interactive STEAM museum for ages 0–12; visits last 1h45 and capacity is limited, so a rainy-day session should be booked rather than assumed. |
| [Verona Natural History Museum](https://museodistorianaturale.comune.verona.it/nqcontent.cfm?a_id=43639&lang=en) | Indoor geology, paleontology, zoology, and botany fallback; current hours Tuesday–Sunday 10:00–18:00, last entry 17:30. |
| [Museo Nicolis — visitor information](https://www.museonicolis.com/en/info-and-tickets/) | From 1 October 2026, Tuesday–Friday is reservation-only for groups of at least 20; regular public opening is Saturday/Sunday 10:00–18:00. |

## Story/content completion gate

This lane is complete for the trip only when `ST-001`–`ST-066` P0 items pass, `DEC-S02` is either closed or deliberately deferred behind a manifest slot, the 16 scored missions and return epilogue are explicit, every claim is sourced, every mission has a no-GPS/no-ticket fallback, all three children contribute meaningfully, and the frozen content package runs from the offline build without missing copy or assets.
