# Infrastructure foundation handoff

**Scope:** INF-001–INF-011  
**Status:** local package contract complete; account, production URL, and physical-phone release checks deferred  
**Date:** 29 September 2026

`AC1`, `AC2`, and so on refer to each task's acceptance criteria in listed order in `planning/INFRA_TASKS.md`.

## Acceptance evidence

| Task | Local evidence mapped to acceptance criteria | Deferred release evidence |
|---|---|---|
| INF-001 | AC1: `VITE_BASE_PATH`, default `/missione-italia/`, is the single override. AC2–AC3: public boundary and manual inputs are explicit in `README.md`, `MANUAL_IMPORT.md`, and `planning/INFRA_FOUNDATION_DECISIONS.md`. AC4: typed cloud flag defaults off and absent cloud values pass tests/build. AC5: local install/build requires no credential, account, or remote. | Personal owner/repository/Pages URL and phone matrix are recorded only during manual release. |
| INF-002 | AC1: this folder is the copy root and contains no standalone `.git`. AC2: no credential, remote, push, or deployment action was performed. AC3: workflows target `main`; branch change is documented. AC4: `.gitignore` covers environment, output, coverage, tests, diagnostics, logs, and editors. AC5: package is isolated from parent/private files. AC6: `README.md` and `MANUAL_IMPORT.md` document commands, public boundary, import, Pages, validation, and rollback. | User performs the clean personal-repository import. |
| INF-003 | AC1: `.nvmrc`, `engines`, and both workflows pin Node 24.15.0; npm 11.12.1 is pinned. AC2: exact dependencies and `package-lock.json`; clean `npm ci` passed. AC3: strict TypeScript, `noUncheckedIndexedAccess`, and `exactOptionalPropertyTypes`; no blanket `any`. AC4: runtime is React, React DOM, bundled Phosphor, and Workbox registration only. AC5: production build passed; the only install warning was reviewed as the build-only `vite-plugin-pwa → workbox-build → glob@11.1.0` deprecation. | CI repeats the clean install after import. |
| INF-004 | AC1: `src/app`, `components`, `config`, `content`, `platform`, `styles`, and `tests/infra` separate concerns; the backend save contract remains untouched. AC2: versioned JSON stays under `public/content`; assets under `public/assets`. AC3: all required npm commands exist. AC4: one `index.html`/React entry and internal state; the canonical preview URL refreshed with HTTP 200. AC5: content/assets use `import.meta.env.BASE_URL` through `joinBasePath`. | Feature views consume this source contract in later waves. |
| INF-005 | AC1: no-Supabase typecheck/test/build passed. AC2: allowlist contains only reviewed public base/cloud/tile/Supabase values. AC3: secret-shaped names, `sb_secret_`, and decoded legacy `service_role` JWTs fail tests. AC4: `.env.example` is placeholder-only and local environment files are ignored. AC5: public bundling warning is in both environment example and README. | Cloud settings remain absent/off for the trip candidate unless the later P0 gate passes. |
| INF-006 | AC1: `validate.yml` runs `npm ci` then the full verify chain. AC2: workflow permission is `contents: read` with no secrets. AC3: exact Node pin matches `.nvmrc`. AC4: build/deploy workflow repeats the same verify gate before artifact upload. AC5: every official action uses a reviewed full commit SHA with a version comment. | GitHub-hosted execution begins only after personal import. |
| INF-007 | AC1: normalization accepts `/<repo>/` or `/`. AC2: runtime paths derive from Vite base. AC3: default subpath preview passed; an alternate `/family-trip/` build also passed and emitted matching HTML/inventory. AC4: manifest `id`, `start_url`, and `scope` equal the configured base. AC5 local equivalent: canonical preview shell, refresh, manifest, worker, content, and icon URLs all returned 200. | Repeat AC5 on the final HTTPS Pages URL and installed app. |
| INF-008 | AC1: deployment uploads only `dist` and instructions select GitHub Actions. AC2: build and dependent deploy jobs are separate. AC3: deploy has only `contents: read`, `pages: write`, and `id-token: write`. AC4: `github-pages` environment and one `pages` concurrency group. AC5: only `main`/manual events deploy; PRs run read-only validation. AC6 contract: Pages URL is exposed and a retrying HTTP/app-shell smoke step follows deploy. AC7: delivery stopped at files; no account/remote/Pages action occurred. AC8: `MANUAL_IMPORT.md` covers copy boundary, settings, verification, and rollback. | Actual deploy output URL and post-deploy smoke result require the user-run workflow. |
| INF-009 | AC1: generated manifest contains stable ID, names, base-safe launch scope, standalone display, colors, and portrait orientation. AC2: visually inspected real 192/512/maskable derivatives preserve the full opaque safe composition. AC3: real 180px Apple icon and Apple metadata are included; guidance accurately uses Share → Add to Home Screen. AC4 local contract: required icon/manifest files served with 200. AC5: install guidance states installation is optional. | Android Chrome/iPhone Safari recognition and Home Screen launches require the recorded phones and final HTTPS URL. |
| INF-010 | AC1 local contract: generated `sw.js` is under the configured scope. AC2: `registerType: prompt` and `updateSW(true)` runs only from “Update when ready”; there is no automatic reload. AC3: `cleanupOutdatedCaches` runs after safe activation. AC4: registration error preserves the app and shows a parent-readable warning. AC5: `vite-plugin-pwa@1.3.0` generated the worker in the pinned production build. | Confirm worker control and update flow on installed production clients. Mission-transaction interlock belongs to INF-012. |
| INF-011 | AC1: the current inline 16-mission manifest, source/reward/package JSON, shell, and every registered offline-critical icon are present in the generated precache; future registered media/fonts are build-audited by the same boundary. AC2: policy and tests exclude OSM tiles, Google, Supabase responses, diagnostics, family data/photos, source masters, and source maps; generated worker has no runtime cache rules. AC3: missing registered files fail content/build validation and any candidate over 5 MiB fails the precache audit. AC4: `reports/cache-inventory.json` records base-aware URL, SHA-256 revision, raw bytes, and gzip bytes for 15 unique entries. AC5 local contract: shell/navigation fallback and all current content are precached. | Physical airplane-mode restart is deferred; complete in-app action coverage is repeated after gameplay integration and on the final phone. |

## Validation record

| Command/check | Result |
|---|---|
| `python scripts/generate-icons.py` | PASS; 180/192/512/maskable files produced without crop; dimensions, visual safe area, hashes, and provenance checked |
| `npm ci` | PASS; 449 packages installed from lockfile |
| `node scripts/validate-contracts.mjs` | PASS; all 11 groups, including updated asset/content package integrity |
| `npm run typecheck` | PASS |
| `npm run lint` | PASS, zero warnings |
| `npm test` | PASS; 3 files, 14 tests |
| `npm run build` | PASS; generated service worker, 15 unique precache entries, 1,019,689 raw bytes / 806,941 gzip bytes |
| alternate-base build (`VITE_BASE_PATH=/family-trip/`) | PASS; manifest/HTML/inventory use `/family-trip/` |
| default preview HTTP smoke | PASS; shell, manifest, worker, content package, and 192px icon returned 200 under `/missione-italia/`; manifest ID/start/scope matched |

## Deferred, not failed

- Personal GitHub import, repository settings, workflow runs, Pages activation, production URL, and rollback rehearsal.
- Primary/backup phone model recording; Android/iPhone install, standalone launch, HTTPS worker control, and airplane-mode checks.
- Full offline gameplay-action and safe transaction/update checks after frontend and persistence waves.
- No self-hosted font or story illustration was approved in Wave 0, so none was fabricated; when supplied and registered, the build boundary must include it.

There is no blocker for the next wave. Cloud backup remains off and no Supabase value was requested.
