# Parent Corner browser QA — 30 September 2026

## Result

Parent Corner passed production-build browser QA at 320, 375, and 430 CSS px.

## Coverage

- Adult entry and explicit confirmation.
- Safe cancel with focus returned to the adult-entry control.
- Parent Corner layout, chapter access, Verona route choices, settings, update state, storage health, install help, diagnostics, reset, delete, and safe return.
- Diagnostics preview/copy and exclusion of nicknames, answers, URLs, tokens, coordinates, stacks, and raw errors.
- Reset-progress and delete-family consequence dialogs; both were cancelled and no trip data was deleted.
- Final production Atlas after restoring the 900 ms adult hold.

## Responsive/accessibility evidence

- 320 px: document `scrollWidth` equals `clientWidth`; no horizontal scrolling.
- 375 px: adult confirmation and Parent Corner controls remain readable with safe-action initial focus.
- 430 px: chapter-access rows and sticky Done action remain readable.
- Native dialogs make background content inert, focus the safe action first, and restore the invoker on cancel.
- The browser automation API cannot sustain a 900 ms hold. A temporary local 1 ms/direct-click override was used only to visually inspect the gated screens, then fully reverted. The final source and production build use 900 ms; deterministic hold/cancel tests pass.

## Final validation

- `npm run verify`: pass.
- TypeScript and ESLint: pass, zero warnings.
- Contract validation: 11/11 groups.
- Vitest: 16 files, 83/83 tests.
- Production PWA build and precache audit: pass; 15 files, 1,208,007 bytes raw / 854,289 gzip.
- Final browser view shows the restored production Atlas and `Adult controls. Hold for 900 milliseconds`.

## Remaining release gates

- Maps/GPS and their offline checkpoint fallback.
- Enabled-cloud states only if Supabase is later approved.
- Production-like journeys, landscape/200% text, physical-phone install, airplane-mode restart, and deployment rollback rehearsal.
