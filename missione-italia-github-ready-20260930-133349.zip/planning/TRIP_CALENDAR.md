# Missione Italia — Confirmed Trip Calendar

**Dates:** Sunday, 4 October through Saturday, 10 October 2026  
**Status:** calendar and overnight sequence confirmed; exact hotel localities and the 8–9 October excursion choices remain TBC  
**Family:** two adults; children aged 9, 7, and 4

**Scheduling authority:** this file controls story dates and overnight sequence. Verified against the 2026 calendar on 29 September 2026. Destination selection is data in `public/content/trip-manifest.json`; it must not rewrite the confirmed dates.

| Date | Origin | Confirmed principal activity | Destination / overnight | App inclusion |
|---|---|---|---|---|
| **Sun 4 Oct** | Basel | Drive to the Gardaland area | Gardaland area; exact locality TBC | Lightweight **Road / Curiosity** chapter. No Gardaland content. |
| **Mon 5 Oct** | Gardaland area | Gardaland day; transfer afterward | Venice area; exact locality TBC | **Excluded from the app.** Show only a neutral pause/continue state if needed; no story, mission, map checkpoint, unlock, tracking, or branded asset. |
| **Tue 6 Oct** | Venice area | Venice city exploration | Venice area; exact locality TBC | **Venice / Wonder** chapter: four city missions and short/full walk variants. |
| **Wed 7 Oct** | Venice area | Murano and Burano; transfer to Verona afterward | Verona; exact lodging TBC | **Lagoon Islands / Creativity** chapter: Murano, lagoon navigation, and Burano missions. Transfer itself has no required mission. |
| **Thu 8 Oct** | Verona | Arena di Verona, Juliet's House, Verona city; optional short trip remains TBC | Verona | **Verona / Teamwork** city missions. Any short trip replaces part of the afternoon rather than being added on top. |
| **Fri 9 Oct** | Verona | Full-day car excursion remains TBC | Verona | Stable scored slots `VER-04` morning and `VER-05` afternoon select a manifest variant. Primary recommendation: Sigurtà + Borghetto; no destination is assumed. |
| **Sat 10 Oct** | Verona | Drive home | Basel / home | Lightweight return-road epilogue; story completion does not depend on it. |

## Confirmed content boundaries

- Gardaland is intentionally outside Missione Italia. It must not appear as a chapter, mission, checkpoint, reward, story setting, or source-review requirement.
- Four-power story: **Curiosity** (Road) → **Wonder** (Venice) → **Creativity** (Murano/Burano) → **Teamwork** (Verona).
- Sunday Road is included; Saturday is a short epilogue and never carries a required compass power.
- Thursday's optional short trip and Friday's full-day destination remain decision `DEC-S02`, deliberately deferred behind manifest slots. No child-facing destination promise is published before selection, and the choice does not change the 16-mission count.

## Calendar change control

- Confirmed date/order changes require an explicit parent update to this file before manifest copy changes.
- Hotel names/localities may replace `TBC` without changing chapter order.
- Excursion selection updates only `excursionSelection.selectedPairId` and the active variants for `VER-04`/`VER-05`.
- Monday remains outside the app even if travel timing changes.

## Recommended 8–9 October pairing

1. **Thursday 8 October — Verona only.** Arena/Piazza Bra and the historic-centre hunt in the morning; long lunch/rest; Ponte Pietra and the Castel San Pietro funicular/viewpoint in the afternoon. The Arena currently lists a 15:00 closure on 8 October, making morning the reliable slot.
2. **Friday 9 October — Sigurtà + Borghetto.** Garden/maze in the morning; lunch and a compact water-mill/river mystery in Borghetto in the afternoon. They form one nearby cluster, and the official Verona destination site places them about half an hour from Verona.

This is more manageable for ages 9, 7, and 4 than adding a Thursday car trip and then combining multiple Lake Garda towns on Friday. Sirmione + a short Lazise stop remains the alternate if the family values lake/castle scenery more than garden play and accepts the parking/walking load.

## Weather rule

- Decide the outdoor Friday plan from the forecast by Thursday evening.
- In heavy rain, remain in Verona: Natural History Museum in the morning and a prebooked 1h45 Children's Museum session in the afternoon.
- Museo Nicolis is not the Friday fallback: from 1 October 2026 its Tuesday–Friday public access is currently limited to prebooked groups of at least 20.
- Recheck all official opening, transport, closure, and booking information on 2–3 October and again the evening before use.

## Official planning sources checked 29 September 2026

- [Venezia Unica — Murano](https://www.veneziaunica.it/en/things-to-do-in-venice/venice-areas/islands/murano)
- [Venezia Unica — Burano](https://www.veneziaunica.it/en/things-to-do-in-venice/venice-areas/isole/burano)
- [ACTV navigation timetables](https://actv.avmspa.it/en/content/orari-servizio-di-navigazione-0)
- [Arena Amphitheatre](https://www.visitverona.it/en/poi/arena-amphitheatre)
- [Valeggio, Sigurtà, and Borghetto](https://www.visitverona.it/en/explore/a-magical-mix-of-history-and-countryside)
- [Parco Giardino Sigurtà hours](https://www.sigurta.it/faq)
- [Sirmione parking](https://visitsirmione.com/en/info/parking/)
- [Children's Museum Verona](https://www.cmverona.it/home/)
- [Verona Natural History Museum](https://museodistorianaturale.comune.verona.it/nqcontent.cfm?a_id=43639&lang=en)
- [Museo Nicolis visitor information](https://www.museonicolis.com/en/info-and-tickets/)
