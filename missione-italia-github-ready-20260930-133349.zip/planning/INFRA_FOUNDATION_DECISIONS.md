# Infrastructure foundation decisions

**Scope:** INF-001–INF-011 local contract, 29 September 2026

- The package root is the complete copy boundary. It has no standalone Git repository, remote, credential, account identity, or deployment state.
- GitHub Pages defaults to `/missione-italia/`. `VITE_BASE_PATH` is the only override; use `/<repo>/` for a project site and `/` for a user site/custom domain.
- A free Pages deployment and every committed/static file are public. Family data, precise location, progress, photos, credentials, and private travel material are excluded.
- Personal GitHub owner, repository/Pages URLs, default-branch exceptions, and primary/backup phone details are manual release inputs, not local-build blockers.
- `VITE_V1_CLOUD_BACKUP` defaults to `off`. Missing Supabase settings never fail the build or app, and no Supabase values are requested for Wave 0.
- Node 24.15.0 and npm 11.12.1 are pinned locally and in CI. Dependencies are exact and the lockfile is authoritative.
- The generated service worker uses prompt updates. Its precache is limited to the app shell, current content package, approved registered assets, and any future approved self-hosted fonts.
- OSM tiles, Google URLs, Supabase responses, diagnostics, family data/photos, source masters, and source maps are outside the precache.
- The first UI is a truthful foundation status/install shell. It is not a gameplay mock, wireframe, or story-art substitute.

