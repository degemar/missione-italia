# Backend/data Wave 1 handoff

**Completed:** 29 September 2026 · **Scope:** `BE-021`–`BE-024`, `BE-030` · **Result:** pass

The implementation is local-only. No Git remote, account, Supabase project, network client, authentication, analytics, or cloud service was accessed or added. Gardaland remains excluded; Arena and Juliet remain exterior-first in content; Verona excursion selection stays manifest-driven.

## Deliverables

| Task | Evidence |
|---|---|
| `BE-021` | `src/storage/storage-engine.ts`, `local-save-repository.ts`, `index.ts`; native IndexedDB adapter, memory fallback, serialized atomic repository |
| `BE-022` | `save-migrations.ts`, `content-reconciliation.ts`, migration fixtures; ordered v0→v1 migration and stable-ID reconciliation |
| `BE-023` | `save-transfer.ts`; SHA-256 export/import preview and replacement; verified trip-data deletion |
| `BE-024` | `docs/local-storage-and-recovery.md`; bounded last-known-good policy, parent-triggered persistence, recovery signals/runbook |
| `BE-030` | `tests/backend/*.test.ts`, `tests/backend/helpers.ts`, `tests/fixtures/save/migration/*`; deterministic native-API contract suite |

`fake-indexeddb` `6.2.4` is the only added dependency and is dev-only. It runs the production native IndexedDB adapter in Node; no alternate production database or abstraction was introduced.

## Acceptance evidence

### BE-021

| Criterion | Evidence | Result |
|---|---|---|
| Canonical, recovery, and outbox update atomically | One three-store IndexedDB transaction in `updateInternal`/`replaceInternal`; bounded/outbox test | Pass |
| Persist before setup/mission/manual/skip/settings/reset success | Repository resolves after `transaction.oncomplete`; generic typed mutation path plus fresh/manual/skipped/reset fixtures | Pass |
| Rapid/background/reload/duplicate safe | Promise serialization, keyed mission reducer, 20-call duplicate test, immediate close/reopen test | Pass |
| No network/session/map required | Storage modules import only local contracts/native APIs; complete-story test has no cloud client | Pass |
| IndexedDB unavailable/quota fallback | Explicit durability result and parent copy; unavailable and `QuotaExceededError` tests | Pass |

### BE-022

| Criterion | Evidence | Result |
|---|---|---|
| Deterministic, idempotent migrations | Ordered registry; v0 fixture migrates once and second pass is unchanged | Pass |
| Validate before replacing last good | Migration validation precedes atomic canonical replacement | Pass |
| Failed migration restores prior and permits export | Failure test restores newest valid snapshot and `exportTrip()` succeeds; otherwise original stays untouched with `invalid-save` | Pass |
| Compatible stable IDs retained; unknown IDs recoverable/inactive | Reconciliation partitions active/unknown while preserving the serialized map; tests cover content update and unknown route | Pass |
| Newer schema never downgraded/overwritten | v2 fixture returns read-only `newer-schema`; update rejects and bytes remain unchanged | Pass |

### BE-023

| Criterion | Evidence | Result |
|---|---|---|
| Export excludes prohibited/session/device data | Strict save validator plus export test scan | Pass |
| Import validates schema/trip/content/checksum/size before preview | `previewSaveImport`; corrupt, tampered, wrong-trip, incompatible, old-schema, and oversize tests | Pass |
| Import snapshots and never silently overwrites | Preview checksum must remain unchanged; replacement adds `before-import` recovery | Pass |
| Local deletion removes and verifies all trip stores | `deleteLocalTripData` and deletion test | Pass |
| Static cached content remains | Repository can address only its three IndexedDB stores; runbook records boundary | Pass |

### BE-024

| Criterion | Evidence | Result |
|---|---|---|
| Bounded validated snapshots | Maximum three; newest-first validation and six-write pruning test | Pass |
| Corrupt canonical falls back and tells parent | Integrity mutation test returns `source: recovery`, `warning: corrupt-canonical` | Pass |
| Persistence parent-triggered/non-blocking | Browser API has no implicit call site; explicit granted and memory-only tests | Pass |
| Required recovery scenarios documented | Browser clearing, PWA removal, eviction, failed migration, quota/corruption, and JSON restore in runbook | Pass |

### BE-030

| Criterion | Evidence | Result |
|---|---|---|
| Required fixtures/states/failures covered | Foundation fixtures plus v0/v2/corrupt fixtures; 33 deterministic backend tests cover fresh/partial/full/manual/skipped/reset, duplicate, mismatch, recovery, quota, unavailable IndexedDB, import, and delete | Pass |
| Reload/device restart survives offline | Fresh IndexedDB connection reopens the same database after the first repository closes | Pass |
| Full story works with cloud absent/failing | All 16 scored missions complete with no cloud/network interface present; backup remains disabled | Pass |
| Fictional/no family data | Fixtures use no real family identity; prohibited-data validator remains active | Pass |

## Interface for Frontend

Import from `src/storage/index.ts`. Create one `LocalSaveRepository` in the app data layer, await every mutation before success navigation/celebration, render its durability/warning state in Parent Corner/Recovery, and keep React components away from IndexedDB. Derive rewards/unlocks from active known mission progress; never count the preserved unknown map.

## Validation record

- Backend suite: 33/33 tests passed.
- TypeScript: passed.
- ESLint: passed with zero warnings.
- Content/save/package validator: all 11 groups passed.
- Full `npm run verify`: passed, including production build and precache audit.

## Non-blocking follow-ups

- Frontend owns the actual Parent Corner import/export file picker, confirmation UI, banners, and persistence-request gesture.
- Infra owns real-browser/PWA lifecycle, background/force-close, OS-eviction, and physical-phone validation.
- `BE-040+` cloud/auth/sync remains intentionally absent and disabled.

## Blockers

None.
