# Frontend Wave 1 browser QA — 30 September 2026

## Result

Wave 1 passed local production-build browser QA after two defects were corrected.

## Coverage

- Production PWA preview at 320, 375, and 430 CSS px.
- Welcome, three-child setup, three-step opening, atlas, chapter, mission card, story, eyes-up handoff, all three role check-ins, persisted completion, celebration, and Passport.
- Reload/resume with one completed mission.
- Console warnings and errors.

## Defects found and fixed

1. A 320 px viewport could expose horizontal scrolling when a classic vertical scrollbar reduced the usable content width. Root minimum widths were removed and a stable scrollbar gutter was added. The recheck reported equal document `scrollWidth` and `clientWidth`.
2. Navigation from a scrolled screen could leave the next focused heading behind the sticky header. Every screen transition now resets the document to the top before focusing its heading. The recheck settled at `scrollY: 0`, with the focused heading below the header.

## Evidence

- Full journey at 375 px awarded exactly one mission and changed progress from 0/16 to 1/16.
- Passport showed the shared `Eagle Eye` stamp and the saved discovery for `Country Detective`.
- Reload restored Passport and the 1/16 progress state.
- 320 px recheck: no horizontal scrollbar.
- 430 px recheck: cards, Passport sections, and sticky actions remained readable.
- Browser console: zero warnings and zero errors.
- Automated suite after the fixes: `npm run verify` passes with 61/61 tests and all 11 contract groups.

## Still required

- Physical iPhone/Android field check remains part of `FE-027`.
- Parent Corner, degraded states, maps, and optional cloud UI are outside Wave 1.
