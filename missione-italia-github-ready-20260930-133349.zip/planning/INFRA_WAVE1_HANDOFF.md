# Infrastructure Wave 1 handoff

**Completed:** 30 September 2026  
**Scope audited:** `INF-012`–`INF-017`, `INF-023`–`INF-025`, `INF-032`–`INF-033`  
**Result:** local infrastructure adapters pass; map, Parent Corner presentation, deployed rollback, and physical-phone evidence remain correctly open

No Git remote, deployment, account, network service, Supabase project, map provider, geolocation prompt, or browser-wide deletion was accessed.

## Task status and evidence

| Task | Status | Evidence / remaining gate |
|---|---|---|
| `INF-012` | Local pass; deployment rehearsal open | `safe-update.ts`, `use-pwa-lifecycle.ts`, and the central App commit path prevent activation outside Atlas/Parent or during a transaction, flush `LocalSaveRepository`, then activate. Build/app/content/database/SHA metadata and compatibility checks are machine-readable. Tests retain completed progress across activation/reopen. Actual waiting-worker forward/rollback rehearsal remains `INF-038`. |
| `INF-013` | Partial | `platform-state.ts` models online, offline-ready/not-ready, tiles, location status, cloud-off/unavailable, and keeps core gameplay available. Tile-to-checkpoint UI and external Google label require `INF-019`–`INF-022`; keep this task open. |
| `INF-014` | Pass (audited) | Existing versioned schema, strict save contract, stable IDs, prohibited-field checks, and atomic IndexedDB stores satisfy the task. |
| `INF-015` | Pass (audited) | Existing `LocalSaveRepository` is the only IndexedDB boundary; hydration, atomic/idempotent completion, reopen, duplicate-tap, quota, and memory-only tests pass. |
| `INF-016` | Local pass; release rollback gate open | Existing v0→v1 migration/recovery plus the explicit `missionIdMigrations` registry preserve renamed/removed progress. Empty, partial, complete, malformed, old, and newer-version fixtures pass. Named rollback-build proof remains `INF-038`; keep the grouped Wave checkbox open. |
| `INF-017` | Adapter pass; Parent UI open | `storage-health.ts` exposes estimate/quota/persisted and best-effort persist without permission APIs. `trip-data-maintenance.ts` requires two-step deliberate confirmation and deletes only the trip's three IndexedDB stores plus the exact owned trip-data cache. It never enumerates or clears browser-wide caches. Parent presentation belongs to `FE-016`/`FE-017`. |
| `INF-023` | Pass (audited) | The 12 draft-2020-12 schemas and matching runtime/save types remain authoritative and CI-blocking. |
| `INF-024` | Pass | Validator now additionally enforces exact filename case, registered asset hash/size/dimensions, destination bounds, safe HTTPS sources, references, GeoJSON order/range, and the existing semantic contract. Seven deterministic content mutations pass. |
| `INF-025` | Pass for current runtime assets | `runtime-asset-policy.json` and `audit-precache.mjs` verify provenance/licence text, hashes, PNG dimensions, per-asset caps, registered offline coverage, and 15/25 MiB aggregate budgets. Missing optional story art remains omitted, not represented by placeholders. |
| `INF-032` | Adapter pass; panel/network audit open | `diagnostics.ts` stores only a maximum of 20 allowlisted code/timestamp pairs locally. Snapshot includes versions, SHA, service worker, readiness, storage, feature flags, connectivity, tiles, location status, and cloud status. Preview is explicit and contains no nickname, answer, URL, token, stack, or path. Parent panel and final network audit remain `FE-016`/`INF-035`. |
| `INF-033` | Partial | `recovery-catalogue.ts` defines distinct stable codes and safe actions; `InfrastructureErrorBoundary.tsx` contains feature render failures without retaining raw exceptions. Map/location/cloud feature wiring remains downstream; reset is never first/automatic. |

## Exact frontend integration API

1. Keep all saves inside `LocalGameController`; `App` already wraps its central commit path with `trackLocalTransaction`. Never call `updateSW(true)` outside `usePwaLifecycle`.
2. Instantiate one `PlatformStateController(navigator.onLine, false)`. Map PWA readiness to `OFFLINE_READINESS_CHANGED`; later map/tile, location, and optional cloud adapters dispatch only status enums—never coordinates.
3. For Parent diagnostics, call `StorageHealthAdapter.inspect(controller.getDurabilityStatus())`, then `createDiagnosticSnapshot(...)`. Show `createDiagnosticPreview(snapshot)` before any deliberate copy action.
4. Request durable storage only from a parent gesture via `controller.requestPersistentStorage()`; a denied result is not persistence.
5. For reset/delete, call `prepareTripMaintenance`, show its consequence, then call `confirmTripMaintenance` only from the explicit confirmation action. Pass the confirmed intent to `controller.resetProgress(...)` or `controller.deleteTripData(...)`; for delete, provide `clearDiagnostics: () => diagnosticBuffer.clear()`.
6. Record only catalogue codes through `LocalDiagnosticBuffer.record(code)`. Never pass exception text, a URL, stack, answer, nickname, or token.
7. Wrap feature surfaces with `InfrastructureErrorBoundary` and render the corresponding `recoveryFor(kind)` actions. Map and cloud failures should replace only that feature; Passport/manual play stay available.

## Validation

`npm run verify` passes:

- TypeScript: pass.
- ESLint: pass with zero warnings.
- Contract validator: 11/11 groups; 35 JSON/GeoJSON files; 7 invalid content mutations.
- Vitest: 15 files, 78/78 tests.
- Production PWA build: 4,583 modules; JS 101.36 KiB gzip; CSS 3.39 KiB gzip.
- Precache audit: 15 files; 1,156,144 bytes raw / 841,440 bytes gzip.

## Files changed

- `src/platform/{build-metadata,diagnostics,InfrastructureErrorBoundary,platform-state,recovery-catalogue,safe-update,storage-health,trip-data-maintenance,use-pwa-lifecycle}.ts(x)`
- `src/app/App.tsx`, `src/app/game-controller.ts`
- `src/components/AppShell.tsx`, `src/i18n/strings.ts`
- `src/content/content-repository.ts`, `src/content/types.ts`
- `src/storage/content-reconciliation.ts`, `src/storage/local-save-repository.ts`, `src/storage/save-transfer.ts`
- `vite.config.ts`, `src/vite-env.d.ts`, `config/runtime-asset-policy.json`
- `scripts/validate-contracts.mjs`, `scripts/audit-precache.mjs`
- `tests/infra/*`, `tests/frontend/content-repository.test.ts`, `tests/backend/save-contract.test.ts`, content-invalid fixtures

## True blockers

None for `FE-016`/`FE-017` Parent Corner integration. `INF-013` and `INF-033` cannot fully close before map/checkpoint fallback work; `INF-016` cannot claim release rollback proof before the named-build rehearsal.
