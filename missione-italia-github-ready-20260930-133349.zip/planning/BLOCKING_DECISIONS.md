# Missione Italia — Decision Gate

**Status:** no blocker remains before specialist execution.

## Closed decisions

| Workstream | Decision |
|---|---|
| Story | English story/UI with a small Italian phrase layer. |
| Story | Arena and Juliet's House missions must work outside; interior guidance is deferred. |
| Story | No family accessibility or sensory constraint was declared; inclusive skip, read-aloud, reduced-motion, no-ticket, and no-GPS fallbacks still ship. |
| UX/UI | Mobile-phone-only responsive web/PWA. |
| UX/UI | Functional icons use self-hosted Phosphor Icons (MIT); chapter, compass, stamp, and route illustrations are original and share one art direction. |
| Infrastructure | Codex must not connect to or publish through the professional GitHub account. It creates a portable local package, workflows, and manual-import guide for the user's personal repository. |
| Backend | The Supabase project already exists and is connected to the personal repository. Local IndexedDB remains authoritative; Supabase backup is feature-flagged and cannot block play. |
| Product | Gardaland stays completely outside the app. All other days are included; the outbound and return days stay lightweight. |

## Deferred inputs — not blockers

| Input | Needed when | Safe handoff |
|---|---|---|
| Personal GitHub owner/repository URL and resulting Pages URL | Manual import/deployment test | User enters them while following `MANUAL_IMPORT.md`; Codex does not authenticate or push. |
| Supabase Project URL | Cloud-backup integration test | User places it in local `.env.local` and later a personal-repository variable. Do not paste it into chat. |
| Supabase browser-safe publishable key (`sb_publishable_...`) | Cloud-backup integration test | Same local/manual flow. Never provide a secret key, service-role key, database password, or access token. |
| Exact production URL | Supabase Auth redirect allowlist | Add after GitHub Pages is live. |
| Primary and backup phone model/OS/browser | Final release QA | Record before actual-device testing; it does not block implementation. |
| Thursday optional short trip and Friday day trip | Destination-content freeze | The app uses manifest-driven destination slots; decide later without changing the engine. |

## Execution boundary

Agents may now start one at a time. Recommended order: Story foundation → UX/UI contract → Backend/data contracts → Infrastructure shell → Frontend assembly → specialist QA/freeze.

See [`MANUAL_HANDOFF_INPUTS.md`](MANUAL_HANDOFF_INPUTS.md) for the later personal GitHub, Supabase, and release-QA inputs.
