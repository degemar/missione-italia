# Missione Italia — pause status (30 September 2026)

## Safe stopping point

- All specialist agents are stopped.
- The complete local-first family loop is implemented: setup, Atlas, four chapters, 16 missions, roles, celebrations, Passport, persistence, recovery/export, and Parent Corner.
- Phone-browser QA passed at 320, 375, and 430 CSS px. Horizontal overflow and retained-scroll focus bugs were fixed.
- Parent Corner QA passed for the 900 ms adult gate, cancel/focus return, diagnostics, and non-destructive reset/delete confirmation paths.
- The last fully verified application baseline passed 83/83 tests, typecheck, lint, all 11 content checks, production build, and PWA precache audit.
- No professional GitHub remote/account and no Supabase credentials were connected.

## Story Wave 2 checkpoint

The Story agent was stopped at the pause deadline after saving:

- `planning/VERONA_WAVE2_RUN_SHEETS.md`
- updates to `public/content/sources.json`
- updates to `public/content/trip-manifest.json`
- updated hashes in `public/content/content-package.json`

The run sheets use current official sources for Verona, Arena di Verona, Juliet's House, Sigurtà, Sirmione, Lazise, parking/ZTL, and indoor fallbacks.

Known open items:

- `planning/STORY_WAVE2_HANDOFF.md` was not written before interruption.
- `ST-045` is intentionally partial: Verona's two official treasure-hunt maps are physical IAT handouts, and their unseen clues must not be copied or claimed.
- `ST-046` remains open.
- The live opening-hours, closure, weather, parking, ticket, and ZTL recheck remains due on 2–3 October.

## Validation at pause

After the Story edits, root corrected the changed `sources.json` file hash and deterministic package hash.

The latest `npm run verify` reached these confirmed passes:

- TypeScript
- ESLint with zero warnings
- all 11 content/contract groups, including package hashes

Vitest did not start because the Windows sandbox blocked Vite's helper process with the known `spawn EPERM` condition. This is an environment restriction, not a discovered test failure. Tests and the production build must be rerun outside the sandbox at resume; the last complete baseline remains 83/83.

## Exact resume sequence

1. Run `npm run verify` with the already-approved elevated execution if the sandbox returns `spawn EPERM`.
2. Inspect `planning/VERONA_WAVE2_RUN_SHEETS.md` and resume one Story agent only to finish `ST-040`–`ST-056`, write `planning/STORY_WAVE2_HANDOFF.md`, and update task statuses. Keep `ST-045` partial and `ST-046` open unless new evidence resolves them.
3. Run one UX/UI Wave 2 agent for `UX-008`–`UX-011` plus the implemented-primitives review against `UX-003`–`UX-006`.
4. Run one Infrastructure maps agent for `INF-019`–`INF-022` and `INF-026`–`INF-027`: lazy Leaflet/OpenStreetMap, one-shot foreground location, Google Maps URL handoff, offline checkpoint list, and adapter tests.
5. Run one Frontend maps/quality agent for `FE-019`–`FE-025` and the remaining tile/GPS portion of `FE-017`.
6. Complete local privacy/data freeze (`BE-050`, `BE-060`).
7. Run Wave 3 integration and actual-family-phone release QA. The decisive gate is install → airplane-mode restart → mission → force-close → progress recovery on the production URL.
8. Consider optional Supabase only after every trip-critical Wave 3 gate passes.

Continue one specialist at a time. Do not start Git/remotes, deployment, account access, or Supabase work without Diego's explicit direction.

## Testing and deployment state

- The core app is ready for meaningful local family testing.
- Before manually importing the latest source to personal GitHub, complete resume step 1 so the interrupted Story edits have a fresh full verification/build.
- Manual personal-GitHub instructions remain in `MANUAL_IMPORT.md`.
- Local preview command: `npm run preview -- --host 127.0.0.1 --port 4173`
- Preview URL: `http://127.0.0.1:4173/missione-italia/`
- Supabase is not required for the trip-ready release and remains off.

## Fixed scope retained

- 4–10 October 2026; one shared parent phone; children aged 4, 7, and 9.
- Four chapters: Road & Return, Venice, Lagoon Islands, and Verona.
- Gardaland does not appear in app content, navigation, or tests.
- Arena di Verona and Juliet's House remain exterior-first.
- Friday recommendation remains Sigurtà + Borghetto, with Sirmione + Lazise and Verona indoor alternatives.
- English UI with a small Italian phrase layer; phone-only PWA; local-first saves.
- Maps use curated checkpoint walks, Leaflet/OpenStreetMap when online, ordered offline lists, optional Google Maps handoff, one-shot foreground location, and no stored coordinates/history.
